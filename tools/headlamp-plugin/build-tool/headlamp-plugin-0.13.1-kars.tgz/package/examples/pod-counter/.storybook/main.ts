import type { StorybookConfig } from '@storybook/react-webpack5';
import webpack from 'webpack';


const config: StorybookConfig = {
  stories: ['../src/**/*.mdx', '../src/**/*.stories.@(js|jsx|mjs|ts|tsx)'],
  addons: [
    '@storybook/addon-webpack5-compiler-swc',
    '@storybook/addon-onboarding',
    '@storybook/addon-essentials',
    '@chromatic-com/storybook',
    '@storybook/addon-interactions',
  ],
  framework: {
    name: '@storybook/react-webpack5',
    options: {},
  },
  webpackFinal: async (config) => {
    config.plugins?.push(
      new webpack.DefinePlugin({
        'import.meta.env': JSON.stringify({
          PUBLIC_URL: process.env.PUBLIC_URL || '',
        }),
      })
    );
    return config;
  },
};
export default config;
