/**
 * Gets the number of rows per page for tables from local storage.
 *
 * @param defaultRowsPerPage - The default number of rows per page if not set in local storage.
 * @returns {number} - The number of rows per page.
 * If not set, returns the default value.
 */
export declare function getTablesRowsPerPage(defaultRowsPerPage?: number): number;
/**
 * Sets the number of rows per page for tables in local storage.
 *
 * @param perPage - The number of rows per page.
 * @returns {void}
 */
export declare function setTablesRowsPerPage(perPage: number): void;
