/**
 * Adds backstage authentication token to headers if available
 *
 * @param headers - optional existing headers to add the token to
 * @returns headers with backstage token if available
 */
export declare function addBackstageAuthHeaders(headers?: HeadersInit): HeadersInit;
