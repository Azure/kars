/**
 * @returns the 'VERSION' of the app and the 'GIT_VERSION' of the app.
 */
export declare function getVersion(): {
    VERSION: any;
    GIT_VERSION: any;
};
/**
 * @returns the product name of the app, or undefined if it's not set.
 */
export declare function getProductName(): string | undefined;
