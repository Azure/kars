/**
 * @returns true if the app is in development mode.
 */
export declare function isDevMode(): boolean;
