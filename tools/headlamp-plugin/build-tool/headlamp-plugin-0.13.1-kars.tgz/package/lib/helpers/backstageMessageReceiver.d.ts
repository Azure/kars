/**
 * getBackstageToken gets the backstage token from the local storage
 *
 * @returns the backstage token
 */
export declare function getBackstageToken(): string | null;
/**
 * setupBackstageMessageReceiver sets up a listener for messages from the backstage app
 * and sets the backend token if it is received
 *
 * @returns void
 */
export declare function setupBackstageMessageReceiver(): void;
