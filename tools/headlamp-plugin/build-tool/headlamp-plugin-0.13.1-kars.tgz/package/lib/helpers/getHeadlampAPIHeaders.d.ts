/**
 * Sets the backend token to use when making API calls from Headlamp when running as an app.
 *
 * This is not a K8s or OIDC token, but one that protects headlamp-server APIs.
 */
export declare function setBackendToken(token: string | null): void;
/**
 * Returns headers for making API calls to the headlamp-server backend.
 */
export declare function getHeadlampAPIHeaders(): {
    [key: string]: string;
};
