/**
 * isBackstage checks if Headlamp is running in a backstage app
 *
 * @returns true if Headlamp is running in a backstage app
 */
export declare function isBackstage(): boolean;
