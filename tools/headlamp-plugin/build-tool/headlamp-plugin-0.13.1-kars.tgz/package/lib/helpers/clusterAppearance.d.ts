/**
 * Sanitized per-cluster UI settings extracted from localStorage.
 */
export interface ClusterAppearance {
    accentColor?: string;
    icon?: string;
}
/**
 * Returns whether a color string matches hex, rgb(), or rgba() formats.
 *
 * @param color - CSS color string to validate.
 * @returns {boolean} True if the color is valid; otherwise false.
 */
export declare function isValidCssColor(color: string): boolean;
/**
 * Coerces to a valid CSS color or returns undefined if invalid.
 *
 * @param color - Candidate color value (string or other).
 * @returns {string | undefined} The valid color or undefined if invalid.
 */
export declare function sanitizeCssColor(color: unknown): string | undefined;
/**
 * Extracts and sanitizes appearance fields from localStorage for a given cluster.
 *
 * @param clusterName - The cluster name. If not provided, uses the current cluster from getCluster().
 * @returns {ClusterAppearance} Sanitized per-cluster appearance settings from localStorage.
 */
export declare function getClusterAppearanceFromMeta(clusterName?: string | null): ClusterAppearance;
