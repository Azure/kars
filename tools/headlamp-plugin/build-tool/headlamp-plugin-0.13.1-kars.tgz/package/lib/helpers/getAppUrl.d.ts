declare global {
    interface Window {
        /**
         * headlampBackendPort is set by Electron to specify the backend server port.
         * It allows the frontend to connect to the backend on a configurable port.
         */
        headlampBackendPort?: number;
    }
}
/**
 * @returns URL depending on dev-mode/electron/docker desktop, base-url, and window.location.origin.
 *
 * @example isDevMode | isElectron returns 'http://localhost:4466/'
 * @example isDockerDesktop returns 'http://localhost:64446/'
 * @example base-url set as '/headlamp' returns '/headlamp/'
 * @example isDevMode | isElectron and base-url is set
 *          it returns 'http://localhost:4466/headlamp/'
 * @example returns 'https://headlamp.example.com/'using the window.location.origin of browser
 *
 */
export declare function getAppUrl(): string;
