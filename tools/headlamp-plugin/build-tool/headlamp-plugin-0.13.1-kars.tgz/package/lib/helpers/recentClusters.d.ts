import { Cluster } from '../lib/k8s/cluster';
/**
 * Adds the cluster name to the list of recent clusters in localStorage.
 *
 * @param cluster - the cluster to add to the list of recent clusters. Can be the name, or a Cluster object.
 * @returns void
 */
export declare function setRecentCluster(cluster: string | Cluster): void;
/**
 * @returns the list of recent clusters from localStorage.
 */
export declare function getRecentClusters(): string[];
