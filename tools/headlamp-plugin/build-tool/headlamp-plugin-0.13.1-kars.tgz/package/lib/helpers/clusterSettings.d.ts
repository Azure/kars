/**
 * ClusterSettings defines the structure of the cluster settings object.
 */
export interface ClusterSettings {
    /** Optional default namespace to be used */
    defaultNamespace?: string;
    /** Only allow namespaces in this list to be selected */
    allowedNamespaces?: string[];
    /** This is a custom cluster name. If it is '' it is the actual cluster name. */
    currentName?: string;
    nodeShellTerminal?: {
        linuxImage?: string;
        namespace?: string;
        isEnabled?: boolean;
    };
    podDebugTerminal?: {
        debugImage?: string;
        isEnabled?: boolean;
    };
    /** Cluster appearance settings stored in localStorage */
    appearance?: {
        accentColor?: string;
        icon?: string;
    };
}
export declare const DEFAULT_NODE_SHELL_LINUX_IMAGE = "docker.io/library/busybox:latest";
export declare const DEFAULT_NODE_SHELL_NAMESPACE = "default";
export declare const DEFAULT_POD_DEBUG_IMAGE = "docker.io/library/busybox:latest";
/**
 * Stores the cluster settings in local storage.
 *
 * @param clusterName - The name of the cluster.
 * @param settings - The cluster settings to be stored.
 * @returns {void}
 */
export declare function storeClusterSettings(clusterName: string, settings: ClusterSettings): void;
/**
 * Loads the cluster settings from local storage.
 *
 * @param clusterName - The name of the cluster.
 * @returns {ClusterSettings} - The cluster settings.
 */
export declare function loadClusterSettings(clusterName: string): ClusterSettings;
