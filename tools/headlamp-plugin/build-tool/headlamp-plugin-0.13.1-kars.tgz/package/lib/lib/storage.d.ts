export declare function getSavedNamespaces(cluster?: string): string[];
export declare function saveNamespaces(namespaces: string[], cluster?: string): void;
