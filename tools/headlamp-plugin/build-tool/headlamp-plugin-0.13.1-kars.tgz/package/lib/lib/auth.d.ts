/**
 * Retrieves the authentication token for a given cluster.
 * If a custom getToken method is defined in the Redux store, it will be used.
 * Otherwise, the token is retrieved from local storage.
 *
 * Important! This will only work if plugins have overriden getToken function!
 * By default tokens are stored in httpOnly cookies and not available from JS
 *
 * @param cluster - The name of the cluster.
 * @returns The authentication token for the specified cluster, or undefined if not set.
 */
export declare function getToken(cluster: string): string | undefined;
/**
 * Retrieves the user information encoded in the authentication token for a given cluster.
 *
 * Important! This will only work if plugins have overriden getToken function!
 * By default tokens are stored in httpOnly cookies and not available from JS
 *
 * @param cluster - The name of the cluster.
 * @returns The decoded user information from the token's payload.
 */
export declare function getUserInfo(cluster: string): any;
/**
 * Checks whether an authentication token exists for the given cluster.
 *
 * Important! This will only work if plugins have overriden getToken function!
 * By default tokens are stored in httpOnly cookies and not available from JS
 *
 * @param cluster - The name of the cluster.
 * @returns True if a token exists, false otherwise.
 */
export declare function hasToken(cluster: string): boolean;
/**
 * Sets or updates the token for a given cluster using cookie-based storage.
 * The token is stored securely in an HttpOnly cookie on the backend.
 *
 * @param cluster - The name of the cluster.
 * @param token - The authentication token to set. Pass null to clear the token.
 * @throws {Error} When cluster name is invalid or backend request fails
 */
export declare function setToken(cluster: string, token: string | null): Promise<void> | Promise<boolean>;
/**
 * Logs out the user by clearing the authentication token for the specified cluster.
 *
 * @param cluster - The name of the cluster to log out from.
 * @throws {Error} When logout request fails
 */
export declare function logout(cluster: string): Promise<void>;
/**
 * Deletes all stored authentication tokens
 *
 * @returns {void}
 */
export declare function deleteTokens(): Promise<void[]>;
