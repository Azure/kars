/**
 * @returns A path prefixed with cluster path, and the given path.
 *
 * The given path does not start with a /, it will be added.
 */
export declare function getClusterPrefixedPath(path?: string | null): string;
/**
 * Get the currently selected cluster name.
 *
 * If more than one cluster is selected it will return:
 *  - On details pages: the cluster of the currently viewed resource
 *  - On any other page: one of the selected clusters
 *
 * To get all currently selected clusters please use {@link getSelectedClusters}
 *
 * @returns The current cluster name, or null if not in a cluster context.
 */
export declare function getCluster(urlPath?: string): string | null;
/** Returns cluster URL parameter from the current path or the given path */
export declare function getClusterPathParam(maybeUrlPath?: string): string | undefined;
/**
 * Format cluster path URL parameter
 *
 * Cluster parameter contains selected clusters, with the first one being the current one
 * usually used for details pages.
 *
 * @param selectedClusters - list of all selected clusters
 * @param currentCluster - (optional) cluster name of the current cluster
 * @returns formatted cluster parameter
 */
export declare const formatClusterPathParam: (selectedClusters: string[], currentCluster?: string) => string;
/**
 * Gets clusters.
 *
 * @param returnWhenNoClusters return this value when no clusters are found.
 * @returns the cluster group from the URL.
 */
export declare function getClusterGroup(returnWhenNoClusters?: string[]): string[];
/**
 * Get list of selected clusters.
 *
 * @param returnWhenNoClusters return this value when no clusters are found.
 * @param urlPath optional, path string containing cluster parameters.
 * @returns the cluster group from the URL.
 */
export declare function getSelectedClusters(returnWhenNoClusters?: string[], urlPath?: string): string[];
