import type { AppStore } from '../../redux/stores/store';
export interface RouteURLProps {
    /**
     * Selected clusters path parameter
     *
     * Check out {@link getClusterPathParam} and {@link formatClusterPathParam} function
     * for working with this parameter
     */
    cluster?: string;
    [prop: string]: any;
}
/**
 * This is so we can access the store from anywhere, but not import it directly.
 * @param newStore
 */
export declare function setStore(newStore: AppStore): void;
export declare function createRouteURL(routeName?: string, params?: RouteURLProps): string;
