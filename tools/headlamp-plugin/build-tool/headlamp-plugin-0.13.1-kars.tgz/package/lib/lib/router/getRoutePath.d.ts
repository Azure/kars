import type { Route } from './Route';
export declare function getRoutePath(route: Route): string;
