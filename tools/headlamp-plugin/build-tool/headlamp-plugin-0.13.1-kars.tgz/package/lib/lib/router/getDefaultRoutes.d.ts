import type { Route } from './Route';
export declare function getDefaultRoutes(): {
    [routeName: string]: Route;
};
export declare function setDefaultRoutes(routes: {
    [routeName: string]: Route;
}): void;
