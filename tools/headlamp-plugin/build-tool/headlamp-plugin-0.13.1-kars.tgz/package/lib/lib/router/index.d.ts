import type { RouteURLProps } from './createRouteURL';
import { createRouteURL } from './createRouteURL';
import { getDefaultRoutes } from './getDefaultRoutes';
import { getRoute } from './getRoute';
import { getRoutePath } from './getRoutePath';
import { getRouteUseClusterURL } from './getRouteUseClusterURL';
import { Route } from './Route';
export type { Route, RouteURLProps };
export { getDefaultRoutes, getRouteUseClusterURL, getRoutePath, getRoute, createRouteURL };
export declare const NotFoundRoute: {
    path: string;
    exact: boolean;
    name: string;
    component: () => import("react/jsx-runtime").JSX.Element;
    sidebar: null;
    noAuthRequired: boolean;
};
