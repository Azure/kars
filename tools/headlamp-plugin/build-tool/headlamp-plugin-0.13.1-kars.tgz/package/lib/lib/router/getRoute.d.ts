export declare function getRoute(routeName?: string): import("./Route").Route | undefined;
