import type { AppTheme } from './AppTheme';
declare module '@mui/material/styles/createPalette.d' {
    interface Palette {
        success: PaletteColor;
        background: TypeBackground;
        sidebar: {
            background: string;
            color: string;
            selectedBackground: string;
            selectedColor: string;
            actionBackground: string;
        };
        navbar: {
            background: string;
            color: string;
        };
        [propName: string]: any;
    }
    interface PaletteOptions {
        success?: PaletteColorOptions;
        [propName: string]: any;
    }
    interface TypeBackground {
        default: string;
        paper: string;
        muted: string;
    }
}
/** Check whether navbar should use light or dark mode based on the background */
export declare const useNavBarMode: () => "light" | "dark";
/**
 * Creates a Material UI theme from our own simple theme definition
 */
export declare function createMuiTheme(currentTheme: AppTheme): import("@mui/material/styles").Theme;
export declare function usePrefersColorScheme(): boolean | "light";
/**
 * Hook gets theme based on user preference, and also OS/Browser preference.
 */
export declare function getThemeName(): string;
export declare function setTheme(themeName: string): void;
