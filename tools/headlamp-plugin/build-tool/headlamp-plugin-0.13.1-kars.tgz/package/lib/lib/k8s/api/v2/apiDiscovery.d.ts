import type { ApiResource } from './ApiResource';
/**
 * Discovers available API resources from Kubernetes clusters.
 * - Only resources that support the 'list' verb are included in the results
 *
 * @param clusters - An array of cluster names to discover API resources from
 * @returns list of API resources
 *
 */
export declare function apiDiscovery(clusters: string[]): Promise<ApiResource[]>;
