import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
type ResourceName = 'cpu' | 'memory' | 'storage' | 'ephemeral-storage';
type UpdateMode = 'Off' | 'Initial' | 'Auto' | 'Recreate';
type EvictionChangeRequirement = 'TargetHigherThanRequests' | 'TargetLowerThanRequests';
interface VpaSpec {
    targetRef: {
        apiVersion: string;
        kind: string;
        name: string;
        namespace?: string;
    };
    updatePolicy?: {
        updateMode: UpdateMode;
        minReplicas?: number;
        evictionRequirements?: {
            resources: {
                resourceName: ResourceName;
            }[];
            changeRequirement: EvictionChangeRequirement;
        }[];
    };
    resourcePolicy?: {
        containerPolicies: {
            containerName: string;
            mode?: UpdateMode;
            minAllowed?: {};
            maxAllowed?: {};
            controlledResources?: ResourceName[];
            controlledValues?: 'RequestsAndLimits' | 'RequestsOnly';
        }[];
    };
    recommenders?: {
        name: string;
    }[];
}
interface VpaStatus {
    conditions: VpaCondition[];
    recommendation?: VpaRecommendation;
}
interface VpaCondition {
    type: string;
    status: string;
    lastTransitionTime: string;
    reason?: string;
    message?: string;
}
interface RecommendationValue {
    cpu?: string;
    memory?: string;
    storage?: string;
    ephemeralStorage?: string;
}
interface VpaRecommendation {
    containerRecommendations: {
        containerName: string;
        lowerBound: RecommendationValue;
        target: RecommendationValue;
        uncappedTarget: RecommendationValue;
        upperBound: RecommendationValue;
    }[];
}
export interface KubeVPA extends KubeObjectInterface {
    spec: VpaSpec;
    status: VpaStatus;
}
declare class VPA extends KubeObject<KubeVPA> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeVPA;
    static isEnabled(): Promise<boolean>;
    get spec(): VpaSpec;
    get status(): VpaStatus;
    get referenceObject(): KubeObject | null;
    get targetRecommendations(): RecommendationValue | null | undefined;
}
export default VPA;
