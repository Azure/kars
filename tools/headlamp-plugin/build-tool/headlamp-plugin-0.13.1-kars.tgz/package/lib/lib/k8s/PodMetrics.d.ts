import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
interface KubePodMetrics extends KubeObjectInterface {
    timestamp: string;
    window: string;
    containers: Array<{
        name: string;
        usage: {
            cpu: string;
            memory: string;
        };
    }>;
}
export declare const METRIC_REFETCH_INTERVAL_MS = 5000;
export declare class PodMetrics extends KubeObject<KubePodMetrics> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
}
export {};
