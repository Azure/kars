import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
interface LegacyIngressRule {
    host: string;
    http: {
        paths: {
            path: string;
            backend: LegacyIngressBackend;
        }[];
    };
}
export interface IngressRule {
    host: string;
    http?: {
        paths: {
            path: string;
            pathType?: string;
            backend: IngressBackend;
        }[];
    };
}
interface LegacyIngressBackend {
    serviceName: string;
    servicePort: string;
}
export interface IngressBackend {
    service?: {
        name: string;
        port: {
            number?: number;
            name?: string;
        };
    };
    resource?: {
        apiVersion: string;
        kind: string;
        name: string;
    };
}
export interface KubeIngress extends KubeObjectInterface {
    spec: {
        ingressClassName?: string;
        rules?: IngressRule[] | LegacyIngressRule[];
        tls?: {
            hosts: string[];
            secretName: string;
        }[];
        defaultBackend?: {
            resource?: {
                apiVersion: string;
                kind: string;
                name: string;
            };
            service?: {
                name: string;
                port: {
                    name?: string;
                    number?: number;
                };
            };
        };
        [key: string]: any;
    };
}
declare class Ingress extends KubeObject<KubeIngress> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    static getBaseObject(): KubeIngress;
    private cachedRules;
    get spec(): KubeIngress['spec'];
    getHosts(): string | undefined;
    getRules(): IngressRule[];
}
export default Ingress;
