import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubePDB extends KubeObjectInterface {
    spec: {
        selector: {
            matchLabels: {
                [key: string]: string;
            };
            matchExpressions?: {
                key: string;
                operator: string;
                values: string[];
            };
        };
        minAvailable?: number;
        maxUnavailable?: number;
    };
    status: {
        currentHealthy: number;
        desiredHealthy: number;
        disruptionsAllowed: number;
        expectedPods: number;
        observedGeneration: number;
        disruptedPods?: {
            [key: string]: string;
        };
        conditions: {
            type: string;
            status: string;
            reason: string;
            observedGeneration: number;
            message: string;
            lastTransitionTime: string;
        }[];
    };
}
declare class PDB extends KubeObject<KubePDB> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubePDB;
    get spec(): KubePDB['spec'];
    get status(): KubePDB['status'];
    get selectors(): string[];
}
export default PDB;
