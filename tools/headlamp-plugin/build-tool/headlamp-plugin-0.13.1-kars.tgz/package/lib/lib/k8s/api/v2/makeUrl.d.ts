/**
 * Formats URL path
 *
 * @example
 * ```ts
 * makeUrl(["my", "path", 5], { name: "hello" })
 * // returns "/my/path/5?name=hello"
 * ```
 *
 * @param urlParts - parts of the path, will be separated by /
 * @param query - query parameters object
 *
 * @returns Formatted URL path
 */
export declare function makeUrl(urlParts: any[] | string, query?: Record<string, any>): string;
