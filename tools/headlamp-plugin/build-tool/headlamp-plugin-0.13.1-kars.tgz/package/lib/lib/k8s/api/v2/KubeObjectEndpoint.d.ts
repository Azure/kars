export interface KubeObjectEndpoint {
    group?: string;
    version: string;
    resource: string;
}
export declare const KubeObjectEndpoint: {
    /**
     * Formats endpoints information into a URL path
     *
     * @param endpoint - Kubernetes resource endpoint definition
     * @param namespace - Namespace, optional
     * @returns Formatted URL path
     */
    toUrl: ({ group, version, resource }: KubeObjectEndpoint, namespace?: string) => string;
};
