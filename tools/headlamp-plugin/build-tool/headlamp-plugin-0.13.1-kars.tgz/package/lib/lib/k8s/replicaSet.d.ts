import type { KubeCondition, KubeContainer, LabelSelector } from './cluster';
import type { KubeMetadata } from './KubeMetadata';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
import type { KubePodSpec } from './pod';
export interface KubeReplicaSet extends KubeObjectInterface {
    spec: {
        minReadySeconds: number;
        replicas: number;
        selector: LabelSelector;
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
        [other: string]: any;
    };
    status: {
        availableReplicas: number;
        conditions: Omit<KubeCondition, 'lastProbeTime' | 'lastUpdateTime'>[];
        fullyLabeledReplicas: number;
        observedGeneration: number;
        readyReplicas: number;
        replicas: number;
    };
}
declare class ReplicaSet extends KubeObject<KubeReplicaSet> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static isScalable: boolean;
    get spec(): KubeReplicaSet['spec'];
    get status(): KubeReplicaSet['status'];
    static getBaseObject(): KubeReplicaSet;
    getContainers(): KubeContainer[];
    getMatchLabelsList(): string[];
}
export default ReplicaSet;
