import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubePersistentVolumeClaim extends KubeObjectInterface {
    spec?: {
        accessModes?: string[];
        resources?: {
            limits?: object;
            requests: {
                storage?: string;
                [other: string]: any;
            };
        };
        storageClassName?: string;
        volumeMode?: string;
        volumeName?: string;
        [other: string]: any;
    };
    status?: {
        capacity?: {
            storage?: string;
        };
        phase?: string;
        accessModes?: string[];
        [other: string]: any;
    };
}
declare class PersistentVolumeClaim extends KubeObject<KubePersistentVolumeClaim> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubePersistentVolumeClaim;
    get spec(): {
        [other: string]: any;
        accessModes?: string[];
        resources?: {
            limits?: object;
            requests: {
                storage?: string;
                [other: string]: any;
            };
        };
        storageClassName?: string;
        volumeMode?: string;
        volumeName?: string;
    } | undefined;
    get status(): {
        [other: string]: any;
        capacity?: {
            storage?: string;
        };
        phase?: string;
        accessModes?: string[];
    } | undefined;
}
export default PersistentVolumeClaim;
