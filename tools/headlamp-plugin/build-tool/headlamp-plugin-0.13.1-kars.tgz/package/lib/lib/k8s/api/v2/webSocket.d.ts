/**
 * Get the WebSocket base URL dynamically to support runtime port configuration
 */
export declare function getBaseWsUrl(): string;
export declare const BASE_WS_URL: string;
/**
 * Configuration for establishing a WebSocket connection to watch Kubernetes resources.
 * Used by the multiplexer to manage multiple WebSocket connections efficiently.
 *
 * @template T The expected type of data that will be received over the WebSocket
 */
export type WebSocketConnectionRequest<T> = {
    /**
     * The Kubernetes cluster identifier to connect to.
     * Used for routing WebSocket messages in multi-cluster environments.
     */
    cluster: string;
    /**
     * The WebSocket endpoint URL to connect to.
     * Should be a full URL including protocol and any query parameters.
     * Example: 'https://cluster.example.com/api/v1/pods/watch'
     */
    url: string;
    /**
     * Callback function that handles incoming messages from the WebSocket.
     * @param data The message payload, typed as T (e.g., K8s Pod, Service, etc.)
     */
    onMessage: (data: T) => void;
};
/**
 * Create new WebSocket connection to the backend
 *
 * @param url - WebSocket URL
 * @param options - Connection options
 *
 * @returns WebSocket connection
 */
export declare function openWebSocket<T>(url: string, { protocols: moreProtocols, type, cluster, onMessage, }: {
    /**
     * Any additional protocols to include in WebSocket connection
     */
    protocols?: string | string[];
    /**
     *
     */
    type: 'json' | 'binary';
    /**
     * Cluster name
     */
    cluster?: string;
    /**
     * Message callback
     */
    onMessage: (data: T) => void;
}): Promise<WebSocket>;
/**
 * Creates or joins mutiple existing WebSocket connections
 *
 * @param url - endpoint URL
 * @param options - WebSocket options
 */
export declare function useWebSockets<T>({ connections, enabled, protocols, type, }: {
    enabled?: boolean;
    /** Make sure that connections value is stable between renders */
    connections: Array<WebSocketConnectionRequest<T>>;
    /**
     * Any additional protocols to include in WebSocket connection
     * make sure that the value is stable between renders
     */
    protocols?: string | string[];
    /**
     * Type of websocket data
     */
    type?: 'json' | 'binary';
}): void;
