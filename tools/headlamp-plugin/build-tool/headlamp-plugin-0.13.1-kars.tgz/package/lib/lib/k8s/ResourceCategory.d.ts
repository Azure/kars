import { type KubeObject } from './KubeObject';
/**
 * User friendly alternative to Kubernetes API groups
 *
 * Combines multiple API groups along some resources from core (legacy) group
 * into one entity with a useful label.
 */
export interface ResourceCategory {
    label: string;
    /** MDI icon */
    icon: string;
    /** Description of the group */
    description: string;
    /** Which api groups are included */
    apiGroups?: string[];
    /** Which kinds from core api group are included */
    coreKinds?: string[];
    /** Ignore certain kinds from the groups */
    excludeKinds?: string[];
}
export declare const categoriesConfig: ResourceCategory[];
/**
 * Get category of the given kubernetes object
 *
 * @param resource Kubernetes object
 * @returns resource category
 */
export declare const getKubeObjectCategory: (resource: KubeObject) => ResourceCategory;
