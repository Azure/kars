import { KubeObject, type KubeObjectInterface } from './KubeObject';
export interface CrossVersionObjectReference {
    apiVersion: string;
    kind: string;
    name: string;
}
interface MetricIdentifier {
    name: string;
    selector: {
        matchLabels: {
            [key: string]: string;
        };
        matchExpressions: {
            key: string;
            operator: string;
            values: string[];
        };
    };
}
interface MetricValueStatus {
    averageUtilization?: number;
    averageValue?: string;
    value?: string;
}
interface MetricTarget {
    type: MetricType;
    averageUtilization?: number;
    averageValue?: string;
    value?: string;
}
type MetricType = 'Utilization' | 'Value' | 'AverageValue';
type MetricSourceType = 'Resource' | 'Pods' | 'Object' | 'External' | 'ContainerResource';
interface HpaSpec {
    maxReplicas: number;
    minReplicas: number;
    targetCPUUtilizationPercentage?: number;
    scaleTargetRef: CrossVersionObjectReference;
    metrics: {
        external?: {
            metric: MetricIdentifier;
            target: MetricTarget;
        };
        object?: {
            metric: MetricIdentifier;
            describedObject: CrossVersionObjectReference;
            target: MetricTarget;
        };
        pods?: {
            metric: MetricIdentifier;
            target: MetricTarget;
        };
        resource?: {
            name: string;
            target: MetricTarget;
        };
        containerResource?: {
            container: string;
            name: string;
            target: MetricTarget;
        };
        type: MetricSourceType;
    }[];
}
interface HpaStatus {
    currentCPUUtilizationPercentage?: number;
    currentReplicas: number;
    desiredReplicas: number;
    lastScaleTime: string;
    observedGeneration?: number;
    currentMetrics: {
        type: string;
        external?: {
            current: MetricValueStatus;
            metric: MetricIdentifier;
        };
        object?: {
            current: MetricValueStatus;
            metric: MetricIdentifier;
            desiredObject: CrossVersionObjectReference;
        };
        pods?: {
            current: MetricValueStatus;
            metric: MetricIdentifier;
        };
        resource?: {
            name: string;
            current: MetricValueStatus;
        };
        containerResource?: {
            container: string;
            name: string;
            current: MetricValueStatus;
        };
    }[] | null;
    conditions: {
        type: string;
        status: string;
        lastTransitionTime: string;
        reason: string;
        message: string;
    }[];
}
export interface KubeHPA extends KubeObjectInterface {
    spec: HpaSpec;
    status: HpaStatus;
}
interface HPAMetrics {
    name: string;
    definition: string;
    value: string;
    shortValue: string;
}
declare class HPA extends KubeObject<KubeHPA> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeHPA;
    get spec(): HpaSpec;
    get status(): HpaStatus;
    metrics(t: Function): HPAMetrics[];
    get referenceObject(): KubeObject | null;
}
export default HPA;
