import { KubeObject, type KubeObjectInterface } from './KubeObject';
/**
 * BackendTLSPolicyTargetRef defines the target resource (e.g., Service) for the TLS policy.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/backendtlspolicy/#structure}
 */
export interface BackendTLSPolicyTargetRef {
    group: string;
    kind: string;
    name: string;
    sectionName?: string;
}
/**
 * BackendTLSPolicyValidation defines TLS validation settings such as trusted CA and SAN.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/backendtlspolicy/#structure}
 */
export interface BackendTLSPolicyValidation {
    caCertificateRefs: {
        group: string;
        kind: string;
        name: string;
    }[];
    hostname: string;
}
/**
 * BackendTLSPolicySpec defines the policy spec.
 */
export interface BackendTLSPolicySpec {
    targetRefs: BackendTLSPolicyTargetRef[];
    validation: BackendTLSPolicyValidation;
    [key: string]: any;
}
/**
 * BackendTLSPolicy is a Gateway API type that enforces TLS connections from the gateway to the backend.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/backendtlspolicy/}
 */
export interface KubeBackendTLSPolicy extends KubeObjectInterface {
    spec: BackendTLSPolicySpec;
}
declare class BackendTLSPolicy extends KubeObject<KubeBackendTLSPolicy> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): BackendTLSPolicySpec;
    get targetRefs(): BackendTLSPolicyTargetRef[];
    get validation(): BackendTLSPolicyValidation;
    static get pluralName(): string;
}
export default BackendTLSPolicy;
