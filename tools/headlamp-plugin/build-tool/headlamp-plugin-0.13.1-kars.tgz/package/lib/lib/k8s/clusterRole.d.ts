import { KubeObject } from './KubeObject';
import type { KubeRole } from './role';
declare class ClusterRole extends KubeObject<KubeRole> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get rules(): {
        apiGroups: string[];
        nonResourceURLs: string[];
        resourceNames: string[];
        resources: string[];
        verbs: string[];
    }[];
}
export default ClusterRole;
