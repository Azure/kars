import type { QueryParameters } from './api/v1/queryParameters';
import type { ApiError } from './api/v2/ApiError';
import type { KubeMetadata } from './KubeMetadata';
import { KubeObject } from './KubeObject';
export interface KubeEvent {
    type: string;
    reason: string;
    message: string;
    metadata: KubeMetadata;
    involvedObject: {
        kind: string;
        namespace: string;
        name: string;
        uid: string;
        apiVersion: string;
        resourceVersion: string;
        fieldPath: string;
    };
    [otherProps: string]: any;
}
declare class Event extends KubeObject<KubeEvent> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    private static maxEventsLimit;
    static get maxLimit(): number;
    static set maxLimit(limit: number);
    get spec(): any;
    get status(): any;
    get involvedObject(): any;
    get type(): any;
    get reason(): any;
    get message(): any;
    get source(): any;
    get count(): any;
    get lastOccurrence(): any;
    get firstOccurrence(): any;
    static objectEvents(object: KubeObject): Promise<any>;
    get involvedObjectInstance(): KubeObject | null;
    /**
     * Fetch events for given clusters
     *
     * Important! Make sure to have the parent component have clusters as a key
     * so that component remounts when clusters change, instead of rerendering
     * with different number of clusters
     */
    static useListForClusters(clusterNames: string[], options?: {
        queryParams?: QueryParameters;
    }): {
        [cluster: string]: {
            warnings: Event[];
            error?: ApiError | null;
        };
    };
    /**
     * Fetch warning events for given clusters
     * Amount is limited to {@link Event.maxEventsLimit}
     *
     * Important! Make sure to have the parent component have clusters as a key
     * so that component remounts when clusters change, instead of rerendering
     * with different number of clusters
     */
    static useWarningList(clusters: string[], options?: {
        queryParams?: QueryParameters;
    }): {
        [cluster: string]: {
            warnings: Event[];
            error?: ApiError | null;
        };
    };
}
export default Event;
