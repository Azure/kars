import type { StringDict } from './cluster';
import { KubeObject, type KubeObjectInterface } from './KubeObject';
export interface KubeConfigMap extends KubeObjectInterface {
    data: StringDict;
}
declare class ConfigMap extends KubeObject<KubeConfigMap> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get data(): StringDict;
    static getBaseObject(): KubeConfigMap;
}
export default ConfigMap;
