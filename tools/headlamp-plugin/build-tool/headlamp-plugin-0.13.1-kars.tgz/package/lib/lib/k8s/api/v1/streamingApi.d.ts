import type { KubeObjectInterface } from '../../KubeObject';
import type { QueryParameters } from './queryParameters';
export type StreamUpdate<T = any> = {
    type: 'ADDED' | 'MODIFIED' | 'DELETED' | 'ERROR';
    object: T;
};
export type StreamResultsCb<T = any> = (data: T) => void;
export type StreamUpdatesCb<T = any> = (data: T | StreamUpdate<T>) => void;
export type StreamErrCb = (err: Error & {
    status?: number;
}, cancelStreamFunc?: () => void) => void;
/**
 * Fetches the data and watches for changes to the data.
 *
 * @param url - The URL of the Kubernetes API endpoint.
 * @param name - The name of the Kubernetes API resource.
 * @param cb - The callback function to execute when the stream receives data.
 * @param errCb - The callback function to execute when an error occurs.
 * @param queryParams - The query parameters to include in the API request.
 *
 * @returns A function to cancel the stream.
 */
export declare function streamResult<T extends KubeObjectInterface>(url: string, name: string, cb: StreamResultsCb<T>, errCb: StreamErrCb, queryParams?: QueryParameters, cluster?: string): Promise<() => void>;
/**
 * Streams the results of a Kubernetes API request.
 *
 * @param url - The URL of the Kubernetes API endpoint.
 * @param cb - The callback function to execute when the stream receives data.
 * @param errCb - The callback function to execute when an error occurs.
 * @param queryParams - The query parameters to include in the API request.
 *
 * @returns A function to cancel the stream.
 */
export declare function streamResults<T extends KubeObjectInterface>(url: string, cb: StreamResultsCb<T>, errCb: StreamErrCb, queryParams: QueryParameters | undefined): Promise<() => void>;
export interface StreamResultsParams {
    cb: StreamResultsCb;
    errCb: StreamErrCb;
    cluster?: string;
}
export declare function streamResultsForCluster(url: string, params: StreamResultsParams, queryParams?: QueryParameters): Promise<() => void>;
/**
 * Configure a stream with... StreamArgs.
 */
export interface StreamArgs {
    /** Whether the stream is expected to receive JSON data. */
    isJson?: boolean;
    /** Additional WebSocket protocols to use when connecting. */
    additionalProtocols?: string[];
    /** A callback function to execute when the WebSocket connection is established. */
    connectCb?: () => void;
    /** Whether to attempt to reconnect the WebSocket connection if it fails. */
    reconnectOnFailure?: boolean;
    /** A callback function to execute when the WebSocket connection fails. */
    failCb?: () => void;
    tty?: boolean;
    stdin?: boolean;
    stdout?: boolean;
    stderr?: boolean;
    cluster?: string;
}
/**
 * Establishes a WebSocket connection to the specified URL and streams the results
 * to the provided callback function.
 *
 * @param url - The URL to connect to.
 * @param cb - The callback function to receive the streamed results.
 * @param args - Additional arguments to configure the stream.
 *
 * @returns An object with two functions: `cancel`, which can be called to cancel
 * the stream, and `getSocket`, which returns the WebSocket object.
 */
export declare function stream<T>(url: string, cb: StreamResultsCb<T>, args: StreamArgs): {
    cancel: () => void;
    getSocket: () => WebSocket | null;
};
/**
 * Connects to a WebSocket stream at the specified path and returns an object
 * with a `close` function and a `socket` property. Sends messages to `cb` callback.
 *
 * @param path - The path of the WebSocket stream to connect to.
 * @param cb - The function to call with each message received from the stream.
 * @param onFail - The function to call if the stream is closed unexpectedly.
 * @param isJson - Whether the messages should be parsed as JSON.
 * @param additionalProtocols - An optional array of additional WebSocket protocols to use.
 *
 * @returns An object with a `close` function and a `socket` property.
 */
export declare function connectStream<T>(path: string, cb: StreamResultsCb<T>, onFail: () => void, isJson: boolean, additionalProtocols?: string[], cluster?: string): Promise<{
    close: () => void;
    socket: WebSocket | null;
}>;
interface StreamParams {
    cluster?: string;
    isJson?: boolean;
    additionalProtocols?: string[];
}
/**
 * connectStreamWithParams is a wrapper around connectStream that allows for more
 * flexibility in the parameters that can be passed to the WebSocket connection.
 *
 * This is an async function because it may need to fetch the kubeconfig for the
 * cluster if the cluster is specified in the params. If kubeconfig is found, it
 * sends the X-HEADLAMP-USER-ID header with the user ID from the localStorage.
 * It is sent as a base64url encoded string in protocal format:
 * `base64url.headlamp.authorization.k8s.io.${userID}`.
 *
 * @param path - The path of the WebSocket stream to connect to.
 * @param cb - The function to call with each message received from the stream.
 * @param onFail - The function to call if the stream is closed unexpectedly.
 * @param params - Stream parameters to configure the connection.
 *
 * @returns A promise that resolves to an object with a `close` function and a `socket` property.
 */
export declare function connectStreamWithParams<T>(path: string, cb: StreamResultsCb<T>, onFail: () => void, params?: StreamParams): Promise<{
    close: () => void;
    socket: WebSocket | null;
}>;
export {};
