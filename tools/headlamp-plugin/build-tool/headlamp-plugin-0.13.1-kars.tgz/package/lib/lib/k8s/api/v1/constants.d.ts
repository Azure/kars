export declare const BASE_HTTP_URL: string;
export declare const CLUSTERS_PREFIX = "clusters";
export declare const JSON_HEADERS: {
    Accept: string;
    'Content-Type': string;
};
export declare const DEFAULT_TIMEOUT: number;
export declare const MIN_LIFESPAN_FOR_TOKEN_REFRESH = 10;
