import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeRole extends KubeObjectInterface {
    rules: {
        apiGroups: string[];
        nonResourceURLs: string[];
        resourceNames: string[];
        resources: string[];
        verbs: string[];
    }[];
}
declare class Role extends KubeObject<KubeRole> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get rules(): {
        apiGroups: string[];
        nonResourceURLs: string[];
        resourceNames: string[];
        resources: string[];
        verbs: string[];
    }[];
}
export default Role;
