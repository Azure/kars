import { KubeMetadata } from './KubeMetadata';
import { KubeObject, KubeObjectInterface } from './KubeObject';
export interface KubeEndpointSliceEndpointConditions {
    ready: boolean;
    serving: boolean;
    terminating: boolean;
}
export interface KubeEndpointSliceEndpoint {
    addresses: string[];
    hostname: string;
    nodeName?: string;
    conditions?: KubeEndpointSliceEndpointConditions;
    zone?: string;
    targetRef?: Pick<KubeObjectInterface, 'apiVersion' | 'kind'> & Pick<KubeMetadata, 'name' | 'namespace' | 'resourceVersion' | 'uid'> & {
        fieldPath: string;
    };
}
export interface KubeEndpointSlicePort {
    name?: string;
    port: number;
    protocol: string;
    appProtocol?: string;
}
export interface KubeEndpointSlice extends KubeObjectInterface {
    addressType?: string;
    ports?: KubeEndpointSlicePort[];
    endpoints?: KubeEndpointSliceEndpoint[];
}
declare class EndpointSlice extends KubeObject<KubeEndpointSlice> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeEndpointSlice;
    get spec(): KubeEndpointSlice;
    get ports(): number[];
    getOwnerServiceName(): string | undefined;
}
export default EndpointSlice;
