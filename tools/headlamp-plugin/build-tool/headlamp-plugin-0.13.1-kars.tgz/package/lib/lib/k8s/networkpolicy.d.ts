import type { LabelSelector } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface NetworkPolicyPort {
    port?: string | number;
    protocol?: string;
    endPort?: number;
}
export interface IPBlock {
    cidr: string;
    except: string[];
}
export interface NetworkPolicyPeer {
    ipBlock?: IPBlock;
    namespaceSelector?: LabelSelector;
    podSelector?: LabelSelector;
}
export interface NetworkPolicyEgressRule {
    ports: NetworkPolicyPort[];
    to: NetworkPolicyPeer[];
}
export interface NetworkPolicyIngressRule {
    ports: NetworkPolicyPort[];
    from: NetworkPolicyPeer[];
}
export interface KubeNetworkPolicy extends KubeObjectInterface {
    egress: NetworkPolicyEgressRule[];
    ingress: NetworkPolicyIngressRule[];
    podSelector: LabelSelector;
    policyTypes: string[];
}
declare class NetworkPolicy extends KubeObject<KubeNetworkPolicy> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeNetworkPolicy;
    static get pluralName(): string;
}
export default NetworkPolicy;
