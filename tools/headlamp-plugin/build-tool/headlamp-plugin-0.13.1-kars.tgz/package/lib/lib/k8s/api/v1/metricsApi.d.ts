import type { KubeMetrics } from '../../cluster';
import type { ApiError } from '../v2/ApiError';
/**
 * Gets the metrics for the specified resource. Gets new metrics every 10 seconds.
 *
 * @param url - The url of the resource to get metrics for.
 * @param onMetrics - The function to call with the metrics.
 * @param onError - The function to call if there's an error.
 * @param cluster - The cluster to get metrics for. By default uses the current cluster (URL defined).
 *
 * @returns A function to cancel the metrics request.
 */
export declare function metrics(url: string, onMetrics: (arg: KubeMetrics[]) => void, onError?: (err: ApiError) => void, cluster?: string): Promise<() => void>;
