import type { KubeObjectClass, KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeCRD extends KubeObjectInterface {
    spec: {
        group: string;
        version: string;
        names: {
            plural: string;
            singular: string;
            kind: string;
            listKind: string;
            categories?: string[];
        };
        versions: {
            name: string;
            served: boolean;
            storage: boolean;
            additionalPrinterColumns: {
                name: string;
                type: string;
                jsonPath: string;
                description?: string;
                priority?: number;
                format?: string;
            }[];
        }[];
        scope: string;
        [other: string]: any;
    };
    status?: {
        acceptedNames?: {
            kind: string;
            plural: string;
            shortNames: string[];
            categories?: string[];
        };
        conditions?: {
            type: string;
            status: string;
            lastTransitionTime: string;
            reason: string;
            message: string;
        }[];
        storedVersions?: string[];
    };
}
declare class CustomResourceDefinition extends KubeObject<KubeCRD> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    static readOnlyFields: string[];
    static get listRoute(): string;
    static get detailsRoute(): string;
    get spec(): KubeCRD['spec'];
    get status(): KubeCRD['status'];
    get plural(): string;
    getMainAPIGroup(): [string, string, string];
    get isNamespacedScope(): boolean;
    makeCRClass(): typeof KubeObject<KubeCRD>;
    getCategories(): string[];
}
export interface CRClassArgs {
    apiInfo: {
        group: string;
        version: string;
    }[];
    kind: string;
    pluralName: string;
    singularName: string;
    isNamespaced: boolean;
    customResourceDefinition?: CustomResourceDefinition;
}
/** @deprecated Use the version of the function that receives an object as its argument. */
export declare function makeCustomResourceClass(args: [group: string, version: string, pluralName: string][], isNamespaced: boolean): KubeObjectClass;
export declare function makeCustomResourceClass(args: CRClassArgs): KubeObjectClass;
export default CustomResourceDefinition;
