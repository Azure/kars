import type { QueryParameters } from '../../api/v1/queryParameters';
import type { ApiError } from '../../api/v2/ApiError';
import type { KubeObject } from '../../KubeObject';
import { KubeObjectEndpoint } from './KubeObjectEndpoint';
export type QueryStatus = 'pending' | 'success' | 'error';
export interface QueryResponse<DataType, ErrorType> {
    /**
     * The last successfully resolved data for the query.
     */
    data: DataType | null;
    /**
     * The error object for the query, if an error was thrown.
     * - Defaults to `null`.
     */
    error: ErrorType | null;
    /**
     * A derived boolean from the `status` variable, provided for convenience.
     * - `true` if the query attempt resulted in an error.
     */
    isError: boolean;
    /**
     * Is `true` whenever the first fetch for a query is in-flight.
     */
    isLoading: boolean;
    /**
     * Is `true` whenever the query is executing, which includes initial fetch as well as background refetch.
     */
    isFetching: boolean;
    /**
     * A derived boolean from the `status` variable, provided for convenience.
     * - `true` if the query has received a response with no errors and is ready to display its data.
     */
    isSuccess: boolean;
    /**
     * The status of the query.
     * - Will be:
     *   - `pending` if there's no cached data and no query attempt was finished yet.
     *   - `error` if the query attempt resulted in an error.
     *   - `success` if the query has received a response with no errors and is ready to display its data.
     */
    status: QueryStatus;
}
/**
 * Query response containing KubeList with added items field for convenience
 */
export interface QueryListResponse<DataType, ItemType, ErrorType> extends QueryResponse<DataType, ErrorType> {
    items: Array<ItemType> | null;
    /**
     * Results from individual clusters. Keyed by cluster name.
     */
    clusterResults?: Record<string, QueryListResponse<DataType, ItemType, ErrorType>>;
    errors: ApiError[] | null;
}
export declare const kubeObjectQueryKey: ({ cluster, endpoint, namespace, name, queryParams, }: {
    cluster: string;
    endpoint?: KubeObjectEndpoint | null;
    namespace?: string;
    name: string;
    queryParams?: QueryParameters;
}) => (string | QueryParameters | KubeObjectEndpoint | null | undefined)[];
/**
 * Returns a single KubeObject.
 */
export declare function useKubeObject<K extends KubeObject>({ kubeObjectClass, namespace, name, cluster, queryParams, }: {
    /** Class to instantiate the object with */
    kubeObjectClass: (new (...args: any) => K) & typeof KubeObject<any>;
    /** Object namespace */
    namespace?: string;
    /** Object name */
    name: string;
    /** Cluster name */
    cluster?: string;
    queryParams?: QueryParameters;
}): [K | null, ApiError | null] & QueryResponse<K, ApiError>;
/**
 * Checks and returns an endpoint that works from the list
 *
 * @params endpoints - List of possible endpoints
 */
export declare const useEndpoints: (endpoints: KubeObjectEndpoint[], cluster: string, namespace?: string) => {
    endpoint: KubeObjectEndpoint | undefined;
    error: ApiError | null;
};
