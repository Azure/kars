import type { KubeObjectInterfaceCreate } from '../../KubeObject';
/**
 * Applies the provided body to the Kubernetes API.
 *
 * Tries to POST, and if there's a conflict it does a PUT to the api endpoint.
 *
 * Overloads:
 * - When called with a KubeObjectInterfaceCreate body, the parameter type is the create type.
 * - Otherwise it accepts a full KubeObjectInterface.
 *
 * @param body - The kubernetes object body to apply.
 * @param clusterName - The cluster to apply the body to. By default uses the current cluster (URL defined).
 *
 * @returns The response from the kubernetes API server.
 */
export declare function apply<T extends KubeObjectInterfaceCreate>(body: T, clusterName?: string): Promise<T>;
