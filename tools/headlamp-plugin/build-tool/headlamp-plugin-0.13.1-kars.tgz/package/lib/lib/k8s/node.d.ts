import type { ApiError } from './api/v2/ApiError';
import type { KubeCondition, KubeMetrics } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeNode extends KubeObjectInterface {
    status: {
        addresses?: {
            address: string;
            type: string;
        }[];
        allocatable?: {
            cpu: any;
            memory: any;
            ephemeralStorage: any;
            hugepages_1Gi: any;
            hugepages_2Mi: any;
            pods: any;
        };
        capacity?: {
            cpu: any;
            memory: any;
            ephemeralStorage: any;
            hugepages_1Gi: any;
            hugepages_2Mi: any;
            pods: any;
        };
        conditions?: (Omit<KubeCondition, 'lastProbeTime' | 'lastUpdateTime'> & {
            lastHeartbeatTime: string;
        })[];
        nodeInfo?: {
            architecture: string;
            bootID: string;
            containerRuntimeVersion: string;
            kernelVersion: string;
            kubeProxyVersion: string;
            kubeletVersion: string;
            machineID: string;
            operatingSystem: string;
            osImage: string;
            systemUUID: string;
        };
    };
    spec: {
        podCIDR: string;
        taints: {
            key: string;
            value?: string;
            effect: string;
        }[];
        [otherProps: string]: any;
    };
}
declare class Node extends KubeObject<KubeNode> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get status(): KubeNode['status'];
    get spec(): KubeNode['spec'];
    static useMetrics(): [KubeMetrics[] | null, ApiError | null];
    getExternalIP(): string;
    getInternalIP(): string;
}
export default Node;
