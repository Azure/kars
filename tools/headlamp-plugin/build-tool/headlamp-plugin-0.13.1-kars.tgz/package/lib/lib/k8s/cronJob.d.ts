import type { KubeContainer } from './cluster';
import type { KubeMetadata } from './KubeMetadata';
import { KubeObject, type KubeObjectInterface } from './KubeObject';
/**
 * CronJob structure returned by the k8s API.
 *
 * @see {@link https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/cron-job-v1/} Kubernetes API reference for CronJob
 *
 * @see {@link https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/} Kubernetes definition for CronJob
 */
export interface KubeCronJob extends KubeObjectInterface {
    spec: {
        suspend: boolean;
        schedule: string;
        startingDeadlineSeconds?: number;
        successfulJobsHistoryLimit: number;
        failedJobsHistoryLimit: number;
        concurrencyPolicy: string;
        jobTemplate: {
            spec: {
                metadata?: Partial<KubeMetadata>;
                template: {
                    spec: {
                        metadata?: Partial<KubeMetadata>;
                        containers: KubeContainer[];
                    };
                };
            };
        };
        [otherProps: string]: any;
    };
    status: {
        [otherProps: string]: any;
    };
}
declare class CronJob extends KubeObject<KubeCronJob> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get spec(): any;
    get status(): any;
    static getBaseObject(): KubeCronJob;
    getContainers(): KubeContainer[];
}
export default CronJob;
