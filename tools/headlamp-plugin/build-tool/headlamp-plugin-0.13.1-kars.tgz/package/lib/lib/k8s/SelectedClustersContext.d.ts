/** Allows overriding selected clusters value in a react subtree */
export declare const SelectedClustersContext: import("react").Context<string[] | undefined>;
