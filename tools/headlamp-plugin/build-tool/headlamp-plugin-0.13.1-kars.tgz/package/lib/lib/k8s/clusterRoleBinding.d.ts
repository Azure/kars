import { KubeObject } from './KubeObject';
import type { KubeRoleBinding } from './roleBinding';
declare class ClusterRoleBinding extends KubeObject<KubeRoleBinding> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get roleRef(): {
        apiGroup: string;
        kind: string;
        name: string;
    };
    get subjects(): KubeRoleBinding['subjects'];
}
export default ClusterRoleBinding;
