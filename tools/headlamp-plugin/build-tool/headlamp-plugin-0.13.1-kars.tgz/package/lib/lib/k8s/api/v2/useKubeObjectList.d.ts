import type { QueryObserverOptions } from '@tanstack/react-query';
import type { KubeObject, KubeObjectClass } from '../../KubeObject';
import type { QueryParameters } from '../v1/queryParameters';
import { ApiError } from './ApiError';
import type { QueryListResponse } from './hooks';
import { KubeList } from './KubeList';
import { KubeObjectEndpoint } from './KubeObjectEndpoint';
/**
 * @returns true if the websocket multiplexer is enabled.
 * defaults to true. This is a feature flag to enable the websocket multiplexer.
 */
export declare function getWebsocketMultiplexerEnabled(): boolean;
/**
 * Object representing a List of Kube object
 * with information about which cluster and namespace it came from
 */
export interface ListResponse<K extends KubeObject> {
    /** KubeList with items */
    list: KubeList<K>;
    /** Cluster of the list */
    cluster: string;
    /** If the list only has items from one namespace */
    namespace?: string;
}
/**
 * Query to list Kube objects from a cluster and namespace(optional)
 *
 * @param kubeObjectClass - Class to instantiate the object with
 * @param endpoint - API endpoint
 * @param namespace - namespace to list objects from(optional)
 * @param cluster - cluster name
 * @param queryParams - query parameters
 * @returns query options for getting a single list of kube resources
 */
export declare function kubeObjectListQuery<K extends KubeObject>(kubeObjectClass: KubeObjectClass, endpoint: KubeObjectEndpoint, namespace: string | undefined, cluster: string, queryParams: QueryParameters, refetchInterval?: number): QueryObserverOptions<ListResponse<K> | undefined | null, ApiError>;
/**
 * Accepts a list of lists to watch.
 * Upon receiving update it will modify query data for list query
 */
export declare function useWatchKubeObjectLists<K extends KubeObject>({ kubeObjectClass, endpoint, lists, queryParams, }: {
    /** KubeObject class of the watched resource list */
    kubeObjectClass: (new (...args: any) => K) & typeof KubeObject<any>;
    /** Query parameters for the WebSocket connection URL */
    queryParams?: QueryParameters;
    /** Kube resource API endpoint information */
    endpoint?: KubeObjectEndpoint | null;
    /** Which clusters and namespaces to watch */
    lists: Array<{
        cluster: string;
        namespace?: string;
        resourceVersion: string;
    }>;
}): void;
/**
 * Creates multiple requests to list Kube objects
 * Handles multiple clusters, namespaces and allowed namespaces
 *
 * @param clusters - list of clusters
 * @param getAllowedNamespaces -  function to get allowed namespaces for a cluster
 * @param isResourceNamespaced - if the resource is namespaced
 * @param requestedNamespaces - requested namespaces(optional)
 *
 * @returns list of requests for clusters and appropriate namespaces
 */
export declare function makeListRequests(clusters: string[], getAllowedNamespaces: (cluster: string | null) => string[], isResourceNamespaced: boolean, requestedNamespaces?: string[]): Array<{
    cluster: string;
    namespaces?: string[];
}>;
/**
 * Returns a combined list of Kubernetes objects and watches for changes from the clusters given.
 *
 * @param param - request paramaters
 * @returns Combined list of Kubernetes resources
 */
export declare function useKubeObjectList<K extends KubeObject>({ requests, kubeObjectClass, queryParams, watch, refetchInterval, }: {
    requests: Array<{
        cluster: string;
        namespaces?: string[];
    }>;
    /** Class to instantiate the object with */
    kubeObjectClass: (new (...args: any) => K) & typeof KubeObject<any>;
    queryParams?: QueryParameters;
    /** Watch for updates @default true */
    watch?: boolean;
    /** How often to refetch the list. Won't refetch by default. Disables watching if set. */
    refetchInterval?: number;
}): [Array<K> | null, ApiError | null] & QueryListResponse<Array<ListResponse<K> | undefined | null>, K, ApiError>;
