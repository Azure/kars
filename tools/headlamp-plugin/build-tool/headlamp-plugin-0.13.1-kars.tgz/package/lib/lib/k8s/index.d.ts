import { ConfigState } from '../../redux/configSlice';
import { ApiError } from './api/v2/ApiError';
import { Cluster, LabelSelector, StringDict } from './cluster';
import ClusterRole from './clusterRole';
import ClusterRoleBinding from './clusterRoleBinding';
import ConfigMap from './configMap';
import CustomResourceDefinition from './crd';
import CronJob from './cronJob';
import DaemonSet from './daemonSet';
import Deployment from './deployment';
import Endpoints from './endpoints';
import EndpointSlice from './endpointSlices';
import Gateway from './gateway';
import GatewayClass from './gatewayClass';
import GRPCRoute from './grpcRoute';
import HPA from './hpa';
import HTTPRoute from './httpRoute';
import Ingress from './ingress';
import IngressClass from './ingressClass';
import Job from './job';
import { Lease } from './lease';
import { LimitRange } from './limitRange';
import Namespace from './namespace';
import NetworkPolicy from './networkpolicy';
import Node from './node';
import PersistentVolume from './persistentVolume';
import PersistentVolumeClaim from './persistentVolumeClaim';
import Pod from './pod';
import PodDisruptionBudget from './podDisruptionBudget';
import PriorityClass from './priorityClass';
import ReplicaSet from './replicaSet';
import ResourceQuota from './resourceQuota';
import Role from './role';
import RoleBinding from './roleBinding';
import { RuntimeClass } from './runtime';
import Secret from './secret';
import Service from './service';
import ServiceAccount from './serviceAccount';
import StatefulSet from './statefulSet';
import StorageClass from './storageClass';
export declare const ResourceClasses: {
    ClusterRole: typeof ClusterRole;
    ClusterRoleBinding: typeof ClusterRoleBinding;
    ConfigMap: typeof ConfigMap;
    CustomResourceDefinition: typeof CustomResourceDefinition;
    CronJob: typeof CronJob;
    DaemonSet: typeof DaemonSet;
    Deployment: typeof Deployment;
    Endpoint: typeof Endpoints;
    Endpoints: typeof Endpoints;
    EndpointSlice: typeof EndpointSlice;
    LimitRange: typeof LimitRange;
    Lease: typeof Lease;
    ResourceQuota: typeof ResourceQuota;
    HorizontalPodAutoscaler: typeof HPA;
    PodDisruptionBudget: typeof PodDisruptionBudget;
    PriorityClass: typeof PriorityClass;
    Ingress: typeof Ingress;
    IngressClass: typeof IngressClass;
    Job: typeof Job;
    Namespace: typeof Namespace;
    NetworkPolicy: typeof NetworkPolicy;
    Node: typeof Node;
    PersistentVolume: typeof PersistentVolume;
    PersistentVolumeClaim: typeof PersistentVolumeClaim;
    Pod: typeof Pod;
    ReplicaSet: typeof ReplicaSet;
    Role: typeof Role;
    RoleBinding: typeof RoleBinding;
    RuntimeClass: typeof RuntimeClass;
    Secret: typeof Secret;
    Service: typeof Service;
    ServiceAccount: typeof ServiceAccount;
    StatefulSet: typeof StatefulSet;
    StorageClass: typeof StorageClass;
    Gateway: typeof Gateway;
    GatewayClass: typeof GatewayClass;
    HTTPRoute: typeof HTTPRoute;
    GRPCRoute: typeof GRPCRoute;
};
/** Hook for getting or fetching the clusters configuration.
 * This gets the clusters from the redux store. The redux store is updated
 * when the user changes the configuration. The configuration is stored in
 * the local storage. When stateless clusters are present, it combines the
 * stateless clusters with the clusters from the redux store.
 * @returns the clusters configuration.
 * */
export declare function useClustersConf(): ConfigState['allClusters'];
/**
 * Get the currently selected cluster name.
 *
 * If more than one cluster is selected it will return:
 *  - On details pages: the cluster of the currently viewed resource
 *  - On any other page: one of the selected clusters
 *
 * To get all currently selected clusters please use {@link useSelectedClusters}
 *
 * @returns currently selected cluster
 */
export declare function useCluster(): string | null;
/**
 * Get a list of selected clusters. Updates when the cluster changes.
 *
 * @returns list of selected clusters. if no clusters are selected, an empty list is returned.
 */
export declare function useSelectedClusters(): string[];
/**
 * Gets the version of the cluster given by the parameter.
 *
 * @param clusterName - the name of the cluster to query, or the currently selected cluster.
 * @returns a promise that resolves to a dictionary containing version info.
 */
export declare function getVersion(clusterName?: string): Promise<StringDict>;
export type CancellablePromise = Promise<() => void>;
/**
 * Hook to manage multiple cancellable API calls tied to the active cluster.
 *
 * @param apiCalls - functions returning cancellable promises for API calls.
 */
export declare function useConnectApi(...apiCalls: (() => CancellablePromise)[]): void;
/**
 * See {@link https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#list-and-watch-filtering|Label selector examples},
 * {@link https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#resources-that-support-set-based-requirements|deployment selector example},
 * {@link https://github.com/kubernetes/apimachinery/blob/be3a79b26814a8d7637d70f4d434a4626ee1c1e7/pkg/selection/operator.go#L24|possible operators}, and
 * {@link https://github.com/kubernetes/apimachinery/blob/be3a79b26814a8d7637d70f4d434a4626ee1c1e7/pkg/labels/selector.go#L305|Format rule for expressions}.
 */
export declare function labelSelectorToQuery(labelSelector: LabelSelector): string;
/**
 * Simplifies a matchLabels object into an array of string expressions.
 *
 * @param matchLabels - the matchLabels object from a LabelSelector.
 * @param isEqualSeperator - whether to use "=" as the separator instead of ":".
 * @returns an array of simplified label strings, or an empty string.
 */
export declare function matchLabelsSimplifier(matchLabels: LabelSelector['matchLabels'], isEqualSeperator?: boolean): string[] | '';
/**
 * Simplifies a matchExpressions array into an array of string representations.
 *
 * @param matchExpressions - the matchExpressionss array from a LabelSelector.
 * @returns an array of simplified expression strings, or an empty string.
 */
export declare function matchExpressionSimplifier(matchExpressions: LabelSelector['matchExpressions']): string[] | '';
/** Hook to get the version of the clusters given by the parameter.
 *
 * @param clusters
 * @returns a map with cluster -> version-info, and a map with cluster -> error.
 */
export declare function useClustersVersion(clusters: Cluster[]): [{
    [clusterName: string]: StringDict;
}, {
    [clusterName: string]: ApiError | null;
}];
export * as cluster from './cluster';
export * as clusterRole from './clusterRole';
export * as clusterRoleBinding from './clusterRoleBinding';
export * as configMap from './configMap';
export * as crd from './crd';
export * as cronJob from './cronJob';
export * as daemonSet from './daemonSet';
export * as deployment from './deployment';
export * as event from './event';
export * as ingress from './ingress';
export * as ingressClass from './ingressClass';
export * as job from './job';
export * as namespace from './namespace';
export * as node from './node';
export * as persistentVolume from './persistentVolume';
export * as persistentVolumeClaim from './persistentVolumeClaim';
export * as pod from './pod';
export * as replicaSet from './replicaSet';
export * as role from './role';
export * as roleBinding from './roleBinding';
export * as secret from './secret';
export * as service from './service';
export * as serviceAccount from './serviceAccount';
export * as statefulSet from './statefulSet';
export * as storageClass from './storageClass';
