import type { GatewayParentReference } from './gateway';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
/**
 * GRPCRoute is a Gateway API type for specifying routing behavior of gRPC requests from a Gateway listener to an API object, i.e. Service.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.GRPCRoute} Gateway API reference for GRPCRoute
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/grpcroute/} Gateway API definition for GRPCRoute
 */
export interface KubeGRPCRoute extends KubeObjectInterface {
    spec: {
        parentRefs: GatewayParentReference[];
        [key: string]: any;
    };
}
declare class GRPCRoute extends KubeObject<KubeGRPCRoute> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): KubeGRPCRoute['spec'];
    get parentRefs(): GatewayParentReference[];
    static get pluralName(): string;
}
export default GRPCRoute;
