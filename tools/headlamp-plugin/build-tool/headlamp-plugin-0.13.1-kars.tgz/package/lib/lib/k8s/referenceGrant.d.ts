import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
/**
 * ReferenceGrantFrom defines the source resource (e.g., HTTPRoute) that is allowed to reference a target resource.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1beta1.ReferenceGrant} Gateway API reference for ReferenceGrant
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/referencegrant/#structure} Gateway API definition for ReferenceGrantFrom
 */
export interface ReferenceGrantFrom {
    group: string;
    kind: string;
    namespace: string;
}
/**
 * ReferenceGrantTo defines the target resource (e.g., Service or Secret) that can be referenced.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1beta1.ReferenceGrant} Gateway API reference for ReferenceGrant
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/referencegrant/#structure} Gateway API definition for ReferenceGrantTo
 */
export interface ReferenceGrantTo {
    group: string;
    kind: string;
    name?: string;
}
/**
 * ReferenceGrant is a Gateway API type that enables cross-namespace references for resources like HTTPRoute or Gateway.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1beta1.ReferenceGrant} Gateway API reference for ReferenceGrant
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/referencegrant/} Gateway API definition for ReferenceGrant
 */
export interface KubeReferenceGrant extends KubeObjectInterface {
    spec: {
        from: ReferenceGrantFrom[];
        to: ReferenceGrantTo[];
        [key: string]: any;
    };
}
declare class ReferenceGrant extends KubeObject<KubeReferenceGrant> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): KubeReferenceGrant['spec'];
    get from(): ReferenceGrantFrom[];
    get to(): ReferenceGrantTo[];
    static get pluralName(): string;
}
export default ReferenceGrant;
