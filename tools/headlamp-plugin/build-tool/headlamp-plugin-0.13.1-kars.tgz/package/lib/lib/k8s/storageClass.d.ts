import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeStorageClass extends KubeObjectInterface {
    provisioner: string;
    reclaimPolicy: string;
    volumeBindingMode: string;
    allowVolumeExpansion?: boolean;
}
declare class StorageClass extends KubeObject<KubeStorageClass> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeStorageClass;
    get isDefault(): boolean;
    get provisioner(): string;
    get reclaimPolicy(): string;
    get volumeBindingMode(): string;
    get allowVolumeExpansion(): boolean | undefined;
    static get listRoute(): string;
    static get pluralName(): string;
}
export default StorageClass;
