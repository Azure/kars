import type { LabelSelector } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
import type { KubeRuleWithOperations, KubeWebhookClientConfig } from './mutatingWebhookConfiguration';
export interface KubeValidatingWebhookConfiguration extends KubeObjectInterface {
    webhooks: {
        admissionReviewVersions: string[];
        clientConfig: KubeWebhookClientConfig;
        failurePolicy?: string;
        matchPolicy?: string;
        name: string;
        namespaceSelector?: {
            matchExpressions: LabelSelector['matchExpressions'];
            matchLabels: LabelSelector['matchLabels'];
        };
        objectSelector?: {
            matchExpressions: LabelSelector['matchExpressions'];
            matchLabels: LabelSelector['matchLabels'];
        };
        rules?: KubeRuleWithOperations[];
        sideEffects?: string;
        timeoutSeconds?: number;
    }[];
}
declare class ValidatingWebhookConfiguration extends KubeObject<KubeValidatingWebhookConfiguration> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeValidatingWebhookConfiguration;
    get webhooks(): KubeValidatingWebhookConfiguration['webhooks'];
}
export default ValidatingWebhookConfiguration;
