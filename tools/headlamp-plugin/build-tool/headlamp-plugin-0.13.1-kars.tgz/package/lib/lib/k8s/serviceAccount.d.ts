import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeServiceAccount extends KubeObjectInterface {
    secrets: {
        apiVersion: string;
        fieldPath: string;
        kind: string;
        name: string;
        namespace: string;
        uid: string;
    }[];
}
declare class ServiceAccount extends KubeObject<KubeServiceAccount> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeServiceAccount;
    get secrets(): KubeServiceAccount['secrets'];
}
export default ServiceAccount;
