/**
 * Represents a resource available in the Kubernetes API.
 */
export interface ApiResource {
    apiVersion: string;
    groupName?: string;
    version: string;
    pluralName: string;
    singularName: string;
    kind: string;
    isNamespaced: boolean;
}
/** Unique identifier for an API Resource */
export declare const apiResourceId: (resource: ApiResource) => string;
