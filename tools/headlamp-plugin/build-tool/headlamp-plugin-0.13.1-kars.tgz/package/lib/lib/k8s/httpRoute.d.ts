import type { GatewayParentReference } from './gateway';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
/**
 * HTTPRouteRule defines semantics for matching an HTTP request based on conditions (matches), processing it (filters), and forwarding the request to an API object (backendRefs).
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.HTTPRouteRule} Gateway API reference for HTTPRouteRule
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/httproute/#rules} Gateway API definition for HTTPRouteRule
 */
export interface HTTPRouteRule {
    name?: string;
    backendRefs?: any[];
    matches?: any[];
    [key: string]: any;
}
/**
 * HTTPRoute is a Gateway API type for specifying routing behavior of HTTP requests from a Gateway listener to an API object, i.e. Service.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.HTTPRoute} Gateway API reference for HTTPRoute
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/httproute/} Gateway API definition for HTTPRoute
 */
export interface KubeHTTPRoute extends KubeObjectInterface {
    spec: {
        hostnames?: string[];
        parentRefs?: GatewayParentReference[];
        rules?: HTTPRouteRule[];
        [key: string]: any;
    };
}
declare class HTTPRoute extends KubeObject<KubeHTTPRoute> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): KubeHTTPRoute['spec'];
    get hostnames(): string[];
    get rules(): HTTPRouteRule[];
    get parentRefs(): GatewayParentReference[];
    static get pluralName(): string;
}
export default HTTPRoute;
