import type { KubeCondition } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeNamespace extends KubeObjectInterface {
    status: {
        phase: string;
        conditions?: KubeCondition[];
    };
}
declare class Namespace extends KubeObject<KubeNamespace> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get status(): {
        phase: string;
        conditions?: KubeCondition[];
    };
    /**
     * This function validates the custom namespace input matches the crieria for DNS-1123 label names.
     * @returns true if the namespace is valid, false otherwise.
     * @params namespace: string
     * @see https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#dns-label-names
     */
    static isValidNamespaceFormat(namespace: string): boolean;
}
export default Namespace;
