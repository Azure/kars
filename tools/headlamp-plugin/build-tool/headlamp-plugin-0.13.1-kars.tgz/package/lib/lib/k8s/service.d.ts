import type { KubeCondition } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubePortStatus {
    error?: string;
    port: number;
    protocol: string;
}
export interface KubeLoadBalancerIngress {
    hostname?: string;
    ip?: string;
    ports?: KubePortStatus[];
}
export interface KubeService extends KubeObjectInterface {
    spec: {
        clusterIP: string;
        ports?: {
            name: string;
            nodePort: number;
            port: number;
            protocol: string;
            targetPort: number | string;
        }[];
        type: string;
        externalIPs: string[];
        selector: {
            [key: string]: string;
        };
        [otherProps: string]: any;
    };
    status: {
        conditions?: KubeCondition[];
        loadBalancer?: {
            ingress: KubeLoadBalancerIngress[];
        };
    };
}
declare class Service extends KubeObject<KubeService> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeService;
    get spec(): KubeService['spec'];
    get status(): {
        conditions?: KubeCondition[];
        loadBalancer?: {
            ingress: KubeLoadBalancerIngress[];
        };
    };
    getExternalAddresses(): string;
    getPorts(): number[] | undefined;
    getFormattedPorts(): string[] | undefined;
    getSelector(): string[];
}
export default Service;
