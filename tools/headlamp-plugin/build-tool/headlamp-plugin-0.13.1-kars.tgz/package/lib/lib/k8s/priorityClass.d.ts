import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubePriorityClass extends KubeObjectInterface {
    value: number;
    preemptionPolicy: string;
    globalDefault?: boolean | null;
    description: string;
}
declare class PriorityClass extends KubeObject<KubePriorityClass> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubePriorityClass;
    get value(): number;
    get globalDefault(): boolean | null;
    get description(): string;
    get preemptionPolicy(): string;
}
export default PriorityClass;
