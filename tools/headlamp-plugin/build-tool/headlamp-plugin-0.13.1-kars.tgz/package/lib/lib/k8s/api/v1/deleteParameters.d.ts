/**
 * DeleteParamaters is a map of delete parameters for the Kubernetes API.
 */
export interface DeleteParameters {
    gracePeriodSeconds?: number;
    /**
     * dryRun causes apiserver to simulate the request, and report whether the object would be modified.
     * Can be '' or 'All'
     *
     * @see https://kubernetes.io/docs/reference/using-api/api-concepts/#dry-run
     */
    dryRun?: string;
}
