import type { StreamArgs, StreamResultsCb } from './api/v1/streamingApi';
import type { KubeCondition, KubeContainer, KubeContainerStatus, Time } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeVolume {
    name: string;
    [volumeName: string]: any;
}
export interface KubePodSpec {
    containers: KubeContainer[];
    nodeName: string;
    nodeSelector?: {
        [key: string]: string;
    };
    initContainers?: KubeContainer[];
    ephemeralContainers?: KubeContainer[];
    readinessGates?: {
        conditionType: string;
    }[];
    volumes?: KubeVolume[];
    serviceAccountName?: string;
    serviceAccount?: string;
    priority?: string;
    tolerations?: any[];
    restartPolicy?: string;
}
export interface KubePod extends KubeObjectInterface {
    spec: KubePodSpec;
    status: {
        conditions: KubeCondition[];
        containerStatuses: KubeContainerStatus[];
        initContainerStatuses?: KubeContainerStatus[];
        ephemeralContainerStatuses?: KubeContainerStatus[];
        hostIP?: string;
        hostIPs?: {
            ip: string;
        }[];
        podIPs?: {
            ip: string;
        }[];
        message?: string;
        phase: string;
        qosClass?: string;
        reason?: string;
        startTime: Time;
        [other: string]: any;
    };
}
export interface ExecOptions extends StreamArgs {
    command?: string[];
}
export interface LogOptions {
    /** The number of lines to display from the end side of the log */
    tailLines?: number;
    /** Whether to show the logs from previous runs of the container (only for restarted containers) */
    showPrevious?: boolean;
    /** Whether to show the timestamps in the logs */
    showTimestamps?: boolean;
    /** Whether to follow the log stream */
    follow?: boolean;
    /** Whether to prettify JSON logs with formatted indentation */
    prettifyLogs?: boolean;
    /** Whether to format JSON string values by unescaping string literals */
    formatJsonValues?: boolean;
    /** Callback to be called when the reconnection attempts stop */
    onReconnectStop?: () => void;
}
/**@deprecated
 * Use `container: string, onLogs: StreamResultsCb, logsOptions: LogOptions`
 * */
type oldGetLogs = (container: string, tailLines: number, showPrevious: boolean, onLogs: StreamResultsCb) => () => void;
type newGetLogs = (container: string, onLogs: LogStreamResultsCb, logsOptions: LogOptions) => () => void;
type LogStreamResultsCb = (result: {
    logs: string[];
    hasJsonLogs: boolean;
}) => void;
type PodDetailedStatus = {
    restarts: number;
    reason: string;
    message: string;
    totalContainers: number;
    readyContainers: number;
    lastRestartDate: Date;
};
declare class Pod extends KubeObject<KubePod> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    protected detailedStatusCache: Partial<{
        resourceVersion: string;
        details: PodDetailedStatus;
    }>;
    constructor(jsonData: KubePod, cluster?: string);
    get spec(): KubePod['spec'];
    get status(): KubePod['status'];
    evict(): Promise<any>;
    getLogs(...args: Parameters<oldGetLogs | newGetLogs>): () => void;
    attach(container: string, onAttach: StreamResultsCb, options?: StreamArgs): {
        cancel: () => void;
        getSocket: () => WebSocket | null;
    };
    exec(container: string, onExec: StreamResultsCb, options?: ExecOptions): {
        cancel: () => void;
        getSocket: () => WebSocket | null;
    };
    /**
     * Add an ephemeral container to the pod.
     * @param containerName - The name of the ephemeral container to add
     * @param image - The container image to use
     * @param command - Optional command to run in the container (defaults to ['sh'])
     * @returns Promise that resolves when the ephemeral container is added
     */
    addEphemeralContainer(containerName: string, image: string, command?: string[]): Promise<void>;
    private getLastRestartDate;
    private isRestartableInitContainer;
    private isPodInitializedConditionTrue;
    private hasPodReadyCondition;
    getDetailedStatus(): PodDetailedStatus;
    static getBaseObject(): KubePod;
}
export default Pod;
