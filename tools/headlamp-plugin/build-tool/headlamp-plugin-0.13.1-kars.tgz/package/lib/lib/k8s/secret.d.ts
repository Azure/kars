import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeSecret extends KubeObjectInterface {
    data: Record<string, string>;
    type: string;
}
declare class Secret extends KubeObject<KubeSecret> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeSecret;
    get data(): Record<string, string>;
    get type(): string;
}
export default Secret;
