import type CronJob from './cronJob';
import type DaemonSet from './daemonSet';
import type Deployment from './deployment';
import type Job from './job';
import type Pod from './pod';
import type ReplicaSet from './replicaSet';
import type StatefulSet from './statefulSet';
export type Workload = Pod | DaemonSet | ReplicaSet | StatefulSet | Job | CronJob | Deployment;
export type WorkloadClass = typeof Pod | typeof DaemonSet | typeof ReplicaSet | typeof StatefulSet | typeof Job | typeof CronJob | typeof Deployment;
