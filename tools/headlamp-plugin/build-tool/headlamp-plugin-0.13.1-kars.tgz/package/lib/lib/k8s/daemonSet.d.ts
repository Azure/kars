import type { KubeContainer, LabelSelector } from './cluster';
import type { KubeMetadata } from './KubeMetadata';
import { KubeObject, type KubeObjectInterface } from './KubeObject';
import type { KubePodSpec } from './pod';
export interface KubeDaemonSet extends KubeObjectInterface {
    spec: {
        updateStrategy: {
            type: string;
            rollingUpdate: {
                maxUnavailable: number;
            };
        };
        selector: LabelSelector;
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
        [otherProps: string]: any;
    };
    status: {
        [otherProps: string]: any;
    };
}
declare class DaemonSet extends KubeObject<KubeDaemonSet> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get spec(): {
        [otherProps: string]: any;
        updateStrategy: {
            type: string;
            rollingUpdate: {
                maxUnavailable: number;
            };
        };
        selector: LabelSelector;
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
    };
    get status(): {
        [otherProps: string]: any;
    };
    static getBaseObject(): KubeDaemonSet;
    getContainers(): KubeContainer[];
    getNodeSelectors(): string[];
}
export default DaemonSet;
