import type { RecursivePartial } from './api/v1/factories';
import { apiFactory, apiFactoryWithNamespace } from './api/v1/factories';
import type { QueryParameters } from './api/v1/queryParameters';
import type { ApiError } from './api/v2/ApiError';
import type { KubeEvent } from './event';
import type { KubeMetadata, KubeMetadataCreate } from './KubeMetadata';
export declare class KubeObject<T extends KubeObjectInterface | KubeEvent = any> {
    jsonData: T;
    /** Readonly field defined as JSONPath paths */
    static readOnlyFields: string[];
    _clusterName: string;
    /** The kind of the object. Corresponding to the resource kind in Kubernetes. */
    static readonly kind: string;
    /** Name of the resource, plural, used in API */
    static readonly apiName: string;
    /** Group and version of the resource formatted as "GROUP/VERSION", e.g. "policy.k8s.io/v1". */
    static readonly apiVersion: string | string[];
    /** Whether the object is namespaced. */
    static readonly isNamespaced: boolean;
    /** Whether the object is scalable, and should have a ScaleButton */
    static readonly isScalable: boolean;
    static _internalApiEndpoint?: ReturnType<typeof apiFactoryWithNamespace | typeof apiFactory>;
    static get apiEndpoint(): ReturnType<typeof apiFactoryWithNamespace | typeof apiFactory>;
    static set apiEndpoint(endpoint: ReturnType<typeof apiFactoryWithNamespace | typeof apiFactory>);
    constructor(json: T, cluster?: string);
    get cluster(): string;
    set cluster(cluster: string);
    static get className(): string;
    get detailsRoute(): string;
    static get detailsRoute(): string;
    /**
     * Get name of the API group of this resource
     * for example will return batch for CronJob
     *
     * For core group, like Pods, it will return undefined
     *
     * API group reference https://kubernetes.io/docs/reference/using-api/#api-groups
     */
    static get apiGroupName(): string | undefined;
    /**
     * Type guard to check if a KubeObject instance belongs to this class.
     * Compares API group name and kind to determine if the instance matches.
     * This works even if class definitions are duplicated and should be used
     * instead of `instanceof`.
     *
     * @param maybeInstance - The KubeObject instance to check.
     * @returns True if the instance is of this class type, with narrowed type.
     */
    static isClassOf<K extends KubeObjectClass>(this: K, maybeInstance: KubeObject): maybeInstance is InstanceType<K>;
    static get pluralName(): string;
    get pluralName(): string;
    get listRoute(): string;
    static get listRoute(): string;
    get kind(): any;
    getDetailsLink(): string;
    getListLink(): string;
    getName(): string;
    getNamespace(): string | undefined;
    getCreationTs(): string;
    getAge(): string;
    getValue(prop: string): any;
    get metadata(): KubeMetadata;
    get isNamespaced(): boolean;
    get isScalable(): boolean;
    getEditableObject(): {};
    /**
     * Returns the API endpoint for this object.
     *
     * @param onList - Callback function to be called when the list is retrieved.
     * @param onError - Callback function to be called when an error occurs.
     * @param opts - Options to be passed to the API endpoint.
     *
     * @returns The API endpoint for this object.
     */
    static apiList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onList: (arg: K[]) => void, onError?: (err: ApiError, cluster?: string) => void, opts?: ApiListSingleNamespaceOptions): (...args: any[]) => Promise<import("./api/v1/factories").CancelFunction>;
    static useApiList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onList: (...arg: any[]) => any, onError?: (err: ApiError, cluster?: string) => void, opts?: ApiListOptions): void;
    static useList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, { cluster, clusters, namespace, refetchInterval, ...queryParams }?: {
        cluster?: string;
        clusters?: string[];
        namespace?: string | string[];
        /** How often to refetch the list. Won't refetch by default. Disables watching if set. */
        refetchInterval?: number;
    } & QueryParameters): [K[] | null, ApiError | null] & import("./api/v2/hooks").QueryListResponse<(import("./api/v2/useKubeObjectList").ListResponse<K> | null | undefined)[], K, ApiError>;
    static useGet<K extends KubeObject>(this: new (...args: any) => K, name: string, namespace?: string, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): [K | null, ApiError | null] & import("./api/v2/hooks").QueryResponse<K, ApiError>;
    static create<Args extends any[], T extends KubeObject>(this: new (...args: Args) => T, ...item: Args): T;
    static apiGet<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onGet: (...args: any) => void, name: string, namespace?: string, onError?: (err: ApiError | null, cluster?: string) => void, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): (...args: any[]) => Promise<import("./api/v1/factories").CancelFunction>;
    static useApiGet<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onGet: (item: K | null) => any, name: string, namespace?: string, onError?: (err: ApiError | null, cluster?: string) => void, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): void;
    _class(): KubeObjectClass;
    delete(force?: boolean): Promise<any>;
    update(data: KubeObjectInterface): Promise<KubeObjectInterface>;
    static put(data: KubeObjectInterface): Promise<KubeObjectInterface>;
    scale(numReplicas: number): Promise<any>;
    patch(body: RecursivePartial<T>): Promise<any>;
    /** Performs a request to check if the user has the given permission.
     * @param reResourceAttrs The attributes describing this access request. See https://kubernetes.io/docs/reference/kubernetes-api/authorization-resources/self-subject-access-review-v1/#SelfSubjectAccessReviewSpec .
     * @returns The result of the access request.
     */
    static fetchAuthorization(reqResourseAttrs?: AuthRequestResourceAttrs, cluster?: string): Promise<any>;
    static getAuthorization(verb: string, reqResourseAttrs?: AuthRequestResourceAttrs, cluster?: string): Promise<any>;
    getAuthorization(verb: string, reqResourseAttrs?: AuthRequestResourceAttrs): Promise<any>;
    static getErrorMessage(err: ApiError | null): "Error: Not found" | "Error: No permissions" | "Error" | null;
    static getBaseObject(): Omit<KubeObjectInterface, 'metadata'> & {
        metadata: Partial<KubeMetadata>;
    };
}
/**
 * @deprecated This function is no longer recommended, it's kept for backwards compatibility.
 * Please extend KubeObject instead
 *
 * @returns A KubeObject implementation for the given object name.
 *
 * @param objectName The name of the object to create a KubeObject implementation for.
 */
export declare function makeKubeObject<T extends KubeObjectInterface | KubeEvent>(): {
    new (json: T, cluster?: string): {
        jsonData: T;
        _clusterName: string;
        cluster: string;
        readonly detailsRoute: string;
        readonly pluralName: string;
        readonly listRoute: string;
        readonly kind: any;
        getDetailsLink(): string;
        getListLink(): string;
        getName(): string;
        getNamespace(): string | undefined;
        getCreationTs(): string;
        getAge(): string;
        getValue(prop: string): any;
        readonly metadata: KubeMetadata;
        readonly isNamespaced: boolean;
        readonly isScalable: boolean;
        getEditableObject(): {};
        _class(): KubeObjectClass;
        delete(force?: boolean): Promise<any>;
        update(data: KubeObjectInterface): Promise<KubeObjectInterface>;
        scale(numReplicas: number): Promise<any>;
        patch(body: RecursivePartial<T>): Promise<any>;
        getAuthorization(verb: string, reqResourseAttrs?: AuthRequestResourceAttrs): Promise<any>;
    };
    /** Readonly field defined as JSONPath paths */
    readOnlyFields: string[];
    /** The kind of the object. Corresponding to the resource kind in Kubernetes. */
    readonly kind: string;
    /** Name of the resource, plural, used in API */
    readonly apiName: string;
    /** Group and version of the resource formatted as "GROUP/VERSION", e.g. "policy.k8s.io/v1". */
    readonly apiVersion: string | string[];
    /** Whether the object is namespaced. */
    readonly isNamespaced: boolean;
    /** Whether the object is scalable, and should have a ScaleButton */
    readonly isScalable: boolean;
    _internalApiEndpoint?: ReturnType<typeof apiFactoryWithNamespace | typeof apiFactory>;
    apiEndpoint: import("./api/v1/factories").ApiClient<KubeObjectInterface> | import("./api/v1/factories").ApiWithNamespaceClient<KubeObjectInterface>;
    readonly className: string;
    readonly detailsRoute: string;
    /**
     * Get name of the API group of this resource
     * for example will return batch for CronJob
     *
     * For core group, like Pods, it will return undefined
     *
     * API group reference https://kubernetes.io/docs/reference/using-api/#api-groups
     */
    readonly apiGroupName: string | undefined;
    /**
     * Type guard to check if a KubeObject instance belongs to this class.
     * Compares API group name and kind to determine if the instance matches.
     * This works even if class definitions are duplicated and should be used
     * instead of `instanceof`.
     *
     * @param maybeInstance - The KubeObject instance to check.
     * @returns True if the instance is of this class type, with narrowed type.
     */
    isClassOf<K extends KubeObjectClass>(this: K, maybeInstance: KubeObject): maybeInstance is InstanceType<K>;
    readonly pluralName: string;
    readonly listRoute: string;
    /**
     * Returns the API endpoint for this object.
     *
     * @param onList - Callback function to be called when the list is retrieved.
     * @param onError - Callback function to be called when an error occurs.
     * @param opts - Options to be passed to the API endpoint.
     *
     * @returns The API endpoint for this object.
     */
    apiList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onList: (arg: K[]) => void, onError?: (err: ApiError, cluster?: string) => void, opts?: ApiListSingleNamespaceOptions): (...args: any[]) => Promise<import("./api/v1/factories").CancelFunction>;
    useApiList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onList: (...arg: any[]) => any, onError?: (err: ApiError, cluster?: string) => void, opts?: ApiListOptions): void;
    useList<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, { cluster, clusters, namespace, refetchInterval, ...queryParams }?: {
        cluster?: string;
        clusters?: string[];
        namespace?: string | string[];
        /** How often to refetch the list. Won't refetch by default. Disables watching if set. */
        refetchInterval?: number;
    } & QueryParameters): [K[] | null, ApiError | null] & import("./api/v2/hooks").QueryListResponse<(import("./api/v2/useKubeObjectList").ListResponse<K> | null | undefined)[], K, ApiError>;
    useGet<K extends KubeObject>(this: new (...args: any) => K, name: string, namespace?: string, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): [K | null, ApiError | null] & import("./api/v2/hooks").QueryResponse<K, ApiError>;
    create<Args extends any[], T_1 extends KubeObject>(this: new (...args: Args) => T_1, ...item: Args): T_1;
    apiGet<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onGet: (...args: any) => void, name: string, namespace?: string, onError?: (err: ApiError | null, cluster?: string) => void, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): (...args: any[]) => Promise<import("./api/v1/factories").CancelFunction>;
    useApiGet<K extends KubeObject>(this: (new (...args: any) => K) & typeof KubeObject<any>, onGet: (item: K | null) => any, name: string, namespace?: string, onError?: (err: ApiError | null, cluster?: string) => void, opts?: {
        queryParams?: QueryParameters;
        cluster?: string;
    }): void;
    put(data: KubeObjectInterface): Promise<KubeObjectInterface>;
    /** Performs a request to check if the user has the given permission.
     * @param reResourceAttrs The attributes describing this access request. See https://kubernetes.io/docs/reference/kubernetes-api/authorization-resources/self-subject-access-review-v1/#SelfSubjectAccessReviewSpec .
     * @returns The result of the access request.
     */
    fetchAuthorization(reqResourseAttrs?: AuthRequestResourceAttrs, cluster?: string): Promise<any>;
    getAuthorization(verb: string, reqResourseAttrs?: AuthRequestResourceAttrs, cluster?: string): Promise<any>;
    getErrorMessage(err: ApiError | null): "Error: Not found" | "Error: No permissions" | "Error" | null;
    getBaseObject(): Omit<KubeObjectInterface, "metadata"> & {
        metadata: Partial<KubeMetadata>;
    };
};
/**
 * This type refers to the *class* of a KubeObject.
 */
export type KubeObjectClass = typeof KubeObject<any>;
/**
 * This is the base interface for all Kubernetes resources, i.e. it contains fields
 * that all Kubernetes resources have.
 */
export interface KubeObjectInterface {
    /**
     * Kind is a string value representing the REST resource this object represents.
     * Servers may infer this from the endpoint the client submits requests to.
     *
     * In CamelCase.
     *
     * Cannot be updated.
     *
     * @see {@link https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds | more info}
     */
    kind: string;
    apiVersion?: string;
    metadata: KubeMetadata;
    spec?: any;
    status?: any;
    items?: any[];
    actionType?: any;
    lastTimestamp?: string;
    key?: any;
    [otherProps: string]: any;
}
/**
 * KubeObjectInterfaceCreate is a version of KubeObjectInterface for creating objects
 * where uid, creationTimestamp, etc. are optional
 */
export interface KubeObjectInterfaceCreate extends Omit<KubeObjectInterface, 'metadata'> {
    metadata: KubeMetadataCreate;
}
export interface ApiListOptions extends QueryParameters {
    /**
     * The clusters to list objects from. By default uses the current clusters being viewed.
     */
    clusters?: string[];
    /** The namespace to list objects from. */
    namespace?: string | string[];
    /**
     * The cluster to list objects from. By default uses the current cluster being viewed.
     * If clusters is set, then we use that and "cluster" is ignored.
     */
    cluster?: string;
}
export interface ApiListSingleNamespaceOptions {
    /** The namespace to get the object from. */
    namespace?: string;
    /** The parameters to be passed to the API endpoint. */
    queryParams?: QueryParameters;
    /** The cluster to get the object from. By default uses the current cluster being viewed. */
    cluster?: string;
}
export interface AuthRequestResourceAttrs {
    name?: string;
    resource?: string;
    subresource?: string;
    namespace?: string;
    version?: string;
    group?: string;
    verb?: string;
}
