/**
 * Deletes the plugin with the specified name from the system.
 *
 * This function sends a DELETE request to the server's plugin management
 * endpoint, targeting the plugin identified by its name and type.
 * The function handles the request asynchronously and returns a promise that
 * resolves when the deletion succeeds.
 *
 * @param name - The unique name of the plugin to delete.
 *  This identifier is used to construct the URL for the DELETE request.
 * @param type - Optional plugin type ('development' or 'user'). If specified,
 *  only that specific plugin location is checked. If omitted, the backend
 *  will check both locations in priority order.
 *
 * @returns Resolves to the parsed response body if present; otherwise `undefined`.
 * @throws {error} — If the response status is not ok.
 *
 * @example
 * // Call to delete a plugin named 'examplePlugin' from user-plugins
 * deletePlugin('examplePlugin', 'user')
 *   .then(response => console.log('Plugin deleted successfully', response))
 *   .catch(error => console.error('Failed to delete plugin', error));
 */
export declare function deletePlugin(name: string, type?: 'development' | 'user'): Promise<any>;
