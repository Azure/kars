import type { QueryParameters } from './queryParameters';
export declare function buildUrl(urlOrParts: string | string[], queryParams?: QueryParameters): string;
/**
 * Combines a base path and a path to create a full path.
 *
 * Doesn't matter if the start or the end has a single slash, the result will always have a single slash.
 *
 * @param base - The base path.
 * @param path - The path to combine with the base path.
 *
 * @returns The combined path.
 */
export declare function combinePath(base: string, path: string): string;
export declare function getApiRoot(group: string, version: string): string;
/**
 * Converts k8s queryParams to a URL query string.
 *
 * @param queryParams - The k8s API query parameters to convert.
 * @returns The query string (starting with '?'), or empty string.
 */
export declare function asQuery(queryParams?: QueryParameters): string;
