import { FitAddon } from '@xterm/addon-fit';
import { Terminal as XTerminal } from '@xterm/xterm';
/**
 * WebSocket communication channels for terminal I/O.
 */
export declare enum Channel {
    StdIn = 0,
    StdOut = 1,
    StdErr = 2,
    ServerError = 3,
    Resize = 4
}
/**
 * Terminal instance with connection state.
 *
 * @property {XTerminal} xterm - XTerm.js terminal instance
 * @property {boolean} connected - Whether WebSocket is connected
 * @property {boolean} reconnectOnEnter - Whether to reconnect on Enter key
 */
export interface XTerminalConnected {
    xterm: XTerminal;
    connected: boolean;
    reconnectOnEnter: boolean;
}
/**
 * Options for configuring terminal stream behavior.
 */
export interface TerminalStreamOptions {
    /** Function that establishes stream connection */
    connectStream: (onData: (data: ArrayBuffer) => void) => Promise<{
        stream: any;
        initialMessage?: string;
    }>;
    /** Terminal container HTML element */
    containerRef: HTMLElement | null;
    /** Whether terminal should be active */
    enabled?: boolean;
    /** Callback when terminal is closed */
    onClose?: () => void;
    /** Custom error handlers */
    errorHandlers?: {
        isSuccessfulExit?: (channel: number, text: string) => boolean;
        isShellNotFound?: (channel: number, text: string) => boolean;
        onConnectionFailed?: (xtermc: XTerminalConnected) => void;
    };
    /** Whether to detect Windows OS */
    detectOS?: boolean;
    /** Additional xterm configuration */
    xtermOptions?: {
        cursorBlink?: boolean;
        cursorStyle?: 'block' | 'underline' | 'bar';
        scrollback?: number;
        rows?: number;
        windowsMode?: boolean;
    };
}
/**
 * React hook for managing WebSocket-based terminal streams.
 *
 * Sets up an XTerm.js terminal with WebSocket communication, handles I/O channels,
 * resizing, and platform-specific keyboard handling. Auto-connects when enabled
 * and container is available.
 *
 * @param options - Configuration for terminal and stream connection
 * @returns Terminal refs and send function for stdin
 */
export declare function useTerminalStream(options: TerminalStreamOptions): {
    xtermRef: import("react").MutableRefObject<XTerminalConnected | null>;
    fitAddonRef: import("react").MutableRefObject<FitAddon | null>;
    streamRef: import("react").MutableRefObject<any>;
    send: (channel: number, data: string) => void;
};
