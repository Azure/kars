import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeIngressClass extends KubeObjectInterface {
    spec: {
        controller: string;
        [key: string]: any;
    };
}
declare class IngressClass extends KubeObject<KubeIngressClass> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeIngressClass;
    get spec(): KubeIngressClass['spec'];
    get isDefault(): boolean;
    static get listRoute(): string;
    static get pluralName(): string;
}
export default IngressClass;
