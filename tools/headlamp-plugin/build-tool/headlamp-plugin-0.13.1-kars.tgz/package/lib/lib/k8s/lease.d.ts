import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface LeaseSpec {
    holderIdentity: string;
    leaseDurationSeconds: number;
    leaseTransitions: number;
    renewTime: string;
}
export interface KubeLease extends KubeObjectInterface {
    spec: LeaseSpec;
}
export declare class Lease extends KubeObject<KubeLease> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeLease;
    get spec(): LeaseSpec;
}
