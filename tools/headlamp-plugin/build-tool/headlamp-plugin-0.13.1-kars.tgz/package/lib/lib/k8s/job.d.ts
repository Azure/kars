import { KubeContainer, LabelSelector } from './cluster';
import { KubeMetadata } from './KubeMetadata';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
import { KubePodSpec } from './pod';
export interface KubeJob extends KubeObjectInterface {
    spec: {
        selector?: LabelSelector;
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
        [otherProps: string]: any;
    };
    status: {
        [otherProps: string]: any;
    };
}
declare class Job extends KubeObject<KubeJob> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get spec(): {
        [otherProps: string]: any;
        selector?: LabelSelector;
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
    };
    get status(): {
        [otherProps: string]: any;
    };
    getContainers(): KubeContainer[];
    /** Returns the duration of the job in milliseconds. */
    getDuration(): number;
    static getBaseObject(): KubeJob;
}
export default Job;
