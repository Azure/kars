import type { KubeMetadata } from './KubeMetadata';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeEndpointPort {
    name?: string;
    appProtocol: string;
    port: number;
    protocol: string;
}
export interface KubeEndpointAddress {
    hostname: string;
    ip: string;
    nodeName?: string;
    targetRef?: Pick<KubeObjectInterface, 'apiVersion' | 'kind'> & Pick<KubeMetadata, 'name' | 'namespace' | 'resourceVersion' | 'uid'> & {
        fieldPath: string;
    };
}
export interface KubeEndpointSubset {
    addresses?: KubeEndpointAddress[];
    notReadyAddresses?: KubeEndpointAddress[];
    ports?: KubeEndpointPort[];
}
export interface KubeEndpoint extends KubeObjectInterface {
    subsets: KubeEndpointSubset[];
}
declare class Endpoints extends KubeObject<KubeEndpoint> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeEndpoint;
    static get detailsRoute(): string;
    static get className(): string;
    get spec(): any;
    get status(): any;
    get subsets(): KubeEndpointSubset[];
    getAddressesText(): string;
    getAddresses(): string[];
}
export default Endpoints;
