import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeRoleBinding extends KubeObjectInterface {
    roleRef: {
        apiGroup: string;
        kind: string;
        name: string;
    };
    subjects: {
        apiGroup: string;
        kind: string;
        name: string;
        namespace: string;
    }[];
}
declare class RoleBinding extends KubeObject<KubeRoleBinding> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    get roleRef(): {
        apiGroup: string;
        kind: string;
        name: string;
    };
    get subjects(): KubeRoleBinding['subjects'];
}
export default RoleBinding;
