import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubePersistentVolume extends KubeObjectInterface {
    spec: {
        capacity: {
            storage: string;
        };
        [other: string]: any;
    };
    status: {
        message: string;
        phase: string;
        reason: string;
    };
}
declare class PersistentVolume extends KubeObject<KubePersistentVolume> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubePersistentVolume;
    get spec(): {
        [other: string]: any;
        capacity: {
            storage: string;
        };
    };
    get status(): {
        message: string;
        phase: string;
        reason: string;
    };
}
export default PersistentVolume;
