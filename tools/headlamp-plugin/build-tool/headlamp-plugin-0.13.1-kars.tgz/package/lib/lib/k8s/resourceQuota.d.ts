import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
interface spec {
    hard: {
        [key: string]: string;
    };
    scopes?: string[];
    scopeSelector?: {
        matchExpressions: {
            operator: string;
            scopeName: string;
            values: string[];
        }[];
    };
}
interface status {
    hard: {
        [key: string]: string;
    };
    used: {
        [key: string]: string;
    };
}
export interface KubeResourceQuota extends KubeObjectInterface {
    spec: spec;
    status: status;
}
declare class ResourceQuota extends KubeObject<KubeResourceQuota> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeResourceQuota;
    get spec(): spec;
    get status(): status;
    get requests(): string[];
    get limits(): string[];
    get resourceStats(): {
        name: string;
        hard: string;
        used: string;
    }[];
}
export default ResourceQuota;
