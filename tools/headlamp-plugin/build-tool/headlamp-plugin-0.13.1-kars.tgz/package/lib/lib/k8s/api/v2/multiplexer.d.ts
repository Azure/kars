/**
 * WebSocket manager to handle connections across the application.
 * Provides a singleton-like interface for managing WebSocket connections,
 * subscriptions, and message handling. Implements connection multiplexing
 * to optimize network usage.
 */
export declare const WebSocketManager: {
    /** Current WebSocket connection instance */
    socketMultiplexer: WebSocket | null;
    /** Flag to track if a connection attempt is in progress */
    connecting: boolean;
    /** Flag to track if we're reconnecting after a disconnect */
    isReconnecting: boolean;
    /** Map of message handlers for each subscription path */
    listeners: Map<string, Set<(data: any) => void>>;
    /** Set of paths that have received a COMPLETE message */
    completedPaths: Set<string>;
    /** Map of active WebSocket subscriptions with their details */
    activeSubscriptions: Map<string, {
        clusterId: string;
        path: string;
        query: string;
    }>;
    /** Map to track pending unsubscribe operations for debouncing */
    pendingUnsubscribes: Map<string, NodeJS.Timeout>;
    /**
     * Creates a unique key for identifying WebSocket subscriptions
     * @param clusterId - Cluster identifier
     * @param path - API resource path
     * @param query - Query parameters
     * @returns Unique subscription key
     */
    createKey(clusterId: string, path: string, query: string): string;
    /**
     * Establishes or returns an existing WebSocket connection.
     *
     * This implementation uses a polling approach to handle concurrent connection attempts.
     * While not ideal, it's a simple solution that works for most cases.
     *
     * Known limitations:
     * 1. Polls every 100ms which may not be optimal for performance
     * 2. No timeout - could theoretically run forever if connection never opens
     * 3. May miss state changes that happen between polls
     *
     * A more robust solution would use event listeners and Promise caching,
     * but that adds complexity and potential race conditions to handle.
     * The current polling approach, while not perfect, is simple and mostly reliable.
     *
     * @returns Promise resolving to WebSocket connection
     */
    connect(): Promise<WebSocket>;
    /**
     * Resubscribes all active subscriptions to a new socket
     * @param socket - WebSocket connection to subscribe to
     */
    resubscribeAll(socket: WebSocket): void;
    /**
     * Subscribe to WebSocket updates for a specific resource
     * @param clusterId - Cluster identifier
     * @param path - API resource path
     * @param query - Query parameters
     * @param onMessage - Callback for handling incoming messages
     * @returns Promise resolving to cleanup function
     */
    subscribe(clusterId: string, path: string, query: string, onMessage: (data: any) => void): Promise<() => void>;
    /**
     * Unsubscribes from WebSocket updates with debouncing to prevent rapid subscribe/unsubscribe cycles.
     *
     * State Management:
     * - Manages pendingUnsubscribes: Map of timeouts for delayed unsubscription
     * - Manages listeners: Map of message handlers for each subscription
     * - Manages activeSubscriptions: Set of currently active WebSocket subscriptions
     * - Manages completedPaths: Set of paths that have completed their initial data fetch
     *
     * Debouncing Logic:
     * 1. Clears any pending unsubscribe timeout for the subscription
     * 2. Removes the message handler from listeners
     * 3. If no listeners remain, sets a timeout before actually unsubscribing
     * 4. Only sends CLOSE message if no new listeners are added during timeout
     *
     * @param key - Subscription key that uniquely identifies this subscription
     * @param clusterId - Cluster identifier for routing to correct cluster
     * @param path - API resource path being watched
     * @param query - Query parameters for filtering
     * @param onMessage - Message handler to remove from subscription
     */
    unsubscribe(key: string, clusterId: string, path: string, query: string, onMessage: (data: any) => void): void;
    /**
     * Handles WebSocket connection close event
     * Sets up state for potential reconnection
     */
    handleWebSocketClose(): void;
    /**
     * Handles incoming WebSocket messages
     * Processes different message types and notifies appropriate listeners
     * @param event - WebSocket message event
     */
    handleWebSocketMessage(event: MessageEvent): void;
};
/**
 * React hook for WebSocket subscription to Kubernetes resources
 * @template T - Type of data expected from the WebSocket
 * @param options - Configuration options for the WebSocket connection
 * @param options.url - Function that returns the WebSocket URL to connect to
 * @param options.enabled - Whether the WebSocket connection should be active
 * @param options.cluster - The Kubernetes cluster ID to watch
 * @param options.onMessage - Callback function to handle incoming messages
 * @param options.onError - Callback function to handle connection errors
 */
export declare function useWebSocket<T>({ url: createUrl, enabled, cluster, onMessage, onError, }: {
    /** Function that returns the WebSocket URL to connect to */
    url: () => string;
    /** Whether the WebSocket connection should be active */
    enabled?: boolean;
    /** The Kubernetes cluster ID to watch */
    cluster?: string;
    /** Callback function to handle incoming messages */
    onMessage: (data: T) => void;
    /** Callback function to handle connection errors */
    onError?: (error: Error) => void;
}): void;
/**
 * Multiplexer endpoint for WebSocket connections
 * This endpoint allows multiple subscriptions over a single connection
 */
export declare const MULTIPLEXER_ENDPOINT = "wsMultiplexer";
/**
 * Message format for WebSocket communication between client and server.
 * Used to manage subscriptions to Kubernetes resource updates.
 */
export interface WebSocketMessage {
    /**
     * Cluster identifier used to route messages to the correct Kubernetes cluster.
     * This is particularly important in multi-cluster environments.
     */
    clusterId: string;
    /**
     * API resource path that identifies the Kubernetes resource being watched.
     * Example: '/api/v1/pods' or '/apis/apps/v1/deployments'
     */
    path: string;
    /**
     * Query parameters for filtering or modifying the watch request.
     * Example: 'labelSelector=app%3Dnginx&fieldSelector=status.phase%3DRunning'
     */
    query: string;
    /**
     * User identifier for authentication and authorization.
     * Used to ensure users only receive updates for resources they have access to.
     */
    userId: string;
    /**
     * Message type that indicates the purpose of the message:
     * - REQUEST: Client is requesting to start watching a resource
     * - CLOSE: Client wants to stop watching a resource
     * - COMPLETE: Server indicates the watch request has completed (e.g., due to timeout or error)
     */
    type: 'REQUEST' | 'CLOSE' | 'COMPLETE';
}
