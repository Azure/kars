import type { KubeMetadata } from '../../KubeMetadata';
export interface ScaleApi {
    get: (namespace: string, name: string, clusterName?: string) => Promise<any>;
    put: (body: {
        metadata: KubeMetadata;
        spec: {
            replicas: number;
        };
    }, clusterName?: string) => Promise<any>;
    patch: (body: {
        spec: {
            replicas: number;
        };
    }, metadata: KubeMetadata, clusterName?: string) => Promise<any>;
}
export declare function apiScaleFactory(apiRoot: string, resource: string): ScaleApi;
