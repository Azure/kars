import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeRuntimeClass extends KubeObjectInterface {
    handler: string;
    overhead?: any;
    scheduling?: any;
}
export declare class RuntimeClass extends KubeObject<KubeRuntimeClass> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeRuntimeClass;
    get spec(): any;
}
