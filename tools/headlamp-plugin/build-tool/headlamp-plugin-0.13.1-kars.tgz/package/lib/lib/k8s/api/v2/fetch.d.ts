export declare const BASE_HTTP_URL: string;
/**
 * Simple wrapper around Fetch function
 * Sends a request to the backend
 *
 * @param url - URL path
 * @param init - options parameter for the Fetch function
 *
 * @returns fetch Response
 */
export declare function backendFetch(url: string | URL, init?: RequestInit): Promise<Response>;
/**
 * A wrapper around Fetch function
 * Allows sending requests to a particular cluster
 *
 * @param url - URL path
 * @param init - same as second parameter of the Fetch function
 * @param init.cluster - name of the cluster
 *
 * @returns fetch Response
 */
export declare function clusterFetch(url: string | URL, init: RequestInit & {
    cluster: string;
}): Promise<Response>;
