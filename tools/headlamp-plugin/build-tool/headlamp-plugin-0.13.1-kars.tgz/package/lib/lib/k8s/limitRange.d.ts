import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface LimitRangeSpec {
    limits: {
        default: {
            cpu: string;
            memory: string;
        };
        defaultRequest: {
            cpu: string;
            memory: string;
        };
        max: {
            cpu: string;
            memory: string;
        };
        min: {
            cpu: string;
            memory: string;
        };
        type: string;
    }[];
}
export interface KubeLimitRange extends KubeObjectInterface {
    spec: LimitRangeSpec;
}
export declare class LimitRange extends KubeObject<KubeLimitRange> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeLimitRange;
    get spec(): LimitRangeSpec;
}
