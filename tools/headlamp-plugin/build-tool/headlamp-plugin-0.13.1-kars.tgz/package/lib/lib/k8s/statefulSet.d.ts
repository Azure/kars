import type { KubeContainer, LabelSelector } from './cluster';
import type { KubeMetadata } from './KubeMetadata';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
import type { KubePodSpec } from './pod';
export interface KubeStatefulSet extends KubeObjectInterface {
    spec: {
        selector: LabelSelector;
        updateStrategy: {
            rollingUpdate: {
                partition: number;
            };
            type: string;
        };
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
        [other: string]: any;
    };
    status: {
        [otherProps: string]: any;
    };
}
declare class StatefulSet extends KubeObject<KubeStatefulSet> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static isScalable: boolean;
    get spec(): {
        [other: string]: any;
        selector: LabelSelector;
        updateStrategy: {
            rollingUpdate: {
                partition: number;
            };
            type: string;
        };
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
    };
    get status(): {
        [otherProps: string]: any;
    };
    static getBaseObject(): KubeStatefulSet;
    getContainers(): KubeContainer[];
}
export default StatefulSet;
