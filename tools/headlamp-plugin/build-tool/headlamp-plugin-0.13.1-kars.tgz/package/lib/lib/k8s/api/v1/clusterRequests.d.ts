import type { KubeObjectInterface } from '../../KubeObject';
import type { QueryParameters } from './queryParameters';
/**
 * Options for the request.
 */
export interface RequestParams extends RequestInit {
    /** Number of milliseconds to wait for a response. */
    timeout?: number;
    /** Is the request expected to receive JSON data? */
    isJSON?: boolean;
    /** Cluster context name. */
    cluster?: string | null;
    /** Whether to automatically log out the user if there is an authentication error. */
    autoLogoutOnAuthError?: boolean;
}
export interface ClusterRequest {
    /** The name of the cluster (has to be unique, or it will override an existing cluster) */
    name?: string;
    /** The cluster URL */
    server?: string;
    /** Whether the server's certificate should not be checked for validity */
    insecureTLSVerify?: boolean;
    /** The certificate authority data */
    certificateAuthorityData?: string;
    /** KubeConfig (base64 encoded)*/
    kubeconfig?: string;
}
/**
 * The options for `clusterRequest`.
 */
export interface ClusterRequestParams extends RequestParams {
    cluster?: string | null;
    autoLogoutOnAuthError?: boolean;
}
/**
 * @returns Auth type of the cluster, or an empty string if the cluster is not found.
 * It could return 'oidc' or '' for example.
 *
 * @param cluster - Name of the cluster.
 */
export declare function getClusterAuthType(cluster: string): string;
/**
 * Sends a request to the backend. If the useCluster parameter is true (which it is, by default), it will be
 * treated as a request to the Kubernetes server of the currently defined (in the URL) cluster.
 *
 * @param path - The path to the API endpoint.
 * @param params - Optional parameters for the request.
 * @param autoLogoutOnAuthError - Whether to automatically log out the user if there is an authentication error.
 * @param useCluster - Whether to use the current cluster for the request.
 * @param queryParams - Optional query parameters for the request.
 *
 * @returns A Promise that resolves to the JSON response from the API server.
 * @throws An ApiError if the response status is not ok.
 */
export declare function request(path: string, params?: RequestParams, autoLogoutOnAuthError?: boolean, useCluster?: boolean, queryParams?: QueryParameters): Promise<any>;
/**
 * Sends a request to the backend. If the cluster is required in the params parameter, it will
 * be used as a request to the respective Kubernetes server.
 *
 * @param path - The path to the API endpoint.
 * @param params - Optional parameters for the request.
 * @param queryParams - Optional query parameters for the k8s request.
 *
 * @returns A Promise that resolves to the JSON response from the API server.
 * @throws An ApiError if the response status is not ok.
 */
export declare function clusterRequest(path: string, params?: ClusterRequestParams, queryParams?: QueryParameters): Promise<any>;
export declare function post(url: string, json: JSON | object | KubeObjectInterface, autoLogoutOnAuthError?: boolean, options?: ClusterRequestParams): Promise<any>;
export declare function patch(url: string, json: any, autoLogoutOnAuthError?: boolean, options?: ClusterRequestParams): Promise<any>;
export declare function put(url: string, json: Partial<KubeObjectInterface>, autoLogoutOnAuthError?: boolean, requestOptions?: ClusterRequestParams): Promise<any>;
export declare function remove(url: string, requestOptions?: ClusterRequestParams): Promise<any>;
