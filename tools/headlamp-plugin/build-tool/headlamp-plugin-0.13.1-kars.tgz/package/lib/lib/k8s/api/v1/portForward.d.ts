export interface PortForward {
    id: string;
    pod: string;
    service: string;
    serviceNamespace: string;
    namespace: string;
    cluster: string;
    port: string;
    targetPort: string;
    status?: string;
    error?: string;
}
export interface PortForwardRequest {
    id: string;
    namespace: string;
    pod: string;
    service: string;
    serviceNamespace: string;
    targetPort: string;
    port?: string;
    address?: string;
}
/**
 * Starts a portforward with the given details.
 *
 * @param cluster - The cluster to portforward for.
 * @param namespace - The namespace to portforward for.
 * @param podname - The pod to portforward for.
 * @param containerPort - The container port to portforward for.
 * @param service - The service to portforward for.
 * @param serviceNamespace - The service namespace to portforward for.
 * @param port - The port to portforward for.
 * @param id - The id to portforward for.
 *
 * @returns The response from the API.
 * @throws {Error} if the request fails.
 */
export declare function startPortForward(cluster: string, namespace: string, podname: string, containerPort: number | string, service: string, serviceNamespace: string, port?: string, address?: string, id?: string): Promise<PortForward>;
/**
 * Stops or deletes a portforward with the specified details.
 *
 * @param cluster - The cluster to portforward for.
 * @param id - The id to portforward for.
 * @param stopOrDelete - Whether to stop or delete the portforward. True for stop, false for delete.
 *
 * @returns The response from the API.
 * @throws {Error} if the request fails.
 */
export declare function stopOrDeletePortForward(cluster: string, id: string, stopOrDelete?: boolean): Promise<string>;
/**
 * Lists the port forwards for the specified cluster.
 *
 * @param cluster - The cluster to list the port forwards.
 *
 * @returns the list of port forwards for the cluster.
 */
export declare function listPortForward(cluster: string): Promise<PortForward[]>;
