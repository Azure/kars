import type { KubeObjectInterface } from '../../KubeObject';
import { KubeObject } from '../../KubeObject';
export interface KubeList<T extends KubeObjectInterface> {
    kind: string;
    apiVersion: string;
    items: T[];
    metadata: {
        resourceVersion: string;
    };
}
export interface KubeListUpdateEvent<T extends KubeObjectInterface> {
    type: 'ADDED' | 'MODIFIED' | 'DELETED' | 'ERROR';
    object: T;
}
export declare const KubeList: {
    /**
     * Apply an update event to the existing list
     *
     * @param list - List of kubernetes resources
     * @param update - Update event to apply to the list
     * @param itemClass - Class of an item in the list. Used to instantiate each item
     * @returns New list with the updated values
     */
    applyUpdate<ObjectInterface extends KubeObjectInterface, ObjectClass extends typeof KubeObject<ObjectInterface>>(list: KubeList<KubeObject<ObjectInterface>>, update: KubeListUpdateEvent<ObjectInterface>, itemClass: ObjectClass, cluster: string): KubeList<KubeObject<ObjectInterface>>;
};
