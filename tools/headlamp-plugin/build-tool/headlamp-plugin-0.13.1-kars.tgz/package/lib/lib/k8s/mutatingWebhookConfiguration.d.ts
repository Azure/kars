import type { LabelSelector } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
export interface KubeRuleWithOperations {
    apiGroups: string[];
    apiVersions: string[];
    operations: string[];
    resources: string[];
    scope?: string;
}
export interface KubeWebhookClientConfig {
    caBundle: string;
    url?: string;
    service?: {
        name: string;
        namespace: string;
        path?: string;
        port?: number;
    };
}
export interface KubeMutatingWebhookConfiguration extends KubeObjectInterface {
    webhooks: {
        admissionReviewVersions: string[];
        clientConfig: KubeWebhookClientConfig;
        failurePolicy?: string;
        matchPolicy?: string;
        name: string;
        namespaceSelector?: {
            matchExpressions: LabelSelector['matchExpressions'];
            matchLabels: LabelSelector['matchLabels'];
        };
        objectSelector?: {
            matchExpressions: LabelSelector['matchExpressions'];
            matchLabels: LabelSelector['matchLabels'];
        };
        reinvocationPolicy?: string;
        rules?: KubeRuleWithOperations[];
        sideEffects?: string;
        timeoutSeconds?: number;
    }[];
}
declare class MutatingWebhookConfiguration extends KubeObject<KubeMutatingWebhookConfiguration> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static getBaseObject(): KubeMutatingWebhookConfiguration;
    get webhooks(): KubeMutatingWebhookConfiguration['webhooks'];
}
export default MutatingWebhookConfiguration;
