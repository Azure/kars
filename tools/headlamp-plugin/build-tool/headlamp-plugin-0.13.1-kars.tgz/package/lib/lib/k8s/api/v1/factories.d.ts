import type { OpPatch } from 'json-patch';
import type { KubeObjectInterface } from '../../KubeObject';
import type { DeleteParameters } from './deleteParameters';
import type { QueryParameters } from './queryParameters';
import { type ScaleApi } from './scaleApi';
import type { StreamErrCb, StreamResultsCb } from './streamingApi';
export type CancelFunction = () => void;
export type SingleApiFactoryArguments = [group: string, version: string, resource: string];
export type MultipleApiFactoryArguments = SingleApiFactoryArguments[];
export type ApiFactoryArguments = SingleApiFactoryArguments | MultipleApiFactoryArguments;
export type SimpleApiFactoryWithNamespaceArguments = [
    group: string,
    version: string,
    resource: string,
    includeScale?: boolean
];
export type MultipleApiFactoryWithNamespaceArguments = SimpleApiFactoryWithNamespaceArguments[];
export type ApiFactoryWithNamespaceArguments = SimpleApiFactoryWithNamespaceArguments | MultipleApiFactoryWithNamespaceArguments;
export type RecursivePartial<T> = {
    [P in keyof T]?: T[P] extends (infer U)[] ? RecursivePartial<U>[] : T[P] extends object | undefined ? RecursivePartial<T[P]> : T[P];
};
export interface ApiClient<ResourceType extends KubeObjectInterface> {
    list: (cb: StreamResultsCb<ResourceType>, errCb: StreamErrCb, queryParams?: QueryParameters, cluster?: string) => Promise<CancelFunction>;
    get: (name: string, cb: StreamResultsCb<ResourceType>, errCb: StreamErrCb, queryParams?: QueryParameters, cluster?: string) => Promise<CancelFunction>;
    post: (body: RecursivePartial<ResourceType>, queryParams?: QueryParameters, cluster?: string) => Promise<ResourceType>;
    put: (body: ResourceType, queryParams?: QueryParameters, cluster?: string) => Promise<ResourceType>;
    patch: (body: OpPatch[], name: string, queryParams?: QueryParameters, cluster?: string) => Promise<ResourceType>;
    delete: (name: string, deleteParams?: DeleteParameters, cluster?: string) => Promise<any>;
    isNamespaced: boolean;
    apiInfo: {
        group: string;
        version: string;
        resource: string;
    }[];
}
export interface ApiWithNamespaceClient<ResourceType extends KubeObjectInterface> {
    list: (namespace: string, cb: StreamResultsCb<ResourceType>, errCb: StreamErrCb, queryParams?: QueryParameters, cluster?: string) => Promise<CancelFunction>;
    get: (namespace: string, name: string, cb: StreamResultsCb<ResourceType>, errCb: StreamErrCb, queryParams?: QueryParameters, cluster?: string) => Promise<CancelFunction>;
    post: (body: RecursivePartial<KubeObjectInterface>, queryParams?: QueryParameters, cluster?: string) => Promise<any>;
    put: (body: KubeObjectInterface, queryParams?: QueryParameters, cluster?: string) => Promise<ResourceType>;
    patch: (body: OpPatch[], namespace: string, name: string, queryParams?: QueryParameters, cluster?: string) => Promise<any>;
    delete: (namespace: string, name: string, deleteParams?: DeleteParameters, cluster?: string) => Promise<any>;
    isNamespaced: boolean;
    apiInfo: {
        group: string;
        version: string;
        resource: string;
    }[];
    scale?: ScaleApi;
}
/**
 * Creates an API client for a single or multiple Kubernetes resources.
 *
 * @param args - The arguments to pass to either `singleApiFactory` or `multipleApiFactory`.
 *
 * @returns An API client for the specified Kubernetes resource(s).
 */
export declare function apiFactory<ResourceType extends KubeObjectInterface = KubeObjectInterface>(...args: ApiFactoryArguments): ApiClient<ResourceType>;
/**
 * Creates an API endpoint object for multiple API endpoints.
 * It first tries the first endpoint, then the second, and so on until it
 * gets a successful response.
 *
 * @param args - An array of arguments to pass to the `singleApiFactory` function.
 *
 * @returns An API endpoint object.
 */
export declare function multipleApiFactory<T extends KubeObjectInterface>(...args: MultipleApiFactoryArguments): ApiClient<T>;
/**
 * Describes the API for a certain resource.
 */
export interface ApiInfo {
    /** The API group. */
    group: string;
    /** The API version. */
    version: string;
    /** The resource name. */
    resource: string;
}
/**
 * @returns An object with methods for interacting with a single API endpoint.
 *
 * @param group - The API group.
 * @param version - The API version.
 * @param resource - The API resource.
 */
export declare function singleApiFactory<T extends KubeObjectInterface>(...[group, version, resource]: SingleApiFactoryArguments): ApiClient<T>;
export declare function apiFactoryWithNamespace<T extends KubeObjectInterface>(...args: ApiFactoryWithNamespaceArguments): ApiWithNamespaceClient<T>;
export declare function resourceDefToApiFactory<ResourceType extends KubeObjectInterface>(resourceDef: KubeObjectInterface, clusterName?: string): Promise<ApiClient<ResourceType> | ApiWithNamespaceClient<ResourceType>>;
