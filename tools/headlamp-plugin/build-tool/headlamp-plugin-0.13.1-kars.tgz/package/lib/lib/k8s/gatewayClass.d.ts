import type { KubeCondition } from './cluster';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
/**
 * GatewayClass is cluster-scoped resource defined by the infrastructure provider. This resource represents a class of Gateways that can be instantiated.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.GatewayClass} Gateway API reference for GatewayClass
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/gatewayclass/} Gateway API definition for GatewayClass
 */
export interface KubeGatewayClass extends KubeObjectInterface {
    spec: {
        controllerName: string;
        [key: string]: any;
    };
    status: {
        conditions?: KubeCondition[];
        [otherProps: string]: any;
    };
}
declare class GatewayClass extends KubeObject<KubeGatewayClass> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): KubeGatewayClass['spec'];
    get status(): {
        [otherProps: string]: any;
        conditions?: KubeCondition[];
    };
    get controllerName(): string;
    static get listRoute(): string;
    static get pluralName(): string;
}
export default GatewayClass;
