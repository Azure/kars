import type { KubeCondition } from './cluster';
import { KubeObject, type KubeObjectInterface } from './KubeObject';
/**
 * ParentReference identifies an API object (usually a Gateway) that can be considered a parent of this resource (usually a route).
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.ParentReference} Gateway API reference for ParentReference
 */
export interface GatewayParentReference {
    group?: string;
    kind?: string;
    namespace?: string;
    sectionName?: string;
    name: string;
    port?: number;
}
/**
 * Listener embodies the concept of a logical endpoint where a Gateway accepts network connections.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.Listener} Gateway API reference for Listener
 */
export interface GatewayListener {
    hostname: string;
    name: string;
    protocol: string;
    port: number;
    [key: string]: any;
}
/**
 * ListenerStatus is the status associated with a Listener.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.ListenerStatus} Gateway API reference for ListenerStatus
 */
export interface GatewayListenerStatus {
    name: string;
    attachedRoutes: number;
    supportedKinds: any[];
    conditions: KubeCondition[];
}
/**
 * GatewayStatusAddress describes a network address that is bound to a Gateway.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.GatewayStatusAddress} Gateway API reference for GatewayStatusAddress
 */
export interface GatewayStatusAddress {
    type?: string;
    value: string;
}
/**
 * Gateway represents an instance of a service-traffic handling infrastructure by binding Listeners to a set of IP addresses.
 *
 * @see {@link https://gateway-api.sigs.k8s.io/reference/spec/#gateway.networking.k8s.io/v1.Gateway} Gateway API reference for Gateway
 *
 * @see {@link https://gateway-api.sigs.k8s.io/api-types/gateway/} Gateway API definition for Gateway
 */
export interface KubeGateway extends KubeObjectInterface {
    spec: {
        gatewayClassName?: string;
        listeners: GatewayListener[];
        [key: string]: any;
    };
    status: {
        addresses?: GatewayStatusAddress[];
        listeners?: GatewayListenerStatus[];
        conditions?: KubeCondition[];
        [otherProps: string]: any;
    };
}
declare class Gateway extends KubeObject<KubeGateway> {
    static kind: string;
    static apiName: string;
    static apiVersion: string[];
    static isNamespaced: boolean;
    get spec(): KubeGateway['spec'];
    get status(): {
        [otherProps: string]: any;
        addresses?: GatewayStatusAddress[];
        listeners?: GatewayListenerStatus[];
        conditions?: KubeCondition[];
    };
    getListeners(): GatewayListener[];
    getAddresses(): GatewayStatusAddress[];
    getListernerStatusByName(name: string): GatewayListenerStatus | null;
    static get pluralName(): string;
}
export default Gateway;
