/**
 * Error with additional information about the request that casued it
 * Used for backend response error handling
 */
export declare class ApiError extends Error {
    message: string;
    /** HTTP status code of the error */
    status?: number;
    /** Namespace of the requested resource */
    namespace?: string;
    /** Cluster name */
    cluster?: string;
    constructor(message: string, props?: {
        status?: number;
        namespace?: string;
        cluster?: string;
    });
}
