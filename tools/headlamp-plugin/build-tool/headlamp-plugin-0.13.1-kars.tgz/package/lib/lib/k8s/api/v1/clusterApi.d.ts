import type { ConfigState } from '../../../../redux/configSlice';
import type { ClusterRequest } from './clusterRequests';
/**
 * Test authentication for the given cluster.
 * Will throw an error if the user is not authenticated.
 */
export declare function testAuth(cluster?: string, namespace?: string): Promise<any>;
/**
 * Checks cluster health
 * Will throw an error if the cluster is not healthy.
 */
export declare function testClusterHealth(cluster?: string): Promise<any[]>;
export declare function setCluster(clusterReq: ClusterRequest): Promise<any>;
/**
 * deleteCluster sends call to backend remove a cluster from the config.
 *
 * Note: Currently, the use for the optional clusterID is only for the clusterID for non-dynamic clusters.
 * It is not needed or used for dynamic clusters.
 * @param cluster
 * @param source
 * @param clusterID
 */
export declare function deleteCluster(
/** The name of the cluster to delete */
cluster: string, 
/** Whether to remove the kubeconfig file associated with the cluster */
removeKubeConfig?: boolean, 
/** The ID for a cluster, composed of the kubeconfig path and cluster name */
clusterID?: string, kubeconfigOrigin?: string, originalName?: string): Promise<{
    clusters: ConfigState['clusters'];
}>;
/**
 * getClusterDefaultNamespace gives the default namespace for the given cluster.
 *
 * If the checkSettings parameter is true (default), it will check the cluster settings first.
 * Otherwise it will just check the cluster config. This means that if one needs the default
 * namespace that may come from the kubeconfig, call this function with the checkSettings parameter as false.
 *
 * @param cluster The cluster name.
 * @param checkSettings Whether to check the settings for the default namespace (otherwise it just checks the cluster config). Defaults to true.
 *
 * @returns The default namespace for the given cluster.
 */
export declare function getClusterDefaultNamespace(cluster: string, checkSettings?: boolean): string;
/**
 * renameCluster sends call to backend to update a field in kubeconfig which
 * is the custom name of the cluster used by the user.
 *
 * Note: Currently, the use for the optional clusterID is only for the clusterID for non-dynamic clusters.
 * It is not needed or used for dynamic clusters.
 * @param cluster
 * @param newClusterName
 * @param source
 * @param clusterID
 */
export declare function renameCluster(
/** The name of the cluster to rename */
cluster: string, 
/** The new name for the cluster */
newClusterName: string, 
/** The source of the cluster, either 'kubeconfig' or 'dynamic_cluster' */
source: string, 
/** The ID for a cluster, composed of the kubeconfig path and cluster name */
clusterID?: string): Promise<any>;
/**
 * parseKubeConfig sends call to backend to parse kubeconfig and send back
 * the parsed clusters and contexts.
 * @param clusterReq - The cluster request object.
 */
export declare function parseKubeConfig(clusterReq: ClusterRequest): Promise<any>;
