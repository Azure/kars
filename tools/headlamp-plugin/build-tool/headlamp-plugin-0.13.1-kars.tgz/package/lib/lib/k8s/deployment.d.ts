import type { KubeContainer, LabelSelector } from './cluster';
import type { KubeMetadata } from './KubeMetadata';
import type { KubeObjectInterface } from './KubeObject';
import { KubeObject } from './KubeObject';
import type { KubePodSpec } from './pod';
export interface KubeDeployment extends KubeObjectInterface {
    spec: {
        selector?: LabelSelector;
        strategy?: {
            type: string;
            [otherProps: string]: any;
        };
        template: {
            metadata?: KubeMetadata;
            spec: KubePodSpec;
        };
        [otherProps: string]: any;
    };
    status: {
        [otherProps: string]: any;
    };
}
declare class Deployment extends KubeObject<KubeDeployment> {
    static kind: string;
    static apiName: string;
    static apiVersion: string;
    static isNamespaced: boolean;
    static isScalable: boolean;
    get spec(): any;
    get status(): any;
    getContainers(): KubeContainer[];
    getMatchLabelsList(): string[];
    static getBaseObject(): KubeDeployment;
}
export default Deployment;
