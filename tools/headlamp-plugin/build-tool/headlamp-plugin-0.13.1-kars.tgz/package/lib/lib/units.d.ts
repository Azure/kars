export declare const TO_GB: number;
export declare const TO_ONE_M_CPU = 1000000;
export declare const TO_ONE_CPU = 1000000000;
export declare function parseDiskSpace(value: string): number;
export declare function parseRam(value: string): number;
export declare function unparseRam(value: number): {
    value: number;
    unit: string;
};
export declare function parseCpu(value: string): number;
export declare function unparseCpu(value: string): {
    value: number;
    unit: string;
};
