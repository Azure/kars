import React from 'react';
import { filterGeneric, filterResource } from '../redux/filterSlice';
import { getCluster, getClusterGroup, getClusterPrefixedPath } from './cluster';
import type { ApiError } from './k8s/api/v2/ApiError';
import type { KubeMetrics } from './k8s/cluster';
import type { KubeEvent } from './k8s/event';
import type { KubeObjectInterface } from './k8s/KubeObject';
import Node from './k8s/node';
import type { Workload } from './k8s/Workload';
export { filterGeneric, filterResource, getClusterPrefixedPath, getCluster, getClusterGroup };
export declare const CLUSTER_ACTION_GRACE_PERIOD = 5000;
export type DateParam = string | number | Date;
export type DateFormatOptions = 'brief' | 'mini';
export interface TimeAgoOptions {
    format?: DateFormatOptions;
}
/**
 * Show the time passed since the given date, in the desired format.
 *
 * @param date - The date since which to calculate the duration.
 * @param options - `format` takes "brief" or "mini". "brief" rounds the date and uses the largest suitable unit (e.g. "4 weeks"). "mini" uses something like "4w" (for 4 weeks).
 * @returns The formatted date.
 */
export declare function timeAgo(date: DateParam, options?: TimeAgoOptions): string;
/** Format a duration in milliseconds to a human-readable string.
 *
 * @param duration - The duration in milliseconds.
 * @param options - `format` takes "brief" or "mini". "brief" rounds the date and uses the largest suitable unit (e.g. "4 weeks"). "mini" uses something like "4w" (for 4 weeks).
 * @returns The formatted duration.
 * */
export declare function formatDuration(duration: number, options?: TimeAgoOptions): string;
export declare function localeDate(date: DateParam): string;
export declare function getPercentStr(value: number, total: number): string | null;
export declare function getReadyReplicas(item: Workload): any;
export declare function getTotalReplicas(item: Workload): any;
export declare function getResourceStr(value: number, resourceType: 'cpu' | 'memory'): string;
export declare function getResourceMetrics(item: Node, metrics: KubeMetrics[], resourceType: 'cpu' | 'memory'): any[];
/**
 * Get a function to filter kube resources based on the current global filter state.
 *
 * @returns A filter function that can be used to filter a list of items.
 * @param matchCriteria - The JSONPath criteria to match.
 */
export declare function useFilterFunc<T extends {
    [key: string]: any;
} | KubeObjectInterface | KubeEvent = KubeObjectInterface | KubeEvent>(matchCriteria?: string[]): (item: T, search?: string) => boolean;
export declare function useErrorState(dependentSetter?: (...args: any) => void): readonly [ApiError | null, React.Dispatch<React.SetStateAction<ApiError | null>>];
/**
 * This function joins a list of items per cluster into a single list of items.
 *
 * @param args The list of objects per cluster to join.
 * @returns The joined list of items, or null if there are no items.
 */
export declare function flattenClusterListItems<T>(...args: ({
    [cluster: string]: T[] | null;
} | null)[]): T[] | null;
/**
 * Combines errors per cluster.
 *
 * @param args The list of errors per cluster to join.
 * @returns The joint list of errors, or null if there are no errors.
 */
export declare function combineClusterListErrors(...args: ({
    [cluster: string]: ApiError | null;
} | null)[]): {
    [cluster: string]: ApiError | null;
} | null;
type URLStateParams<T> = {
    /** The defaultValue for the URL state. */
    defaultValue: T;
    /** Whether to hide the parameter when the value is the default one (true by default). */
    hideDefault?: boolean;
    /** The prefix of the URL key to use for this state (a prefix 'my' with a key name 'key' will be used in the URL as 'my.key'). */
    prefix?: string;
};
export declare function useURLState(key: string, defaultValue: number): [number, React.Dispatch<React.SetStateAction<number>>];
export declare function useURLState(key: string, valueOrParams: number | URLStateParams<number>): [number, React.Dispatch<React.SetStateAction<number>>];
export declare function compareUnits(quantity1: string, quantity2: string): boolean;
export declare function normalizeUnit(resourceType: string, quantity: string): string;
/** Creates a unique ID, with the given prefix.
 * If UNDER_TEST is set to true, it will return the same ID every time, so snapshots do not get invalidated.
 */
export declare function useId(prefix?: string): string | undefined;
export * as auth from './auth';
export * as units from './units';
