import { Notification } from '../components/App/Notifications/notificationsSlice';
export declare function setNotificationsInStore(notifications: Notification[] | Notification): void;
