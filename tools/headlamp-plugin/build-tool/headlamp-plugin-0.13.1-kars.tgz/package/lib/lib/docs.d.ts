import type { OpenAPIV2 } from 'openapi-types';
export declare function resetDocsPromise(): void;
export default function getDocDefinitions(apiVersion: string, kind: string): Promise<OpenAPIV2.SchemaObject | undefined>;
