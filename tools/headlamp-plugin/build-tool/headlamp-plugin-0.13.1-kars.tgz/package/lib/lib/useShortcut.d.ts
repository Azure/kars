import { Options } from 'react-hotkeys-hook';
/**
 * A wrapper around useHotkeys that uses configurable shortcuts from the Redux store.
 *
 * @param shortcutId - The ID of the shortcut (e.g., 'GLOBAL_SEARCH', 'CLUSTER_CHOOSER')
 * @param callback - The callback function to execute when the shortcut is triggered
 * @param options - Additional options to pass to useHotkeys
 * @param deps - Dependencies array for the callback
 */
export declare function useShortcut(shortcutId: string, callback: (event: KeyboardEvent) => void, options?: Options, deps?: any[]): (instance: import("react-hotkeys-hook/dist/types").RefType<HTMLElement>) => void;
/**
 * Get the display string for a shortcut key combination.
 * Converts 'ctrl+shift+l' to 'Ctrl+Shift+L' for display purposes.
 *
 * @param key - The shortcut key string
 * @returns A formatted display string
 */
export declare function formatShortcutKey(key: string): string;
/**
 * Hook to get the current shortcut key for a given shortcut ID
 *
 * @param shortcutId - The ID of the shortcut
 * @returns The current key combination string
 */
export declare function useShortcutKey(shortcutId: string): string;
