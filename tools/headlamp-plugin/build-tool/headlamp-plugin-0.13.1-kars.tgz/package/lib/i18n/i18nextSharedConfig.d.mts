declare namespace _default {
    let contextSeparator: string;
    let namespaces: string[];
    let defaultNamespace: string;
    let localesPath: string;
}
export default _default;
