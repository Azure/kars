import { FormControlProps } from '@mui/material/FormControl';
export interface LocaleSelectProps {
    /** Whether to show the title label above the select dropdown. */
    showTitle?: boolean;
    /** Whether to display full names of languages instead of their language codes. */
    showFullNames?: boolean;
    /** Additional props to pass to the underlying Material-UI `FormControl` component. */
    formControlProps?: FormControlProps;
}
/**
 * A UI for selecting the locale with i18next
 */
export default function LocaleSelect(props: LocaleSelectProps): import("react/jsx-runtime").JSX.Element;
