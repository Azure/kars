import i18next from 'i18next';
export declare const supportedLanguages: {
    [langCode: string]: string;
};
export default i18next;
