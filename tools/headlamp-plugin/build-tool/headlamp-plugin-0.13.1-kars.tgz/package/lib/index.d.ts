import { Theme } from '@mui/material/styles';
declare module '@mui/private-theming' {
    interface DefaultTheme extends Theme {
    }
}
import { Activity } from './components/activity/Activity';
import * as CommonComponents from './components/common';
import * as K8s from './lib/k8s';
import * as ApiProxy from './lib/k8s/apiProxy';
import * as Notification from './lib/notification';
import * as Router from './lib/router';
import * as Utils from './lib/util';
import { Headlamp, Plugin } from './plugin/lib';
import { getSupportedLocales, isLocaleSupported, useTranslation } from './plugin/pluginI18n';
import { PluginSettingsDetailsProps } from './plugin/pluginsSlice';
import type { CallbackActionOptions, HeadlampEvent } from './plugin/registry';
import Registry, { AppLogoProps, clusterAction, ClusterChooserProps, ConfigStore, DefaultAppBarAction, DefaultDetailsViewSection, DefaultHeadlampEvents, DefaultSidebars, DetailsViewDefaultHeaderActions, DetailsViewSectionProps, getHeadlampAPIHeaders, PluginManager, registerAddClusterProvider, registerAppBarAction, registerAppLogo, registerAppTheme, registerClusterChooser, registerClusterProviderDialog, registerClusterProviderMenuItem, registerClusterStatus, registerCustomCreateProject, registerDetailsViewHeaderAction, registerDetailsViewHeaderActionsProcessor, registerDetailsViewSection, registerDetailsViewSectionsProcessor, registerGetTokenFunction, registerHeadlampEventCallback, registerKindIcon, registerKubeObjectGlance, registerMapSource, registerOverviewChartsProcessor, registerPluginSettings, registerProjectDeleteButton, registerProjectDetailsTab, registerProjectHeaderAction, registerProjectOverviewSection, registerResourceTableColumnsProcessor, registerRoute, registerRouteFilter, registerSidebarEntry, registerSidebarEntryFilter, registerUIPanel, runCommand } from './plugin/registry';
export { ApiProxy, K8s, K8s as k8s, CommonComponents, Utils, Router, Plugin, Registry, Headlamp, Notification, DefaultAppBarAction, DefaultDetailsViewSection, DefaultHeadlampEvents, DetailsViewDefaultHeaderActions, getHeadlampAPIHeaders, registerAppLogo, registerAppBarAction, registerClusterChooser, registerDetailsViewHeaderAction, registerDetailsViewSection, registerDetailsViewSectionsProcessor, registerRoute, registerRouteFilter, registerSidebarEntry, registerSidebarEntryFilter, registerDetailsViewHeaderActionsProcessor, registerGetTokenFunction, registerResourceTableColumnsProcessor, registerOverviewChartsProcessor, registerPluginSettings, clusterAction, runCommand, registerAddClusterProvider, registerClusterProviderDialog, registerClusterProviderMenuItem, registerHeadlampEventCallback, ConfigStore, registerKindIcon, registerMapSource, PluginManager, registerUIPanel, registerAppTheme, registerKubeObjectGlance, useTranslation, isLocaleSupported, getSupportedLocales, registerCustomCreateProject, registerProjectDetailsTab, registerProjectOverviewSection, registerProjectHeaderAction, registerClusterStatus, registerProjectDeleteButton, Activity, };
export type { AppLogoProps, PluginSettingsDetailsProps, CallbackActionOptions, ClusterChooserProps, DetailsViewSectionProps, DefaultSidebars, HeadlampEvent, };
