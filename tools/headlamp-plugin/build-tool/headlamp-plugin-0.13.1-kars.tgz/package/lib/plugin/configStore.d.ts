/**
 * A class to manage the configuration state for plugins in a Redux store.
 *
 * @template T - The type of the configuration object.
 */
export declare class ConfigStore<T> {
    private configKey;
    /**
     * Creates an instance of the ConfigStore class.
     *
     * @param {string} configKey - The key to identify the specific plugin configuration.
     */
    constructor(configKey: string);
    /**
     * Sets the entire configuration for a specific plugin.
     *
     * This method will overwrite the entire configuration object for the given key.
     *
     * @param {T} configValue - The new configuration object.
     */
    set(configValue: T): void;
    /**
     * Updates the configuration for a specific plugin.
     *
     * This method will merge the provided partial updates into the current configuration object.
     *
     * @param {Partial<T>} partialUpdates - An object containing the updates to be merged into the current configuration.
     */
    update(partialUpdates: Partial<T>): void;
    /**
     * Retrieves the current configuration for the specified key from the Redux store.
     *
     * @returns The current configuration object.
     */
    get(): T;
    /**
     * Creates a custom React hook for accessing the plugin's configuration state reactively.
     *
     * This hook allows components to access and react to changes in the plugin's configuration.
     *
     * @returns A custom React hook that returns the configuration state.
     */
    useConfig(): () => T;
}
