import { PluginInfo } from './pluginsSlice';
/**
 * Load external, then local plugins. Then initialize() them in order with a Registry.
 */
export declare function initializePlugins(): Promise<unknown>;
/**
 * This can be used to filter out which of the plugins we should execute.
 *
 * @param sources array of source to execute. Has the same order as packageInfos.
 * @param packageInfos array of package.json contents
 * @param appMode if we are in app mode
 * @param compatibleVersion headlamp-plugin version this build is compatible with.
 *     If the plugin engine version is not compatible, the plugin will not be loaded.
 *     Can be set to a semver range, e.g. '>= 0.6.0' or '0.6.0 - 0.7.0'.
 *     If set to an empty string, all plugin versions will be loaded.
 * @param settingsPackages the packages from settings
 *
 * @returns the sources to execute and incompatible PackageInfos
 *          with this structure { sourcesToExecute, incompatiblePackageInfos }
 */
export declare function filterSources(sources: string[], packageInfos: PluginInfo[], appMode: boolean, compatibleVersion: string, settingsPackages?: PluginInfo[]): {
    sourcesToExecute: string[];
    incompatiblePlugins: Record<string, PluginInfo>;
};
/**
 * Apply priority-based plugin loading logic.
 *
 * When multiple versions of the same plugin exist across different locations:
 * - Priority order: development > user > shipped
 * - Only the highest priority ENABLED version is loaded
 * - If a higher priority version is disabled, the next enabled version is loaded
 * - Lower priority versions are marked with isLoaded=false and overriddenBy info
 *
 * @param plugins List of all plugins from all locations
 * @returns Plugins with isLoaded and overriddenBy fields set appropriately
 */
export declare function applyPluginPriority(plugins: PluginInfo[]): PluginInfo[];
/**
 * Updates settings packages based on what the backend provides.
 *
 * - For new plugins (not in settings), includes them with isEnabled=true
 * - For existing plugins (in settings), preserves their isEnabled preference
 * - Returns only plugins that exist in the backend list (automatically removing any that are gone)
 * - Treats plugins with the same name but different types as separate entries
 * - Each plugin is identified by name + type combination
 *
 * @param backendPlugins the list of plugins info from the backend.
 * @param settingsPlugins the list of plugins the settings already knows about.
 * @returns plugin info for the settings (only includes plugins from backend).
 */
export declare function updateSettingsPackages(backendPlugins: PluginInfo[], settingsPlugins: PluginInfo[]): PluginInfo[];
/**
 * Get the list of plugins,
 *   download all the plugin source,
 *   download all the plugin package.json files,
 *   apply priority-based filtering (dev > user > shipped),
 *   filter incompatible plugins and respect enable/disable settings,
 *   execute only the highest priority enabled version of each plugin,
 *   initialize() plugins that register.
 *
 * @param settingsPackages The packages settings knows about.
 * @param onSettingsChange Called when the plugins are different to what is in settings.
 * @param onIncompatible Called when there are incompatible plugins.
 *
 */
export declare function fetchAndExecutePlugins(settingsPackages: PluginInfo[], onSettingsChange: (plugins: PluginInfo[]) => void, onIncompatible: (plugins: Record<string, PluginInfo>) => void): Promise<void>;
/**
 * Asks the main electron process for the permission secrets.
 *
 * @returns promise with permissions secrets like { 'runCmd-minikube': 1235555 }
 */
export declare function permissionSecretsFromApp(): Promise<Record<string, number>>;
