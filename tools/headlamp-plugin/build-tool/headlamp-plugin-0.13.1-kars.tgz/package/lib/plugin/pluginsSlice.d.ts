import { PayloadAction } from '@reduxjs/toolkit';
import React, { ReactElement } from 'react';
/**
 * Props for PluginSettingsDetailsProps component.
 */
export interface PluginSettingsDetailsProps {
    /**
     * Callback function to be triggered when there's a change in data.
     * @param data - The updated data object.
     */
    onDataChange?: (data: {
        [key: string]: any;
    }) => void;
    /**
     * Data object representing the current state/configuration.
     * readonly - The data object is readonly and cannot be modified.
     */
    readonly data?: {
        [key: string]: any;
    };
}
/**
 * PluginSettingsComponentType is the type of the component associated with the plugin's settings.
 */
export type PluginSettingsComponentType = React.ComponentType<PluginSettingsDetailsProps> | ReactElement | null;
/**
 * PluginInfo is the shape of the metadata information for individual plugin objects.
 */
export type PluginInfo = {
    /**
     * The "name" field contains the plugin's name,
     * and must be lowercase and one word, and may contain hyphens and underscores.
     *
     * @see https://docs.npmjs.com/creating-a-package-json-file#required-name-and-version-fields
     */
    name: string;
    /**
     * folderName is the actual folder name on disk (used for deletion).
     * This may differ from the package.json name, especially for scoped packages.
     */
    folderName?: string;
    /**
     * description text of the plugin from npm with same restrictions as package.json description
     * @see https://docs.npmjs.com/cli/v9/configuring-npm/package-json?v=true#description
     */
    description: string;
    /**
     * displayName is the name of the plugin without the author prefix.
     */
    displayName?: string;
    /**
     * origin is the source of the plugin.
     */
    origin?: string;
    /**
     * homepage is the URL link address for the plugin defined from the package.json
     */
    homepage: string;
    /** repository optional field, repository is an object which some plugins nest their URL link within this object. */
    repository?: any;
    /**
     * isEnable is true when the plugin is enabled
     */
    isEnabled?: boolean;
    /**
     * type indicates the source of the plugin: "development", "user", or "shipped"
     */
    type?: 'development' | 'user' | 'shipped';
    /**
     * isLoaded indicates if this plugin version is actually loaded and executed.
     * When multiple versions of the same plugin exist, only the highest priority enabled version is loaded.
     */
    isLoaded?: boolean;
    /**
     * overriddenBy indicates which higher-priority version is loaded instead of this one.
     * Format: "type" (e.g., "development" or "user")
     */
    overriddenBy?: 'development' | 'user' | 'shipped';
    /**
     * isCompatible is true when the plugin is compatible with this version of Headlamp.
     */
    isCompatible?: boolean;
    version?: string;
    author?: string;
    /**
     * dependencies is an object of the plugin's dependencies from the package.json
     */
    devDependencies?: {
        [key: string]: string;
    };
    /**
     * Component associated with the plugin's settings.
     */
    settingsComponent?: PluginSettingsComponentType;
    /**
     * If the plugin settings should be displayed with a save button.
     *
     */
    displaySettingsComponentWithSaveButton?: boolean;
};
export interface PluginsState {
    /** Have plugins finished executing? */
    loaded: boolean;
    /** Information stored by settings about plugins. */
    pluginSettings: PluginInfo[];
}
export declare const pluginsSlice: import("@reduxjs/toolkit").Slice<PluginsState, {
    pluginsLoaded(state: import("immer").WritableDraft<PluginsState>): void;
    /**
     * Save the plugin settings. To both the store, and localStorage.
     */
    setPluginSettings(state: import("immer").WritableDraft<PluginsState>, action: PayloadAction<PluginInfo[]>): void;
    /** Reloads the browser page */
    reloadPage(): void;
    /**
     * Set the plugin settings component.
     */
    setPluginSettingsComponent(state: import("immer").WritableDraft<PluginsState>, action: PayloadAction<{
        name: string;
        component: PluginSettingsComponentType;
        displaySaveButton: boolean;
    }>): void;
}, "plugins", "plugins", import("@reduxjs/toolkit").SliceSelectors<PluginsState>>;
export declare const pluginsLoaded: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"plugins/pluginsLoaded">, setPluginSettings: import("@reduxjs/toolkit").ActionCreatorWithPayload<PluginInfo[], "plugins/setPluginSettings">, setPluginSettingsComponent: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    name: string;
    component: PluginSettingsComponentType;
    displaySaveButton: boolean;
}, "plugins/setPluginSettingsComponent">, reloadPage: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"plugins/reloadPage">;
declare const _default: import("redux").Reducer<PluginsState>;
export default _default;
