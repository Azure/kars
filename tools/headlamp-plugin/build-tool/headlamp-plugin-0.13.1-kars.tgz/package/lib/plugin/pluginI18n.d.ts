import { i18n, TFunction } from 'i18next';
export interface PluginTranslations {
    [locale: string]: {
        [key: string]: string;
    };
}
export interface PluginI18nInfo {
    name: string;
    translations: PluginTranslations;
}
export interface UseTranslationResult {
    /** Translation function */
    t: TFunction;
    /** i18next instance for the plugin */
    i18n: i18n | null;
    /** Whether translations are ready */
    ready: boolean;
}
export interface PluginPackageInfo {
    name: string;
    headlamp?: {
        i18n?: string[];
    };
    [key: string]: unknown;
}
/**
 * Register translations for a plugin programmatically
 * @deprecated This function is deprecated. Use automatic translation file detection instead.
 * Just place translation files in locales/{language}/translation.json and use useTranslation().
 */
export declare function registerPluginTranslations(pluginName: string, translations: PluginTranslations): void;
/**
 * Hook to use translations in a plugin
 * Automatically detects the plugin name from the build-time injected constants
 * @param pluginNameParam Plugin name (automatically injected by build system)
 */
export declare function useTranslation(pluginNameParam?: string): UseTranslationResult;
/**
 * Get all registered plugin translations info
 */
export declare function getPluginTranslationsInfo(): PluginI18nInfo[];
/**
 * Change language for all plugin instances
 */
export declare function changePluginLanguage(language: string): void;
/**
 * Check if a locale is supported by a plugin
 */
export declare function isLocaleSupported(pluginName: string, locale: string): boolean;
/**
 * Get the list of supported locales for a plugin
 */
export declare function getSupportedLocales(pluginName: string): string[];
/**
 * Initialize plugin i18n - simplified approach using package.json configuration
 * This is called automatically during plugin loading
 */
export declare function initializePluginI18n(pluginName: string, packageInfo: PluginPackageInfo, pluginPath: string): Promise<void>;
