import { PayloadAction } from '@reduxjs/toolkit';
/**
 * The state structure for storing plugin configurations.
 * Each plugin configuration is stored under a unique key.
 */
export interface PluginConfigState {
    [configKey: string]: {
        [key: string]: any;
    };
}
/**
 * Slice for handling plugin configurations.
 * Includes reducers to set and update configurations, which are automatically persisted to local storage.
 */
export declare const pluginConfigSlice: import("@reduxjs/toolkit").Slice<PluginConfigState, {
    /**
     * Sets the configuration for a specific plugin.
     * This will overwrite the entire configuration for the given key.
     * The updated state is persisted to local storage.
     *
     * @param state - The current state of the plugin configurations.
     * @param action - An action containing the config key and the new configuration object.
     */
    setPluginConfig(state: import("immer").WritableDraft<PluginConfigState>, action: PayloadAction<{
        configKey: string;
        payload: {
            [key: string]: any;
        };
    }>): void;
    /**
     * Updates the configuration for a specific plugin.
     * This will merge the provided updates into the current configuration for the given key.
     * The updated state is persisted to local storage.
     *
     * @param state - The current state of the plugin configurations.
     * @param action - An action containing the config key and the partial updates to be merged.
     */
    updatePluginConfig(state: import("immer").WritableDraft<PluginConfigState>, action: PayloadAction<{
        configKey: string;
        payload: {
            [key: string]: any;
        };
    }>): void;
}, "pluginConfig", "pluginConfig", import("@reduxjs/toolkit").SliceSelectors<PluginConfigState>>;
export declare const setPluginConfig: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    configKey: string;
    payload: {
        [key: string]: any;
    };
}, "pluginConfig/setPluginConfig">, updatePluginConfig: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    configKey: string;
    payload: {
        [key: string]: any;
    };
}, "pluginConfig/updatePluginConfig">;
declare const _default: import("redux").Reducer<PluginConfigState>;
export default _default;
