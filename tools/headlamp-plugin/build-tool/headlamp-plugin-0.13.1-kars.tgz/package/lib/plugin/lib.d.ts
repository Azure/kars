/**
 * The lib.ts file should carry the bits to be used by plugins whereas
 * the index.ts should have the functions that Headlamp itself needs for
 * loading the plugins.
 */
/**
 * ## Simple plugin example
 *
 * @example
 *
 * ```tsx
 * import { registerAppBarAction } from '@kinvolk/headlamp-plugin/lib';
 * registerAppBarAction(<span>Hello Kubernetes</span>);
 * ```
 *
 * ## Entry point
 *
 * initializePlugins is the main entry point, and it is called by App.tsx near the beginning.
 *
 * ## Loading JavaScript files/URLs, which register Plugins
 *
 * External JavaScripts are first loaded from the "/plugins/list" URL of URLs into the browser.
 * The backend "server" can currently be configured to load plugins from a folder to make this list.
 *
 * Local in-development plugins are then loaded from the "frontend/src/plugin/plugins/" folder.
 *
 * To see more on what plugins can do, please see the plugin functionality.md documentation.
 *
 * @see {@link https://headlamp.dev/docs/latest/development/plugins/functionality/ Plugin functionality}
 */
import { ClusterRequest } from '../lib/k8s/api/v1/clusterRequests';
import Registry from './registry';
/**
 * Plugins may call Headlamp.registerPlugin(pluginId: string, pluginObj: Plugin) to register themselves.
 *
 * They will have their initialize(register) method called at plugin initialization time.
 *
 */
export declare abstract class Plugin {
    /**
     * initialize is called for each plugin with a Registry which gives the plugin methods for doing things.
     *
     * @returns The return code is not used, but used to be required.
     *
     * @see Registry
     */
    abstract initialize(register: Registry): boolean | void;
}
declare global {
    interface Window {
        pluginLib: {
            [libName: string]: any;
        };
        plugins: {
            [pluginId: string]: Plugin;
        };
        registerPlugin: (pluginId: string, pluginObj: Plugin) => void;
        desktopApi: any;
    }
}
/**
 * The members of AppMenu should be the same as the options for the MenuItem in https://www.electronjs.org/docs/latest/api/menu-item
 * except for the "submenu" (which is the AppMenu type) and "click" (which is not supported here, use the
 * "url" field instead).
 */
export interface AppMenu {
    /** A URL to open (if not starting with http, then it'll be opened in the external browser) */
    url?: string;
    /** The submenus of this menu */
    submenu?: AppMenu[];
    /** Any other members from Electron's MenuItem. */
    [key: string]: any;
}
/**
 * This class is a more convenient way for plugins to call registerPlugin in
 * order to register themselves.
 */
export declare abstract class Headlamp {
    /**
     * Got a new plugin to add? Well, registerPlugin is your friend.
     *
     * @param pluginId - a unique id string for your plugin.
     * @param pluginObj - the plugin being added.
     *
     * @example
     *
     * ```javascript
     * const myPlugin = {
     *   initialize: (register) => {
     *     // do some stuff with register
     *     // use some libraries in window.pluginLib
     *     return true;
     *   }
     * }
     *
     * Headlamp.registerPlugin("aPluginIdString", myPlugin)
     * ```
     */
    static registerPlugin(pluginId: string, pluginObj: Plugin): void;
    /**
     * Configure (or update) a cluster that can then be used throughout Headlamp.
     * If the request is successful, further calls to `K8s.useClustersConf()`
     * will show the newly configured cluster.
     *
     * **Important:** This is only available in the desktop version and will result in a
     * bad request when running in-cluster.
     *
     * @param clusterReq - the cluster to be added or updated.
     * @returns a promise which completes to Headlamp's configuration (showing the list of configured clusters).
     */
    static setCluster(clusterReq: ClusterRequest): Promise<any>;
    /**
     * Changes the app menu.
     * If Headlamp is not running as a desktop app, then this method prints an error and doesn't do anything.
     *
     * @param appMenuFunc A function that receives the current app menu configuration and a new one. If the function returns null, the menu is not changed.
     */
    static setAppMenu(appMenuFunc: (currentAppMenuSpec: AppMenu[] | null) => AppMenu[] | null): void;
    /**
     * Returns whether Headlamp is running as a desktop app.
     *
     * @returns true if Headlamp is running as a desktop app.
     */
    static isRunningAsApp(): boolean;
    /**
     * Returns the version of Headlamp as an object with a VERSION (application version) and
     * GIT_VERSION (commit) fields. Like:
     * { VERSION: 'v0.0.0', GIT_VERSION: '0000000000000}
     *
     * @returns the version of Headlamp.
     */
    getVersion(): {
        VERSION: any;
        GIT_VERSION: any;
    };
    /**
     * Returns the name of the product.
     *
     * @returns the name of the product.
     */
    getProductName(): string;
}
