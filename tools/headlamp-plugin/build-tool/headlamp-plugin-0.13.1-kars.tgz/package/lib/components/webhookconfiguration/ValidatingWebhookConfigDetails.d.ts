export default function ValidatingWebhookConfigurationDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
