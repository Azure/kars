import MutatingWebhookConfiguration from '../../lib/k8s/mutatingWebhookConfiguration';
import ValidatingWebhookConfiguration from '../../lib/k8s/validatingWebhookConfiguration';
export interface WebhookConfigurationDetailsProps {
    resourceClass: typeof ValidatingWebhookConfiguration | typeof MutatingWebhookConfiguration;
    name: string;
    cluster?: string;
}
export default function WebhookConfigurationDetails(props: WebhookConfigurationDetailsProps): import("react/jsx-runtime").JSX.Element;
