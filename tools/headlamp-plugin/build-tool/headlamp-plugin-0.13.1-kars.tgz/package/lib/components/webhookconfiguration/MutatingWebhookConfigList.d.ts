export default function MutatingWebhookConfigurationList(): import("react/jsx-runtime").JSX.Element;
