export default function MutatingWebhookConfigList(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
