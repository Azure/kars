export default function ValidatingWebhookConfigurationList(): import("react/jsx-runtime").JSX.Element;
