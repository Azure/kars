import Ingress, { IngressBackend } from '../../lib/k8s/ingress';
export interface LinkStringFormatProps {
    url: string;
    item: Ingress;
    urlPath?: string;
}
/**
 * Format the url to be used in the Link component
 */
export declare function LinkStringFormat({ url, item, urlPath }: LinkStringFormatProps): import("react/jsx-runtime").JSX.Element;
export interface BackendFormatProps {
    backend: IngressBackend[];
}
/**
 * Used to format the backend to be used in the backends field
 */
export declare function BackendFormat({ backend }: BackendFormatProps): import("react/jsx-runtime").JSX.Element;
export default function IngressDetails(props: {
    name?: string;
    namespace?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
