export default function IngressClassList(): import("react/jsx-runtime").JSX.Element;
