export default function IngressList(): import("react/jsx-runtime").JSX.Element;
