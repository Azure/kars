export default function VpaList(): import("react/jsx-runtime").JSX.Element;
