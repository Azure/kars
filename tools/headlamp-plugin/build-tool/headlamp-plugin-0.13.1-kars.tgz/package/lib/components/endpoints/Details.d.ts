export default function EndpointDetails(props: {
    name?: string;
    namespace?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
