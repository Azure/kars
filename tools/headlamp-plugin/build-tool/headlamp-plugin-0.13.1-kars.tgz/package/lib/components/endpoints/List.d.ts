export default function EndpointList(): import("react/jsx-runtime").JSX.Element;
