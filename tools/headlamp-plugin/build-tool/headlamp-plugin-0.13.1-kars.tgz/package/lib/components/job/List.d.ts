import { ApiError } from '../../lib/k8s/api/v2/ApiError';
import Job from '../../lib/k8s/job';
import { SimpleTableProps } from '../common/SimpleTable';
export declare function makeJobStatusValue(job: Job): any;
export declare function makeJobStatusLabel(job: Job): import("react/jsx-runtime").JSX.Element | null;
export default function JobsList(): import("react/jsx-runtime").JSX.Element;
export interface JobsListRendererProps {
    jobs: Job[] | null;
    errors?: ApiError[] | null;
    hideColumns?: 'namespace'[];
    reflectTableInURL?: SimpleTableProps['reflectInURL'];
    noNamespaceFilter?: boolean;
}
export declare function JobsListRenderer(props: JobsListRendererProps): import("react/jsx-runtime").JSX.Element;
