export default function ServiceAccountList(): import("react/jsx-runtime").JSX.Element;
