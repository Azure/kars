import { ApiError } from '../../lib/k8s/api/v2/ApiError';
export interface ClusterGroupErrorMessageProps {
    /**
     * Array of errors
     */
    errors?: ApiError[] | null;
}
export declare function ClusterGroupErrorMessage({ errors }: ClusterGroupErrorMessageProps): import("react/jsx-runtime").JSX.Element[] | null;
