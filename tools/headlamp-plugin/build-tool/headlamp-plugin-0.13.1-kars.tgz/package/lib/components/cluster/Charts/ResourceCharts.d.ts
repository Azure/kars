import '../../../i18n/config';
import { CircularChartProps as ResourceCircularChartProps } from '../../common/Resource/CircularChart';
export declare function MemoryCircularChart(props: ResourceCircularChartProps): import("react/jsx-runtime").JSX.Element;
export declare function CpuCircularChart(props: ResourceCircularChartProps): import("react/jsx-runtime").JSX.Element;
