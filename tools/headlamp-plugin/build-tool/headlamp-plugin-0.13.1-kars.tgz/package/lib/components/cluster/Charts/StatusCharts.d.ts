import '../../../i18n/config';
import Node from '../../../lib/k8s/node';
import Pod from '../../../lib/k8s/pod';
export declare function PodsStatusCircleChart(props: {
    items: Pod[] | null;
}): import("react/jsx-runtime").JSX.Element;
export declare function NodesStatusCircleChart(props: {
    items: Node[] | null;
}): import("react/jsx-runtime").JSX.Element;
