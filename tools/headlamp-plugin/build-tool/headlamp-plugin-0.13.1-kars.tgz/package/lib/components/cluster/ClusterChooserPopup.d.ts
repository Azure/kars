export interface ChooserPopupPros {
    /** The element to which the popup will be anchored. */
    anchor: HTMLElement | null;
    /** Callback to be called when the popup is closed. */
    onClose?: (() => void) | null;
}
/** A popup that allows the user to choose a cluster.
 * @param anchor The element to which the popup will be anchored.
 * @param onClose Callback to be called when the popup is closed.
 */
declare function ClusterChooserPopup(props: ChooserPopupPros): import("react/jsx-runtime").JSX.Element | null;
export default ClusterChooserPopup;
