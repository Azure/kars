declare function KubeConfigLoader(): import("react/jsx-runtime").JSX.Element;
export default KubeConfigLoader;
