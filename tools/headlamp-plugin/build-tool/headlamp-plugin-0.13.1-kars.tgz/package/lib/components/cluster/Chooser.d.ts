import { DialogProps } from '@mui/material/Dialog';
import React, { PropsWithChildren } from 'react';
import { Cluster } from '../../lib/k8s/cluster';
export interface ClusterTitleProps {
    clusters?: {
        [clusterName: string]: Cluster;
    };
    cluster?: string;
    onClick?: (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}
export declare function ClusterTitle(props: ClusterTitleProps): import("react/jsx-runtime").JSX.Element | null;
interface ClusterDialogProps extends PropsWithChildren<Omit<DialogProps, 'open' | 'onClose'>> {
    open?: boolean;
    onClose?: (() => void) | null;
    useCover?: boolean;
    showInfoButton?: boolean;
}
export declare function ClusterDialog(props: ClusterDialogProps): import("react/jsx-runtime").JSX.Element;
declare function Chooser(props: ClusterDialogProps): import("react/jsx-runtime").JSX.Element | null;
export default Chooser;
