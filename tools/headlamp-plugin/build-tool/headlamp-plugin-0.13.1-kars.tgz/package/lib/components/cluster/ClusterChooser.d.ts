import React, { ReactElement } from 'react';
export interface ClusterChooserProps {
    clickHandler: (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    cluster?: string;
    icon?: string;
    accentColor?: string;
}
export type ClusterChooserType = React.ComponentType<ClusterChooserProps> | ReactElement<ClusterChooserProps> | null;
declare const ClusterChooser: React.ForwardRefExoticComponent<ClusterChooserProps & React.RefAttributes<HTMLButtonElement>>;
export default ClusterChooser;
