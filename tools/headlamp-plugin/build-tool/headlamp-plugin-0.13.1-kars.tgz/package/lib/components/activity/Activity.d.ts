import React, { ReactNode } from 'react';
/** Activity position relative to the main container */
type ActivityLocation = 'full' | 'split-left' | 'split-right' | 'split-top' | 'split-bottom' | 'window';
/** Independent screen or a page rendered on top of the app */
export interface Activity {
    /** Unique ID */
    id: string;
    /** Content to display inside the activity */
    content: ReactNode;
    /** Current activity location */
    location: ActivityLocation;
    /** Title to render in the taskbar and in window */
    title?: ReactNode;
    /** Hides title from the window header */
    hideTitleInHeader?: boolean;
    /** Activity icon, optional but highly recommended */
    icon?: ReactNode;
    /** Whether this activity is minimized to the taskbar */
    minimized?: boolean;
    /**
     * Temporary activity will be closed if another activity is opened
     * It will turn into permanent one if user interacts with it
     */
    temporary?: boolean;
    /** Cluster of the launched activity */
    cluster?: string;
}
export declare const Activity: {
    /** Launches new Activity */
    launch(activity: Activity): void;
    /** Closes activity */
    close(id: string): void;
    /** Update existing activity with a partial changes */
    update(id: string, diff: Partial<Activity>): void;
    reset(): void;
};
/** Control activity from within, requires to be used within an existing Activity */
export declare const useActivity: () => readonly [Activity, (changes: Partial<Activity>) => void];
/** Renders a single activity */
export declare function SingleActivityRenderer({ activity, zIndex, index, isOverview, onClick, }: {
    activity: Activity;
    zIndex: number;
    /** Index of this activity within a list of all activities */
    index: number;
    /** Render in a small window for the overview state */
    isOverview: boolean;
    /** Click event callback */
    onClick: React.PointerEventHandler<HTMLDivElement>;
}): import("react/jsx-runtime").JSX.Element;
/** Renders all activities and the taskbar */
export declare const ActivitiesRenderer: React.NamedExoticComponent<object>;
/** Taskbar with all current activities */
export declare const ActivityBar: React.NamedExoticComponent<{
    setIsOverview: React.Dispatch<React.SetStateAction<boolean>>;
}>;
export {};
