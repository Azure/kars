import { PayloadAction } from '@reduxjs/toolkit';
import type { Activity } from './Activity';
export interface ActivityState {
    /** History of opened activities, list of IDs */
    history: string[];
    /** Map of all open activities, key is the ID */
    activities: Record<string, Activity>;
}
export declare const activitySlice: import("@reduxjs/toolkit").Slice<ActivityState, {
    launchActivity(state: import("immer").WritableDraft<ActivityState>, action: PayloadAction<Activity>): void;
    close(state: import("immer").WritableDraft<ActivityState>, action: PayloadAction<string>): void;
    update(state: import("immer").WritableDraft<ActivityState>, action: PayloadAction<Partial<Activity> & {
        id: string;
    }>): void;
    reset(): ActivityState;
}, "activity", "activity", import("@reduxjs/toolkit").SliceSelectors<ActivityState>>;
export declare const activityReducer: import("redux").Reducer<ActivityState>;
