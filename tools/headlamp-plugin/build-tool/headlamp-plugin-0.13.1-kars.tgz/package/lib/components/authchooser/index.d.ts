import React from 'react';
export interface AuthChooserProps {
    children?: React.ReactNode;
}
declare function AuthChooser({ children }: AuthChooserProps): import("react/jsx-runtime").JSX.Element;
export interface PureAuthChooserProps {
    title: string;
    testingTitle: string;
    testingAuth: boolean;
    error: Error | null;
    oauthUrl: string;
    clusterAuthType: string;
    handleOidcAuth: () => void;
    handleTokenAuth: () => void;
    handleTryAgain: () => void;
    handleBackButtonPress: () => void;
    children?: React.ReactNode;
    clusterName: string;
}
export declare function PureAuthChooser({ title, testingTitle, testingAuth, error, oauthUrl, clusterAuthType, handleOidcAuth, handleTokenAuth, handleTryAgain, handleBackButtonPress, children, clusterName, }: PureAuthChooserProps): import("react/jsx-runtime").JSX.Element;
export default AuthChooser;
