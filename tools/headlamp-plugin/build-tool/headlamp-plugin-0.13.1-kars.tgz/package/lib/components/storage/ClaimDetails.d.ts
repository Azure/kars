import PersistentVolumeClaim from '../../lib/k8s/persistentVolumeClaim';
export declare function makePVCStatusLabel(item: PersistentVolumeClaim): import("react/jsx-runtime").JSX.Element;
export default function VolumeClaimDetails(props: {
    name?: string;
    namespace?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
