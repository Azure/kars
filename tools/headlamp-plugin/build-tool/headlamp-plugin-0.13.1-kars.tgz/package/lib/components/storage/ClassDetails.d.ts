export default function StorageClassDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
