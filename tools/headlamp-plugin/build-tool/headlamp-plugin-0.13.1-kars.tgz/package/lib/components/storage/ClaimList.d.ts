export default function VolumeClaimList(): import("react/jsx-runtime").JSX.Element;
