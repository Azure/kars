export declare function StatusLabelByPhase(phase: string): import("react/jsx-runtime").JSX.Element;
