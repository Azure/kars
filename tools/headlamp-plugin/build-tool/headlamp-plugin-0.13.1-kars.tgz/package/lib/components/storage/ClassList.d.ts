export default function ClassList(): import("react/jsx-runtime").JSX.Element;
