export default function VolumeList(): import("react/jsx-runtime").JSX.Element;
