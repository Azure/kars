import PersistentVolume from '../../lib/k8s/persistentVolume';
export declare function makePVStatusLabel(item: PersistentVolume): import("react/jsx-runtime").JSX.Element;
export default function VolumeDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
