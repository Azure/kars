export declare function NetworkPolicyList(): import("react/jsx-runtime").JSX.Element;
