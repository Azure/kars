import { KubeObject } from '../../../../lib/k8s/KubeObject';
import { Relation } from '../../graph/graphModel';
/**
 * Check if the given item has matching labels
 */
export declare const matchesLabels: (matchLabels: Record<string, string>, item: KubeObject) => boolean | undefined;
export declare function useGetAllRelations(): Relation[];
