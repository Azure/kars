declare const kindToIcon: {
    readonly ClusterRole: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly ClusterRoleBinding: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly CronJob: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly DaemonSet: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Group: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Ingress: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly LimitRange: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Namespace: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly PodSecurityPolicy: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly PersistentVolumeClaim: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly RoleBinding: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly ReplicaSet: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly StorageClass: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly StatefulSet: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly User: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly ConfigMap: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly CustomResourceDefinition: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Deployment: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Endpoint: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Endpoints: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly EndpointSlice: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly HorizontalPodAutoscaler: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Job: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly NetworkPolicy: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Pod: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly PersistentVolume: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly ResourceQuota: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Role: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly ServiceAccount: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Secret: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Service: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
    readonly Volume: import("react").FunctionComponent<import("react").SVGProps<SVGSVGElement> & {
        title?: string;
        titleId?: string;
        desc?: string;
        descId?: string;
    }>;
};
declare const kindGroupColors: {
    readonly workloads: "oklch(67.85% 0.12 182.18)";
    readonly storage: "oklch(67.85% 0.12 46.47)";
    readonly network: "oklch(67.85% 0.12 225.16)";
    readonly security: "oklch(67.85% 0.12 275.16)";
    readonly configuration: "oklch(67.85% 0.12 320.03)";
    readonly other: "oklch(67.85% 0 215.25)";
};
export declare const getKindGroupColor: (group: keyof typeof kindGroupColors) => "oklch(67.85% 0.12 182.18)" | "oklch(67.85% 0.12 46.47)" | "oklch(67.85% 0.12 225.16)" | "oklch(67.85% 0.12 275.16)" | "oklch(67.85% 0.12 320.03)" | "oklch(67.85% 0 215.25)";
/**
 * Icon for the Kube resource
 * Color is based on the resource category (workload,storage, etc)
 *
 * Icons are taken from
 * https://github.com/kubernetes/community/tree/master/icons
 *
 * @param params.kind - Resource kind
 * @param params.width - width in css units
 * @param params.height - width in css units
 * @returns
 */
export declare function KubeIcon({ kind, width, height, }: {
    kind: keyof typeof kindToIcon;
    width?: string;
    height?: string;
}): import("react/jsx-runtime").JSX.Element;
export {};
