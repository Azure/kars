import Service from '../../../lib/k8s/service';
export declare function ServiceGlance({ service }: {
    service: Service;
}): import("react/jsx-runtime").JSX.Element;
