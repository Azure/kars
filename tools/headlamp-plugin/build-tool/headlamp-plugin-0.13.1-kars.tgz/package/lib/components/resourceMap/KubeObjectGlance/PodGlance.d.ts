import Pod from '../../../lib/k8s/pod';
export declare function PodGlance({ pod }: {
    pod: Pod;
}): import("react/jsx-runtime").JSX.Element;
