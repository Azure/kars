export declare const GroupNodeComponent: import("react").MemoExoticComponent<({ id }: {
    id: string;
}) => import("react/jsx-runtime").JSX.Element>;
