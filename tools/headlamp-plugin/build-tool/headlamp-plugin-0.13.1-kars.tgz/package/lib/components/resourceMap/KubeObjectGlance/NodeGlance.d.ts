import { GraphNode } from '../graph/graphModel';
/**
 * Generic glance component for rendering node previews in Headlamp's graph view.
 * Renders KubeObjectGlance for Kubernetes objects or a plugin-provided glance for other nodes.
 */
export declare const NodeGlance: ({ node }: {
    node: GraphNode;
}) => import("react/jsx-runtime").JSX.Element | null;
