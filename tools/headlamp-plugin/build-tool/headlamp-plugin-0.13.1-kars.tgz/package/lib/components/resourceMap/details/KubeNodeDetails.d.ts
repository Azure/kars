export declare const canRenderDetails: (maybeKind: string) => boolean;
/**
 * Shows details page for a given Kube resource
 */
export declare const KubeObjectDetails: import("react").MemoExoticComponent<({ resource, customResourceDefinition, }: {
    resource: {
        kind: string;
        cluster?: string;
        metadata: {
            name: string;
            namespace?: string;
        };
    };
    customResourceDefinition?: string;
}) => import("react/jsx-runtime").JSX.Element>;
