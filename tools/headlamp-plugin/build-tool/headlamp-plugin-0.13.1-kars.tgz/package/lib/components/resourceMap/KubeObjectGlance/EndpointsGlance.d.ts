import Endpoints from '../../../lib/k8s/endpoints';
export declare function EndpointsGlance({ endpoints }: {
    endpoints: Endpoints;
}): import("react/jsx-runtime").JSX.Element;
