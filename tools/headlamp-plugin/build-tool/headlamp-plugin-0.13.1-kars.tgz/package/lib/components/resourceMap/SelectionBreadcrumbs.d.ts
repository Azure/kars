import { GraphNode } from './graph/graphModel';
export interface SelectionBreadcrumbsProps {
    /** The graph in which to search the selected node */
    graph: GraphNode;
    /** The ID of the selected node */
    selectedNodeId?: string;
    /** Callback when a node is clicked */
    onNodeClick: (id: string) => void;
}
export declare function SelectionBreadcrumbs({ graph, selectedNodeId, onNodeClick, }: SelectionBreadcrumbsProps): import("react/jsx-runtime").JSX.Element;
