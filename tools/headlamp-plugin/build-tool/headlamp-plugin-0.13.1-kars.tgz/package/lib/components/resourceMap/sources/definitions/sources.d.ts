import { GraphSource } from '../../graph/graphModel';
export declare function useGetAllSources(): GraphSource[];
