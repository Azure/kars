import { ReactNode } from 'react';
export declare function GraphControlButton({ children, onClick, title, disabled, }: {
    children?: ReactNode;
    title: string;
    onClick: () => void;
    disabled?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function GraphControls({ children }: {
    children?: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
