import { ComponentType, ReactNode } from 'react';
import { KubeObject } from '../../../lib/k8s/KubeObject';
export type GraphNode = {
    /**
     * Unique ID for this node.
     * If this node represents a kubernetes object
     * then uid of that object is preferred.
     **/
    id: string;
    /** Display label for this node */
    label?: string;
    /** Subtitle for this node */
    subtitle?: string;
    /** Custom icon for this node */
    icon?: ReactNode;
    /**
     * If this property is set  then it means this graph Node
     * represents a kubernetes object.
     * Label and subtitle will be set based on the object's name and kind.
     */
    kubeObject?: KubeObject;
    /** A node may contain children Nodes. */
    nodes?: GraphNode[];
    /** A node may containain Edges that connect children Nodes. */
    edges?: GraphEdge[];
    /** Whether this Node is collapsed. Only applies to Nodes that have child Nodes. */
    collapsed?: boolean;
    /** Custom component to render details for this node */
    detailsComponent?: ComponentType<{
        node: GraphNode;
    }>;
    /**
     * Weight determines the priority/importance of this node (higher = more important).
     * Used for sorting and determining the "main" node in groups.
     * If not specified, defaults will be used based on node type.
     */
    weight?: number;
    /** Any custom data */
    data?: any;
    /** CustomResourceDefinition for this node */
    customResourceDefinition?: string;
};
/**
 * Iterates graph, breadth first
 */
export declare function forEachNode(graph: GraphNode, cb: (item: GraphNode) => void): void;
/**
 * Edge connecting two Nodes on Map
 */
export interface GraphEdge {
    /** Unique ID */
    id: string;
    /** ID of the source Node */
    source: string;
    /** ID of the target Node */
    target: string;
    /** Optional label */
    label?: ReactNode;
    /** Custom data for this node */
    data?: any;
}
/**
 * Graph Source defines a group of Nodes and Edges
 * that can be loaded on the Map
 *
 * Graph Source may contain other GraphSources
 */
export type GraphSource = {
    /**
     * ID of the source, should be uniquie
     */
    id: string;
    /**
     * Descriptive label of the source
     */
    label: string;
    /**
     * Optional icon to display
     */
    icon?: ReactNode;
    /**
     * Controls wherther the source is shown by default
     * @default true
     */
    isEnabledByDefault?: boolean;
} & ({
    /**
     * Child sources
     */
    sources: GraphSource[];
} | {
    /**
     * Hooks that loads nodes and edges for this source
     */
    useData: () => {
        nodes?: GraphNode[];
        edges?: GraphEdge[];
    } | null;
});
export interface Relation {
    fromSource: string;
    toSource?: string;
    predicate: (from: GraphNode, to: GraphNode) => boolean;
}
/**
 * Gets the effective weight of a node, considering both explicit weight
 * and default weights based on Kubernetes resource type.
 *
 * @param node - The GraphNode to get weight for
 * @returns The effective weight (higher = more important)
 */
export declare function getNodeWeight(node: GraphNode): number;
