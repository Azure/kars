import '@xyflow/react/dist/base.css';
import './GraphView.css';
import { GraphFilter } from './graph/graphFiltering';
import { GraphLookup } from './graph/graphLookup';
import { GraphEdge, GraphNode, GraphSource, Relation } from './graph/graphModel';
interface GraphViewContent {
    setNodeSelection: (nodeId: string) => void;
    nodeSelection?: string;
}
export declare const GraphViewContext: import("react").Context<any>;
export declare const useGraphView: () => GraphViewContent;
interface FullGraphContent {
    fullGraph: any;
    lookup: GraphLookup<GraphNode, GraphEdge>;
}
export declare const FullGraphContext: import("react").Context<any>;
export declare const useFullGraphContext: () => FullGraphContent;
export declare const useNode: (id: string) => GraphNode | undefined;
interface GraphViewContentProps {
    /** Height of the Map */
    height?: string;
    /** ID of a node to select by default */
    defaultNodeSelection?: string;
    /**
     * List of Graph Source to display
     *
     * See {@link GraphSource} for more information
     */
    defaultSources?: GraphSource[];
    /**
     * List of Graph Relations to display
     *
     * See {@link GraphSource} for more information
     */
    defaultRelations?: Relation[];
    /** Default filters to apply */
    defaultFilters?: GraphFilter[];
}
declare function GraphViewContent({ height, defaultNodeSelection, defaultSources, defaultFilters, }: GraphViewContentProps): import("react/jsx-runtime").JSX.Element;
/**
 * Renders Map of Kubernetes resources
 *
 * @param params - Map parameters
 * @returns
 */
export declare function GraphView(props: GraphViewContentProps): import("react/jsx-runtime").JSX.Element;
export {};
