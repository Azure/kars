import { Edge, Node } from '@xyflow/react';
import { GraphNode } from './graphModel';
/**
 * Takes a graph and returns a graph with layout applied
 * Layout will set size and poisiton for all the elements
 *
 * @param graph - root node of the graph
 * @param aspectRatio - aspect ratio of the container
 * @returns
 */
export declare const applyGraphLayout: (graph: GraphNode, aspectRatio: number) => Promise<{
    nodes: Node[];
    edges: Edge[];
}>;
