import { GraphEdge, GraphNode } from './graphModel';
/**
 * Constant time lookup of graph elements
 */
export interface GraphLookup<N, E> {
    /** Get list of outgoing edges from the given node */
    getOutgoingEdges(nodeId: string): E[] | undefined;
    /** Get list of incoming edges to the given node */
    getIncomingEdges(nodeId: string): E[] | undefined;
    /** Get Node by its' ID */
    getNode(nodeId: string): N | undefined;
}
/**
 * Creates a utility for constant time lookup of graph elements
 *
 * @param nodes - list of graph Nodes
 * @param edges - list of graph Edges
 * @returns lookup {@link GraphLookup}
 */
export declare function makeGraphLookup<N extends GraphNode, E extends GraphEdge>(nodes: N[], edges: E[]): GraphLookup<N, E>;
