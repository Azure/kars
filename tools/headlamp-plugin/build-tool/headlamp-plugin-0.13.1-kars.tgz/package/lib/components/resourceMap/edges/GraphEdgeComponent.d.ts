import { EdgeProps } from '@xyflow/react';
import { GraphEdge } from '../graph/graphModel';
/**
 * An edge between Kube Objects
 */
export declare const GraphEdgeComponent: import("react").MemoExoticComponent<(props: EdgeProps & {
    data: GraphEdge["data"];
}) => import("react/jsx-runtime").JSX.Element>;
