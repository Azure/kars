import { GraphEdge, GraphNode } from './graphModel';
export type GraphFilter = {
    type: 'hasErrors';
} | {
    type: 'namespace';
    namespaces: Set<string>;
};
/**
 * Filters the graph nodes and edges based on the provided filters
 * The filters are applied using an OR logic, meaning node will be included if it matches any of the filters
 *
 * Along with the matched node result also includes all the nodes that are related to it,
 * even if they don't match the filter
 *
 * The filters can be of the following types:
 * - `hasErrors`: Filters nodes that have errors based on their resource status. See {@link getStatus}
 * - `namespace`: Filters nodes by their namespace
 *
 * @param nodes - List of all the nodes in the graph
 * @param edges - List of all the edges in the graph
 * @param filters - List of fitlers to apply
 */
export declare function filterGraph(nodes: GraphNode[], edges: GraphEdge[], filters: GraphFilter[]): {
    nodes: GraphNode[];
    edges: GraphEdge[];
};
