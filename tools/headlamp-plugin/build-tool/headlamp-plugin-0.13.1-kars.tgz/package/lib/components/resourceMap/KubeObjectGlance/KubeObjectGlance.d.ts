import { KubeObject } from '../../../lib/k8s/cluster';
/**
 * Little Popup preview of a Kube object
 */
export declare const KubeObjectGlance: import("react").MemoExoticComponent<({ resource }: {
    resource: KubeObject;
}) => import("react/jsx-runtime").JSX.Element[]>;
