import { ReactNode } from 'react';
import { KubeObject } from '../../../lib/k8s/cluster';
import { GraphEdge, GraphNode, GraphSource, Relation } from '../graph/graphModel';
/**
 * Map of nodes and edges where the key is source id
 */
export type SourceData = Map<string, MaybeNodesAndEdges>;
type MaybeNodesAndEdges = {
    nodes?: GraphNode[];
    edges?: GraphEdge[];
} | null;
interface GraphSourcesContext {
    nodes: GraphNode[];
    edges: GraphEdge[];
    toggleSelection: (source: GraphSource) => void;
    setSelectedSources: (sources: Set<string>) => void;
    selectedSources: Set<string>;
    sourceData?: SourceData;
    isLoading?: boolean;
}
export declare const useSources: () => GraphSourcesContext;
/**
 * Returns a flat list of all the sources
 */
export declare function getFlatSources(sources: GraphSource[], result?: GraphSource[]): GraphSource[];
/**
 * Create Edges from object's ownerReferences
 */
export declare const kubeOwnersEdges: (obj: KubeObject) => GraphEdge[];
/**
 * Create reverse Edges from object's ownerReferences
 */
export declare const kubeOwnersEdgesReversed: (obj: KubeObject) => GraphEdge[];
/**
 * Create an object from any Kube object
 */
export declare const makeKubeObjectNode: (obj: KubeObject) => GraphNode;
/**
 * Make an edge connecting two Kube objects
 */
export declare const makeKubeToKubeEdge: (from: KubeObject, to: KubeObject) => GraphEdge;
export default function useThrottledMemo<T>(factory: () => T, deps: any[], throttleMs: number): T;
export interface GraphSourceManagerProps {
    /** List of sources to load */
    sources: GraphSource[];
    /** Children to render */
    children: ReactNode;
    /** Relations between nodes */
    relations: Relation[];
}
/**
 * Loads data from all the sources
 */
export declare function GraphSourceManager({ sources, children, relations }: GraphSourceManagerProps): import("react/jsx-runtime").JSX.Element;
export {};
