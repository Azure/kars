import { KubeObject } from '../../../lib/k8s/cluster';
export type KubeObjectStatus = 'error' | 'success' | 'warning';
/**
 * Returns status for a given Kube resource
 * Not all kinds of resources have a status and/or supported
 */
export declare function getStatus(w: KubeObject): KubeObjectStatus;
