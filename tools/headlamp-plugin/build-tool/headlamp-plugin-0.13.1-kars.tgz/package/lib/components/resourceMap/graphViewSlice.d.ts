/**
 * This slice contains custom graph elements and glances registered by plugins
 */
import { PayloadAction } from '@reduxjs/toolkit';
import { ReactNode } from 'react';
import { GraphNode, GraphSource } from './graph/graphModel';
export interface IconDefinition {
    /**
     * Icon element
     */
    icon: ReactNode;
    /**
     * Color of the icon
     * @example #FF0000
     * @example rgba(255, 100, 20, 0.5)
     */
    color?: string;
}
/**
 * Represents a glance, a custom UI component for rendering specific graph nodes.
 */
export interface Glance {
    /**
     * A unique identifier for the glance.
     */
    id: string;
    /**
     * A function that returns a React component to render for a given graph node.
     * @param props - Object containing the graph node to be rendered.
     * @param props.node - The graph node to be visualized by the glance.
     * @returns A ReactNode representing the rendered component.
     */
    component: (props: {
        node: GraphNode;
    }) => ReactNode;
}
export interface GraphViewSliceState {
    graphSources: GraphSource[];
    kindIcons: Record<string, IconDefinition>;
    glances: Record<string, Glance>;
}
export declare const graphViewSlice: import("@reduxjs/toolkit").Slice<GraphViewSliceState, {
    addGraphSource(state: import("immer").WritableDraft<GraphViewSliceState>, action: PayloadAction<GraphSource>): void;
    addKindIcon(state: import("immer").WritableDraft<GraphViewSliceState>, action: PayloadAction<{
        kind: string;
        definition: IconDefinition;
    }>): void;
    setGlance(state: import("immer").WritableDraft<GraphViewSliceState>, action: PayloadAction<Glance>): void;
}, "graphViewSlice", "graphViewSlice", import("@reduxjs/toolkit").SliceSelectors<GraphViewSliceState>>;
export declare const addGraphSource: import("@reduxjs/toolkit").ActionCreatorWithPayload<GraphSource, "graphViewSlice/addGraphSource">, addKindIcon: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    kind: string;
    definition: IconDefinition;
}, "graphViewSlice/addKindIcon">, setGlance: import("@reduxjs/toolkit").ActionCreatorWithPayload<Glance, "graphViewSlice/setGlance">;
declare const _default: import("redux").Reducer<GraphViewSliceState>;
export default _default;
