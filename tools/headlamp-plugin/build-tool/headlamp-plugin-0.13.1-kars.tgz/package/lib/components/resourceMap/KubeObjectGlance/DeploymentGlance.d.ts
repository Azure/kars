import Deployment from '../../../lib/k8s/deployment';
export declare function DeploymentGlance({ deployment }: {
    deployment: Deployment;
}): import("react/jsx-runtime").JSX.Element;
