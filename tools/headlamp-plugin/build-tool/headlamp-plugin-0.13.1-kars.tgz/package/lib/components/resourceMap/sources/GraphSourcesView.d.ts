import { GraphSource } from '../graph/graphModel';
import { SourceData } from './GraphSources';
export interface GraphSourcesViewProps {
    /** List of sources to render */
    sources: GraphSource[];
    /** Data for each source */
    sourceData: SourceData;
    /** Selected sources */
    selectedSources: Set<string>;
    /** Callback when a source is toggled */
    toggleSource: (source: GraphSource) => void;
}
export declare const GraphSourcesView: import("react").MemoExoticComponent<({ sources, sourceData, selectedSources, toggleSource }: GraphSourcesViewProps) => import("react/jsx-runtime").JSX.Element>;
