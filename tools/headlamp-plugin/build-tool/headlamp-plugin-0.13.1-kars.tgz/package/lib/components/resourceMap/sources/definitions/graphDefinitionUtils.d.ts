import type { KubeObjectClass } from '../../../../lib/k8s/KubeObject';
/** Create a unique API resource ID consisting of the API group name and kind */
export declare function makeKubeSourceId(kubeObjectClass: KubeObjectClass): string;
