import type ReplicaSet from '../../../lib/k8s/replicaSet';
import type StatefulSet from '../../../lib/k8s/statefulSet';
export declare function ReplicaSetGlance({ set }: {
    set: ReplicaSet | StatefulSet;
}): import("react/jsx-runtime").JSX.Element;
