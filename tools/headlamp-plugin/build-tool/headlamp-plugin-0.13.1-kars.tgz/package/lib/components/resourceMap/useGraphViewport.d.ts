import { Node } from '@xyflow/react';
/**
 * Zoom Mode represents different approaches to viewport calculation
 *
 * - 100% (default)
 *   Will try to fit nodes without exceeding 100% zoom
 *   Often results in content overflowing but keeps text readable
 *
 * - Fit
 *   Will show everything and zoom out as needed
 */
type zoomMode = '100%' | 'fit';
/** Helper hook to deal with viewport zooming */
export declare const useGraphViewport: () => {
    updateViewport: ({ nodes, mode, }: {
        /** List of nodes, if not provided will use current nodes in the graph */
        nodes?: Node[];
        /** Zoom mode. More info in the type definition {@link zoomMode} */
        mode?: zoomMode;
    }) => void;
    aspectRatio: number;
};
export {};
