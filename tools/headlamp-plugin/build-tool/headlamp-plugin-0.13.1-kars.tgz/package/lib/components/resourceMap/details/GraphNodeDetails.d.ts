import { GraphNode } from '../graph/graphModel';
export interface GraphNodeDetailsProps {
    /** Node to display */
    node?: GraphNode;
}
/**
 * Side panel display information about a selected Node
 */
export declare function GraphNodeDetails({ node }: GraphNodeDetailsProps): import("react/jsx-runtime").JSX.Element | null;
