type UseQueryParamsStateReturnType<T> = [
    T | undefined,
    (newValue: T | undefined, params?: {
        replace?: boolean;
    }) => void
];
/**
 * Custom hook to manage a state synchronized with a URL query parameter
 *
 * @param param - The name of the query parameter to synchronize with
 * @param initialState - The initial state value
 * @returns A tuple containing the current state value and a function to update the state value
 *
 * @example
 * const [searchTerm, setSearchTerm] = useQueryParamsState('search', 'initial-value')
 *
 */
export declare function useQueryParamsState<T extends string | undefined>(param: string, initialState: T): UseQueryParamsStateReturnType<T>;
export {};
