import { NodeProps } from '@xyflow/react';
export declare const KubeObjectNodeComponent: import("react").MemoExoticComponent<({ id }: NodeProps) => import("react/jsx-runtime").JSX.Element | null>;
