import { Edge, EdgeMouseHandler, Node, NodeMouseHandler, OnMoveStart } from '@xyflow/react';
import React from 'react';
export declare const nodeTypes: {
    object: React.MemoExoticComponent<({ id }: import("@xyflow/react").NodeProps) => import("react/jsx-runtime").JSX.Element | null>;
};
export interface GraphRendererProps {
    /** List of nodes to render */
    nodes: Node[];
    /** List of edges to render */
    edges: Edge[];
    /** Callback when a node is clicked */
    onNodeClick?: NodeMouseHandler<Node>;
    /** Callback when an edge is clicked */
    onEdgeClick?: EdgeMouseHandler<Edge>;
    /** Callback when the graph is started to be moved */
    onMoveStart?: OnMoveStart;
    /** Callback when the background is clicked */
    onBackgroundClick?: () => void;
    /** Additional components to render */
    children?: React.ReactNode;
    /** Additional actions for the controls panael */
    controlActions?: React.ReactNode;
    isLoading?: boolean;
}
export declare function GraphRenderer({ nodes, edges, onNodeClick, onEdgeClick, onMoveStart, onBackgroundClick, children, controlActions, isLoading, }: GraphRendererProps): import("react/jsx-runtime").JSX.Element;
