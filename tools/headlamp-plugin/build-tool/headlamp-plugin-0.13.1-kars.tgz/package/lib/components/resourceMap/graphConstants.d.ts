export declare const minZoom = 0.1;
export declare const maxZoom = 2;
export declare const viewportPaddingPx = 50;
