import Namespace from '../../../lib/k8s/namespace';
import Node from '../../../lib/k8s/node';
import { GraphEdge, GraphNode } from './graphModel';
export type GroupBy = 'node' | 'namespace' | 'instance';
/**
 * Returns the amount of nodes in the graph
 */
export declare const getGraphSize: (graph: GraphNode) => number;
/**
 * Try to find a "main" node in the group based on weight.
 * Higher weight nodes are considered more important.
 *
 * @param nodes - Array of nodes to find the main node from
 * @returns The node with the highest weight (most important), or undefined if array is empty
 */
export declare const getMainNode: (nodes: GraphNode[]) => GraphNode | undefined;
/**
 * Groups the graph into separate 'group' Nodes
 * Nodes within groups are sorted by weight and size
 *
 * @param nodes - List of nodes
 * @param edges - List of edge
 * @param params.groupBy - group by which property
 * @returns Graph, a single root node with groups as its' children
 */
export declare function groupGraph(nodes: GraphNode[], edges: GraphEdge[], { groupBy, namespaces, k8sNodes, }: {
    groupBy?: GroupBy;
    namespaces: Namespace[];
    k8sNodes: Node[];
}): GraphNode;
/**
 * Walks the graph do find the parent of the given node
 */
export declare function getParentNode(graph: GraphNode, elementId: string): GraphNode | undefined;
/**
 * Finds a Node with a group type that contains a given node
 * @param graph - graph which contains the Node
 * @param elementId - ID of a given Node
 * @param strict - If set to false will try to find closest group, if set to true always returns the parent
 * @returns
 */
export declare function findGroupContaining(graph: GraphNode, elementId: string, strict?: boolean): GraphNode | undefined;
/**
 * Given a graph with groups, this function will 'collapse' all groups without
 * the selected node. 'Collapsing' means that group won't show all children but
 * only a preview
 *
 * If selectedNodeId is passed, only shows group containing that node
 *
 * @param graph Single graph node
 * @param params.selectedNodeId Graph node that is selected
 * @param params.expandAll Display all the children within all groups
 * @returns Collapsed graph
 */
export declare function collapseGraph(graph: GraphNode, { selectedNodeId, expandAll }: {
    selectedNodeId?: string;
    expandAll: boolean;
}): {
    id: string;
    label?: string;
    subtitle?: string;
    icon?: import("react").ReactNode;
    kubeObject?: import("../../../lib/k8s/KubeObject").KubeObject;
    nodes?: GraphNode[];
    edges?: GraphEdge[];
    collapsed?: boolean;
    detailsComponent?: import("react").ComponentType<{
        node: GraphNode;
    }>;
    weight?: number;
    data?: any;
    customResourceDefinition?: string;
};
