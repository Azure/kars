import HPA from '../../../lib/k8s/hpa';
export declare function HorizontalPodAutoscalerGlance({ hpa }: {
    hpa: HPA;
}): import("react/jsx-runtime").JSX.Element;
