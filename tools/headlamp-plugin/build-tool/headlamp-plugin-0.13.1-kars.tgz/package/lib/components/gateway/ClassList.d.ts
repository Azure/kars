export declare function makeGatewayStatusLabel(conditions: any[] | null): import("react/jsx-runtime").JSX.Element | null;
export default function GatewayClassList(): import("react/jsx-runtime").JSX.Element;
