export default function GatewayDetails(props: {
    name?: string;
    namespace?: string;
}): import("react/jsx-runtime").JSX.Element;
