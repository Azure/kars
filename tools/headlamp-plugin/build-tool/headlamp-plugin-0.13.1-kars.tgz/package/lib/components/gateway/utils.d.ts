import { GatewayParentReference } from '../../lib/k8s/gateway';
export declare function GatewayParentRefSection(props: {
    parentRefs: GatewayParentReference[];
}): import("react/jsx-runtime").JSX.Element;
