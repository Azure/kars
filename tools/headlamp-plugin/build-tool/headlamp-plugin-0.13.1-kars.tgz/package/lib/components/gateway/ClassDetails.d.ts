export default function GatewayClassDetails(props: {
    name?: string;
}): import("react/jsx-runtime").JSX.Element;
