export default function GRPCRouteList(): import("react/jsx-runtime").JSX.Element;
