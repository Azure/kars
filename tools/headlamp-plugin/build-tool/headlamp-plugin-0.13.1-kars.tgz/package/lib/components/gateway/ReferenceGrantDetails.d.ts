export default function ReferenceGrantDetails(props: {
    name?: string;
    namespace?: string;
}): import("react/jsx-runtime").JSX.Element;
