export default function BackendTrafficPolicyList(): import("react/jsx-runtime").JSX.Element;
