export default function HTTPRouteList(): import("react/jsx-runtime").JSX.Element;
