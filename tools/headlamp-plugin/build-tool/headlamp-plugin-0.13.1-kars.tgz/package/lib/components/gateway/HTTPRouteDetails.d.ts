export interface RuleMatchesProps {
    matches?: {
        path: {
            type?: string;
            value: string;
        };
        headers?: any[];
        queryParams?: any[];
        method?: string;
    }[];
}
export declare function RuleMatches(props: RuleMatchesProps): import("react/jsx-runtime").JSX.Element | null;
export interface RuleFiltersProps {
    filters?: {
        type: string;
        [key: string]: any;
    }[];
}
export declare function RuleFilters(props: RuleFiltersProps): import("react/jsx-runtime").JSX.Element | null;
export interface RuleBackendRefsProps {
    namespace?: string;
    backendRefs?: {
        group?: string;
        kind?: string;
        name: string;
        namespace?: string;
        port?: string;
        weight?: number;
    }[];
}
export declare function RuleBackendRefs(props: RuleBackendRefsProps): import("react/jsx-runtime").JSX.Element | null;
export default function HTTPRouteDetails(props: {
    name?: string;
    namespace?: string;
}): import("react/jsx-runtime").JSX.Element;
