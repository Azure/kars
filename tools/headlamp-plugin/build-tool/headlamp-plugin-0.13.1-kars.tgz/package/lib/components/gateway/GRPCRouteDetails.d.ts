export default function GRPCRouteDetails(props: {
    name?: string;
    namespace?: string;
}): import("react/jsx-runtime").JSX.Element;
