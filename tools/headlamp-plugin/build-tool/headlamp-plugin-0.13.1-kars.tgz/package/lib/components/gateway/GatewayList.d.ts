export default function GatewayList(): import("react/jsx-runtime").JSX.Element;
