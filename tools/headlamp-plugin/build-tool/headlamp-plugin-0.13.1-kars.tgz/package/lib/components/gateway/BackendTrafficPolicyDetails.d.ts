export default function BackendTrafficPolicyDetails(props: {
    name?: string;
    namespace?: string;
}): import("react/jsx-runtime").JSX.Element;
