export default function BackendTLSPolicyList(): import("react/jsx-runtime").JSX.Element;
