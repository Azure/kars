export default function ReferenceGrantList(): import("react/jsx-runtime").JSX.Element;
