import { FunctionComponent } from 'react';
declare const OIDCAuth: FunctionComponent<{}>;
export default OIDCAuth;
