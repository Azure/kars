import Button from '@mui/material/Button';
import React, { ReactNode } from 'react';
interface OauthPopupProps {
    width?: number;
    height?: number;
    url: string;
    title?: string;
    onClose?: () => any;
    onCode: (params: any) => any;
    children?: ReactNode;
    button: typeof Button;
}
declare const OauthPopup: React.FC<OauthPopupProps>;
export default OauthPopup;
