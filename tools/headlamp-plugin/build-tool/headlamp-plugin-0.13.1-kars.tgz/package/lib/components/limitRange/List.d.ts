import { ApiError } from '../../lib/k8s/api/v2/ApiError';
import { LimitRange } from '../../lib/k8s/limitRange';
import { SimpleTableProps } from '../common/SimpleTable';
export interface LimitRangeProps {
    limitRanges: LimitRange[] | null;
    errors: ApiError[] | null;
    hideColumns?: string[];
    reflectTableInURL?: SimpleTableProps['reflectInURL'];
    noNamespaceFilter?: boolean;
}
export declare function LimitRangeRenderer(props: LimitRangeProps): import("react/jsx-runtime").JSX.Element;
export declare function LimitRangeList(): import("react/jsx-runtime").JSX.Element;
