export default function StatefulSetList(): import("react/jsx-runtime").JSX.Element;
