export declare function ResourceQuotaTable({ resourceStats, }: {
    resourceStats: {
        name: string;
        hard: string;
        used: string;
    }[];
}): import("react/jsx-runtime").JSX.Element;
export default function ResourceQuotaDetails(props: {
    name?: string;
    namespace?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
