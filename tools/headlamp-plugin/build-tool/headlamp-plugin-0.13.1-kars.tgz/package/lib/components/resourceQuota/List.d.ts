import { ApiError } from '../../lib/k8s/api/v2/ApiError';
import ResourceQuota from '../../lib/k8s/resourceQuota';
import { SimpleTableProps } from '../common/SimpleTable';
export interface ResourceQuotaProps {
    resourceQuotas: ResourceQuota[] | null;
    errors: ApiError[] | null;
    hideColumns?: string[];
    reflectTableInURL?: SimpleTableProps['reflectInURL'];
    noNamespaceFilter?: boolean;
}
export declare function ResourceQuotaRenderer(props: ResourceQuotaProps): import("react/jsx-runtime").JSX.Element;
export default function ResourceQuotaList(): import("react/jsx-runtime").JSX.Element;
