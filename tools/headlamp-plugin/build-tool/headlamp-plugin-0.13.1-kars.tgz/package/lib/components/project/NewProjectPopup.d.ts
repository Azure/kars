/**
 * A dialog for creating a new project.
 * It provides several options for creating a project, such as from a namespace,
 * auto-detection, from YAML, or a custom project.
 */
export declare function NewProjectPopup({ open, onClose }: {
    open: boolean;
    onClose: () => void;
}): import("react/jsx-runtime").JSX.Element;
