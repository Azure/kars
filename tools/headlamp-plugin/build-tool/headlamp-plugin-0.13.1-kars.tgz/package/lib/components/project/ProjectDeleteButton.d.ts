import { ProjectDefinition } from '../../redux/projectsSlice';
import { ButtonStyle } from '../common/ActionButton';
interface ProjectDeleteButtonProps {
    project: ProjectDefinition;
    buttonStyle?: ButtonStyle;
}
export declare function ProjectDeleteButton({ project, buttonStyle }: ProjectDeleteButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
