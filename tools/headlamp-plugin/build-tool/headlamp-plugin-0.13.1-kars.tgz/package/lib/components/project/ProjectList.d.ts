import { ProjectDefinition } from '../../redux/projectsSlice';
export declare const useProject: (name: string) => {
    isLoading: boolean;
    project: ProjectDefinition | undefined;
};
export default function ProjectList(): import("react/jsx-runtime").JSX.Element;
