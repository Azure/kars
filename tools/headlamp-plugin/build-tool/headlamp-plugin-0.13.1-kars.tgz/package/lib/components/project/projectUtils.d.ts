import { ApiResource } from '../../lib/k8s/api/v2/ApiResource';
import { KubeObject } from '../../lib/k8s/KubeObject';
import { KubeObjectStatus } from '../resourceMap/nodes/KubeObjectStatus';
export declare const PROJECT_ID_LABEL = "headlamp.dev/project-id";
export declare const getHealthIcon: (healthy: number, unhealthy: number, warning: number) => "mdi:help-circle" | "mdi:alert-circle" | "mdi:alert" | "mdi:check-circle";
export declare const getResourcesByKind: (resources: KubeObject[], kind: string) => KubeObject<any>[];
export declare const getResourcesHealth: (resources: KubeObject[]) => Record<KubeObjectStatus, number>;
export declare const defaultApiResources: ApiResource[];
export declare const toKubernetesName: (name: string) => string;
