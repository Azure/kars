import { ProjectDefinition } from '../../redux/projectsSlice';
export declare function useProjectItems(project: ProjectDefinition, { disableWatch }?: {
    disableWatch?: boolean;
}): {
    items: any[];
    errors: {
        resource: import("../../lib/k8s/api/v2/ApiResource").ApiResource;
        errors: import("../../ApiProxy").ApiError[];
    }[];
    isLoading: boolean;
};
