import { KubeObject } from '../../lib/k8s/KubeObject';
import { ResourceCategory } from '../../lib/k8s/ResourceCategory';
import { KubeObjectStatus } from '../resourceMap/nodes/KubeObjectStatus';
export declare function ResourceCategoriesList({ categoryList, selectedCategoryName, onCategoryClick, }: {
    categoryList: Array<{
        category: ResourceCategory;
        items: KubeObject[];
        health: Record<KubeObjectStatus, number>;
    }>;
    selectedCategoryName?: string;
    onCategoryClick: (categoryName: string) => void;
}): import("react/jsx-runtime").JSX.Element;
