export default function ProjectDetails(): import("react/jsx-runtime").JSX.Element;
