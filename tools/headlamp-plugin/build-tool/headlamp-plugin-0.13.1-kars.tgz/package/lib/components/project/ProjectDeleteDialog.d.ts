import Namespace from '../../lib/k8s/namespace';
import { ProjectDefinition } from '../../redux/projectsSlice';
interface ProjectDeleteDialogProps {
    open: boolean;
    project: ProjectDefinition;
    onClose: () => void;
    namespaces: Namespace[];
}
export declare function ProjectDeleteDialog({ open, project, onClose, namespaces, }: ProjectDeleteDialogProps): import("react/jsx-runtime").JSX.Element;
export {};
