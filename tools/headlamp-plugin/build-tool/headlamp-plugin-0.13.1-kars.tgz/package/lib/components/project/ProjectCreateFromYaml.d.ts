export declare function CreateNew(): import("react/jsx-runtime").JSX.Element;
