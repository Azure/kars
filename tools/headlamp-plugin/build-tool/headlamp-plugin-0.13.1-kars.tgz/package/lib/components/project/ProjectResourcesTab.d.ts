import { KubeObject } from '../../lib/k8s/KubeObject';
import { ResourceCategory } from '../../lib/k8s/ResourceCategory';
import { KubeObjectStatus } from '../resourceMap/nodes/KubeObjectStatus';
export declare const useResourceCategoriesList: (resources: KubeObject[]) => {
    category: ResourceCategory;
    items: KubeObject<any>[];
    health: Record<KubeObjectStatus, number>;
}[];
interface ProjectResourcesTabProps {
    projectResources: KubeObject[];
    showClusterColumn?: boolean;
    selectedCategoryName?: string;
    setSelectedCategoryName: (name: string) => void;
}
export declare function ProjectResourcesTab({ projectResources, showClusterColumn, selectedCategoryName, setSelectedCategoryName, }: ProjectResourcesTabProps): import("react/jsx-runtime").JSX.Element;
export {};
