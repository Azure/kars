export default function VersionButton(): import("react/jsx-runtime").JSX.Element | null;
