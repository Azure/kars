export default function NavigationTabs(): import("react/jsx-runtime").JSX.Element | null;
