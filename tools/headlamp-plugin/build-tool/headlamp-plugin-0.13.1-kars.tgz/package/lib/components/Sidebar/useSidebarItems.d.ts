import { SidebarItemProps } from '.';
export declare const useSidebarItems: (sidebarName?: string) => Omit<SidebarItemProps, "sidebar">[];
