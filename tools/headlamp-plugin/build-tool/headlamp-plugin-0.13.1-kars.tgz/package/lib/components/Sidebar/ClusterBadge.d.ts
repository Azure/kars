export interface ClusterBadgeProps {
    /** Cluster display name */
    name: string;
    /** Accent color for the circular icon background */
    accentColor?: string;
    /** Icon to display in the badge */
    icon?: string;
}
/**
 * ClusterBadge displays an icon with a colored circle and cluster name
 * Used in the sidebar to show selected clusters
 */
export default function ClusterBadge({ name, accentColor, icon }: ClusterBadgeProps): import("react/jsx-runtime").JSX.Element;
