import { ListItemProps } from '@mui/material/ListItem';
import React from 'react';
import { SidebarEntry } from './sidebarSlice';
export declare function getFullURLOnRoute(name: string, isCR: boolean | undefined, subList: Omit<SidebarItemProps, 'sidebar'>[]): string;
/**
 * Adds onto SidebarEntryProps for the display of the sidebars.
 */
export interface SidebarItemProps extends ListItemProps, SidebarEntry {
    /** Whether this item is selected. */
    isSelected?: boolean;
    /** The navigation is a child. */
    hasParent?: boolean;
    /** Displayed wide with icon and text, otherwise with just a small icon. */
    fullWidth?: boolean;
    /** Search part of the URL. */
    search?: string;
    /** If a menu item has sub menu items, they will be in here. */
    subList?: Omit<this, 'sidebar'>[];
    /** Whether to hide the sidebar item. */
    hide?: boolean;
    level?: number;
    isCR?: boolean;
}
declare const SidebarItem: React.MemoExoticComponent<(props: SidebarItemProps) => import("react/jsx-runtime").JSX.Element | null>;
export default SidebarItem;
