import { IconProps } from '@iconify/react';
import { PayloadAction } from '@reduxjs/toolkit';
import React from 'react';
export declare enum DefaultSidebars {
    HOME = "HOME",
    IN_CLUSTER = "IN-CLUSTER"
}
/**
 * Represents an entry in the sidebar menu.
 */
export interface SidebarEntry {
    /**
     * Name of this SidebarItem.
     */
    name: string;
    /**
     * Text to display under the name.
     */
    subtitle?: React.ReactNode;
    /**
     * Label to display.
     */
    label: string;
    /**
     * Name of the parent SidebarEntry.
     */
    parent?: string | null;
    /**
     * URL to go to when this item is followed.
     */
    url?: string;
    /**
     * Should URL have the cluster prefix? (default=true)
     */
    useClusterURL?: boolean;
    /**
     * An iconify string or icon object that will be used for the sidebar's icon
     *
     * @see https://icon-sets.iconify.design/mdi/ for icons.
     */
    icon?: IconProps['icon'];
    /** The sidebar to display this item in. If not specified, it will be displayed in the default sidebar.
     */
    sidebar?: DefaultSidebars | string;
}
export interface SidebarState {
    /**
     * The currently selected item in the sidebar.
     */
    selected: {
        item: string | null;
        sidebar: string | DefaultSidebars | null;
    };
    /**
     * Is the sidebar visible?
     */
    isVisible: boolean;
    /**
     * Is the sidebar open?
     */
    isSidebarOpen?: boolean;
    /**
     * Was there user interaction to set the sidebar open?
     */
    isSidebarOpenUserSelected?: boolean;
    /**
     * The entries in the sidebar.
     */
    entries: {
        [propName: string]: SidebarEntry;
    };
    /**
     * Filters to apply to the sidebar entries.
     */
    filters: ((entry: SidebarEntry) => SidebarEntry | null)[];
}
export declare function setInitialSidebarOpen(): {
    isSidebarOpen: boolean;
    isSidebarOpenUserSelected: undefined;
};
export declare const initialState: SidebarState;
declare const sidebarSlice: import("@reduxjs/toolkit").Slice<SidebarState, {
    /**
     * Sets the selected item in the sidebar.
     */
    setSidebarSelected(state: import("immer").WritableDraft<SidebarState>, action: PayloadAction<{
        item: string | null;
        sidebar: string | DefaultSidebars | null;
    }>): void;
    /**
     * Sets the visibility of the sidebar.
     */
    setSidebarVisible(state: import("immer").WritableDraft<SidebarState>, action: PayloadAction<boolean>): void;
    /**
     * Sets an item in the sidebar.
     */
    setSidebarItem(state: import("immer").WritableDraft<SidebarState>, action: PayloadAction<SidebarEntry>): void;
    /**
     * Sets a filter for sidebar items.
     */
    setSidebarItemFilter(state: import("immer").WritableDraft<SidebarState>, action: PayloadAction<(entry: SidebarEntry) => SidebarEntry | null>): void;
    /**
     * Sets whether the sidebar is open or not.
     */
    setWhetherSidebarOpen(state: import("immer").WritableDraft<SidebarState>, action: PayloadAction<boolean>): void;
}, "sidebar", "sidebar", import("@reduxjs/toolkit").SliceSelectors<SidebarState>>;
export declare const setSidebarSelected: import("@reduxjs/toolkit").ActionCreatorWithPayload<{
    item: string | null;
    sidebar: string | DefaultSidebars | null;
}, "sidebar/setSidebarSelected">, setSidebarVisible: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "sidebar/setSidebarVisible">, setSidebarItem: import("@reduxjs/toolkit").ActionCreatorWithPayload<SidebarEntry, "sidebar/setSidebarItem">, setSidebarItemFilter: import("@reduxjs/toolkit").ActionCreatorWithPayload<(entry: SidebarEntry) => SidebarEntry | null, "sidebar/setSidebarItemFilter">, setWhetherSidebarOpen: import("@reduxjs/toolkit").ActionCreatorWithPayload<boolean, "sidebar/setWhetherSidebarOpen">;
export { sidebarSlice };
declare const _default: import("redux").Reducer<SidebarState>;
export default _default;
