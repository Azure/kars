import { IconProps } from '@iconify/react';
import React from 'react';
interface ListItemLinkProps {
    primary: string;
    pathname: string;
    search?: string;
    name: string;
    subtitle?: React.ReactNode;
    tabIndex?: number;
    icon?: IconProps['icon'];
    iconOnly?: boolean;
    hasParent?: boolean;
    level?: number;
    fullWidth?: boolean;
    divider?: boolean;
    containerProps?: {
        [prop: string]: any;
    };
}
export default function ListItemLink(props: ListItemLinkProps): import("react/jsx-runtime").JSX.Element;
export {};
