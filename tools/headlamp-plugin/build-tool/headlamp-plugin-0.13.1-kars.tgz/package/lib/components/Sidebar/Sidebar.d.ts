import React from 'react';
import NavigationTabs from './NavigationTabs';
import { SidebarItemProps } from './SidebarItem';
import { DefaultSidebars } from './sidebarSlice';
export declare const drawerWidth = 240;
export declare const mobileDrawerWidth = 320;
export declare const drawerWidthClosed = 64;
export { DefaultSidebars };
export declare function useSidebarInfo(): {
    isCollapsed: boolean;
    isOpen: boolean;
    isNarrow: boolean;
    canExpand: boolean;
    isTemporary: boolean;
    isUserOpened: boolean | undefined;
    width: string;
};
export default function Sidebar(): import("react/jsx-runtime").JSX.Element | null;
export interface PureSidebarProps {
    /** If the sidebar is fully expanded open or shrunk. */
    open?: boolean;
    /** If the user has selected to open/shrink the sidebar */
    openUserSelected?: boolean;
    /** To show in the sidebar. */
    items: SidebarItemProps[];
    /** The selected route name of the sidebar open. */
    selectedName: string | null;
    /** If the sidebar is the temporary one (full sidebar when user selects it in mobile). */
    isTemporaryDrawer?: boolean;
    /** If the sidebar is in narrow mode. */
    isNarrowOnly?: boolean;
    /** Called when sidebar toggles between open and closed. */
    onToggleOpen: () => void;
    /** The search part of the url */
    search?: string;
    /** A place to put extra components below the links. */
    linkArea: React.ReactNode;
}
export declare const PureSidebar: React.MemoExoticComponent<({ open, openUserSelected, items, isTemporaryDrawer, isNarrowOnly, onToggleOpen, search, linkArea, }: PureSidebarProps) => import("react/jsx-runtime").JSX.Element>;
export declare function useSidebarItem(sidebarDesc: string | null | {
    item: string | null;
    sidebar?: string;
}, computedMatch: any): void;
export { NavigationTabs };
