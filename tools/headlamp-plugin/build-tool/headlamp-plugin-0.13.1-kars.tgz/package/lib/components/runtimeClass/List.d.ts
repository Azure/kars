export declare function RuntimeClassList(): import("react/jsx-runtime").JSX.Element;
