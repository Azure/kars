export declare function SearchSettings({ maxItemsPerResource, setMaxItemsPerResource, refetchIntervalMs, setRefetchIntervalMs, }: {
    maxItemsPerResource: number;
    setMaxItemsPerResource: (n: number) => void;
    refetchIntervalMs: number;
    setRefetchIntervalMs: (n: number) => void;
}): import("react/jsx-runtime").JSX.Element;
