import { ApiResource } from '../../lib/k8s/api/v2/ApiResource';
export interface ApiResourcesViewProps {
    /** List of resources to render */
    resources: ApiResource[];
    /** Selected resources */
    selectedResources?: Set<string>;
    /** Callback when a source is toggled */
    setSelectedResources: (source: Set<string>) => void;
}
/**
 * A component that renders a dropdown button which opens a popover with searchable resource selection UI.
 */
export declare const ApiResourcesView: import("react").MemoExoticComponent<({ resources, selectedResources: selectedSources, setSelectedResources, }: ApiResourcesViewProps) => import("react/jsx-runtime").JSX.Element>;
