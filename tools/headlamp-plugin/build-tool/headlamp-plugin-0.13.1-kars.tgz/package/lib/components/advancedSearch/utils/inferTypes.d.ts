/**
 * Generates TypeScript global variable declarations (`declare var name: type;`)
 * for each top-level property found in the input objects that is a valid identifier.
 * The type represents the deep, combined structure of that property's value, potentially
 * using string literal types for strings with few distinct values.
 * Keys that are not valid JavaScript identifiers are skipped.
 *
 * @param objects - The array of input objects.
 * @returns A string containing all the generated `declare var` statements, separated by newlines.
 * @throws {TypeError} If the input is not an array.
 */
export declare function generateGlobalVarDeclarations(objects: Record<string, any>[], maxKeysPerObject?: number): string;
