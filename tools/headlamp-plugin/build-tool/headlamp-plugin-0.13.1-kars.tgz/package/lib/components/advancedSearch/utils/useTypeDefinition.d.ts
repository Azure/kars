/**
 * Generates a TypeScript type definition based on an array of items.
 *
 * @param items - The array of items to generate a type definition from
 * @param maxKeysPerObject - The maximum number of keys per object to include in the type definition
 * @returns A string representation of the generated TypeScript type definition
 */
export declare const useTypeDefinition: (items: any[], maxKeysPerObject: number) => string;
