export declare const ADVANCED_SEARCH_QUERY_KEY = "advanced-search-query";
/**
 * AdvancedSearch component provides an interface for searching Kubernetes resources
 * with advanced filtering capabilities.
 */
export declare function AdvancedSearch(): import("react/jsx-runtime").JSX.Element;
