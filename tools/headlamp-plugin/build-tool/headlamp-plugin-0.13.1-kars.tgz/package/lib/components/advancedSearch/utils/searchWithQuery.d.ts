/**
 * Performs an asynchronous search on a collection of items using a custom query function.
 * The search process can be interrupted by setting the interruptRef to true.
 *
 * @param {any[]} items - The array of items to search through. Each item is expected to have a jsonData property.
 * @param {string} query - A string expression that will be converted into a query function. This should be a valid JavaScript expression that returns a boolean.
 * @param {Object} interruptRef - A ref object with a `current` property that can be set to true to interrupt the search.
 */
export declare function searchWithQuery<T extends {
    jsonData: any;
}>(items: T[], query: string, interruptRef: {
    current: boolean;
}): Promise<{
    results: T[];
    searchTimeMs: number;
}>;
