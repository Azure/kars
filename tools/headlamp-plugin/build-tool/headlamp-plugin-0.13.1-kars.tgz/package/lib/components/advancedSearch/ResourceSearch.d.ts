import { ApiResource } from '../../lib/k8s/api/v2/ApiResource';
import { KubeObject } from '../../lib/k8s/KubeObject';
export declare function ResourceSearch({ resources, selectedClusters, rawQuery, maxItemsPerResource, refetchIntervalMs, setRawQuery, }: {
    resources: ApiResource[];
    selectedClusters: string[];
    rawQuery: string;
    maxItemsPerResource: number;
    refetchIntervalMs: number;
    setRawQuery: (q?: string) => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function ViewYaml({ item }: {
    item: KubeObject;
}): import("react/jsx-runtime").JSX.Element;
