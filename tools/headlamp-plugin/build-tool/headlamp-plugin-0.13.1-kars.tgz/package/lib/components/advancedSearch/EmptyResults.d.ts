import { ApiResource } from '../../lib/k8s/api/v2/ApiResource';
/**
 * Placeholder for when there are no results
 */
export declare function EmptyResults({ resources, onQuerySelected, }: {
    resources: ApiResource[];
    onQuerySelected: (resources: ApiResource[], query: string) => void;
}): import("react/jsx-runtime").JSX.Element;
