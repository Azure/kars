import { ApiError } from '../../../lib/k8s/api/v2/ApiError';
import { ApiResource } from '../../../lib/k8s/api/v2/ApiResource';
/**
 * A hook that fetches and returns a list of Kubernetes objects for the specified resources.
 *
 * @param resources - An array of ApiResource objects specifying the kinds of resources to fetch.
 * @param clusters - An array of cluster names from which to fetch the resources.
 * @param maxItems - Maximum amount of items per resource.
 * @param refetchIntervalMs - How often to refresh resources. In milliseconds.
 * @returns An array of Kubernetes objects from the specified resources and clusters.
 */
export declare const useKubeLists: (resources: ApiResource[], clusters: string[], maxItems: number, refetchIntervalMs?: number, namespaces?: string[]) => {
    items: any[];
    errors: {
        resource: ApiResource;
        errors: ApiError[];
    }[];
    isLoading: boolean;
};
