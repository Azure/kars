/**
 * Extracts and returns all unique top-level property keys from an array of objects.
 *
 * @param items - An array of objects from which to extract top-level keys
 */
export declare const getTopLevelKeys: (items: any[]) => string[];
