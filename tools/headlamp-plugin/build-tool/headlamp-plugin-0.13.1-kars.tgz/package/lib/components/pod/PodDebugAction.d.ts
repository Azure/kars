import Pod from '../../lib/k8s/pod';
/**
 * Props for PodDebugAction.
 *
 * @property {Pod | null} item - Pod to debug or null
 */
interface PodDebugActionProps {
    item: Pod | null;
}
/**
 * Action button for launching a pod debug terminal.
 *
 * Requires pod existence, enabled cluster settings, and patch/attach permissions.
 * Focuses existing session instead of creating duplicates.
 *
 * @param props - Pod to debug
 * @returns ActionButton wrapped in auth guards, or null
 */
export declare function PodDebugAction(props: PodDebugActionProps): import("react/jsx-runtime").JSX.Element | null;
export {};
