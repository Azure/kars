export declare const ANSI_BLUE = "\u001B[34m";
export declare const ANSI_GREEN = "\u001B[32m";
export declare const ANSI_RESET = "\u001B[0m";
/**
 * Colorizes a JSON log entry with ANSI color codes for better readability.
 * @param logEntry - The log entry to colorize
 * @returns The colorized log entry string
 */
export declare function colorizePrettifiedLog(logEntry: string): string;
