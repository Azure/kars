import Pod from '../../lib/k8s/pod';
import { LogViewerProps } from '../common/LogViewer';
interface PodLogViewerProps extends Omit<LogViewerProps, 'logs'> {
    item: Pod;
}
export declare function PodLogViewer(props: PodLogViewerProps): import("react/jsx-runtime").JSX.Element;
export interface VolumeDetailsProps {
    volumes: any[] | null;
}
export declare function VolumeDetails(props: VolumeDetailsProps): import("react/jsx-runtime").JSX.Element | null;
export interface PodDetailsProps {
    showLogsDefault?: boolean;
    name?: string;
    namespace?: string;
    cluster?: string;
}
export default function PodDetails(props: PodDetailsProps): import("react/jsx-runtime").JSX.Element;
export {};
