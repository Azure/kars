import { ApiError } from '../../lib/k8s/api/v2/ApiError';
import Pod from '../../lib/k8s/pod';
import { PodMetrics } from '../../lib/k8s/PodMetrics';
import { SimpleTableProps } from '../common/SimpleTable';
export declare function makePodStatusLabel(pod: Pod, showContainerStatus?: boolean): import("react/jsx-runtime").JSX.Element;
export interface PodListProps {
    pods: Pod[] | null;
    metrics: PodMetrics[] | null;
    hideColumns?: ('namespace' | 'restarts')[];
    reflectTableInURL?: SimpleTableProps['reflectInURL'];
    noNamespaceFilter?: boolean;
    errors?: ApiError[] | null;
}
export declare function PodListRenderer(props: PodListProps): import("react/jsx-runtime").JSX.Element;
export default function PodList(): import("react/jsx-runtime").JSX.Element;
