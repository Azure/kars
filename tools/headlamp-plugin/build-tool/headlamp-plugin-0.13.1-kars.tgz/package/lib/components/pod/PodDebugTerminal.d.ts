import Pod from '../../lib/k8s/pod';
/**
 * Props for PodDebugTerminal.
 *
 * @property {Pod} item - Pod instance to debug
 * @property {() => void} [onClose] - Callback when terminal closes
 */
interface PodDebugTerminalProps {
    item: Pod;
    onClose?: () => void;
}
/**
 * Terminal component for debugging pods using ephemeral containers.
 *
 * Creates or attaches to ephemeral debug containers with configurable images.
 * Reuses existing running containers and attempts cleanup on close.
 *
 * Note: Ephemeral containers cannot be removed via API and persist in pod spec.
 *
 * @param props - Pod and optional close callback
 * @returns DialogContent with embedded terminal
 */
export declare function PodDebugTerminal(props: PodDebugTerminalProps): import("react/jsx-runtime").JSX.Element;
export {};
