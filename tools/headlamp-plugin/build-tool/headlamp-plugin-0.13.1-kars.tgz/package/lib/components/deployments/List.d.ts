export default function DeploymentsList(): import("react/jsx-runtime").JSX.Element;
