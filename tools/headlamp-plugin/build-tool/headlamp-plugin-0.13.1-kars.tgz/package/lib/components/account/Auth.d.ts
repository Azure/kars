import { SnackbarCloseReason } from '@mui/material/Snackbar';
import React from 'react';
export default function AuthToken(): import("react/jsx-runtime").JSX.Element;
interface clickCallbackType {
    (event: React.MouseEvent<HTMLElement>): void;
}
interface changeCallbackType {
    (event: React.ChangeEvent<HTMLInputElement>): void;
}
export interface PureAuthTokenProps {
    title: string;
    token: string;
    showActions: boolean;
    showError: boolean;
    onCancel: clickCallbackType;
    onChangeToken: changeCallbackType;
    onAuthClicked: clickCallbackType;
    onCloseError: (event: Event | React.SyntheticEvent<any, Event>, reason: SnackbarCloseReason) => void;
}
export declare function PureAuthToken({ title, token, showActions, showError, onCancel, onAuthClicked, onChangeToken, onCloseError, }: PureAuthTokenProps): import("react/jsx-runtime").JSX.Element;
export {};
