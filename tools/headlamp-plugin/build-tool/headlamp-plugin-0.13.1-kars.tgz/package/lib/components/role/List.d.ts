export default function RoleList({ namespaces }: {
    namespaces?: string[];
}): import("react/jsx-runtime").JSX.Element;
