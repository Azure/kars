export default function RoleBindingList(): import("react/jsx-runtime").JSX.Element;
