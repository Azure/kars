export default function PortForwardingList(): import("react/jsx-runtime").JSX.Element;
