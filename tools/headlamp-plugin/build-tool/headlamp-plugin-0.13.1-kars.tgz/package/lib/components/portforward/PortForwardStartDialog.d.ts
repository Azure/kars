export interface PortForwardStartDialogProps {
    open: boolean;
    defaultPort?: string;
    podName: string;
    namespace: string;
    containerPort: string | number;
    onCancel: () => void;
    onConfirm: (portInput?: string) => void;
    isDockerDesktop?: boolean;
}
export default function PortForwardStartDialog(props: PortForwardStartDialogProps): import("react/jsx-runtime").JSX.Element;
