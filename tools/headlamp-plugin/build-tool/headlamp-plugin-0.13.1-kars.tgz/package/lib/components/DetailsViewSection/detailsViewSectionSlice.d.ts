import { PayloadAction } from '@reduxjs/toolkit';
import { ReactNode } from 'react';
import { KubeObject } from '../../lib/k8s/KubeObject';
import { DetailsViewSectionType } from './DetailsViewSection';
export type DetailsViewSection = {
    id: string;
    section?: DetailsViewSectionType;
};
export declare enum DefaultDetailsViewSection {
    METADATA = "METADATA",
    BACK_LINK = "BACK_LINK",
    MAIN_HEADER = "MAIN_HEADER",
    EVENTS = "EVENTS",
    ERROR = "ERROR",
    LOADING = "LOADING",
    CHILDREN = "CHILDREN"
}
type HeaderActionFuncType = (resource: KubeObject | null, sections: (DetailsViewSection | ReactNode)[]) => (DetailsViewSection | ReactNode)[];
export type DetailsViewsSectionProcessor = {
    id: string;
    processor: HeaderActionFuncType;
};
export type DetailsViewSectionProcessorArgs = {
    actions: DetailsViewSection[];
};
export type DetailsViewSectionProcessorType = (info: DetailsViewSectionProcessorArgs) => DetailsViewSection[];
export type DetailsViewSectionsProcessor = {
    id: string;
    processor: DetailsViewSectionProcessorType;
};
export interface DetailsViewSectionState {
    /**
     * List of details views.
     */
    detailViews: DetailsViewSectionType[];
    /**
     * List of details view sections.
     */
    detailsViewSections: DetailsViewSection[];
    /**
     * List of details view sections processors.
     */
    detailsViewSectionsProcessors: DetailsViewsSectionProcessor[];
}
declare const detailsViewSectionSlice: import("@reduxjs/toolkit").Slice<DetailsViewSectionState, {
    /**
     * Sets details view.
     */
    setDetailsView(state: import("immer").WritableDraft<DetailsViewSectionState>, action: PayloadAction<DetailsViewSectionType>): void;
    /**
     * Sets details view section.
     *
     * If the processor is passed as a function, it will be wrapped in an object with a generated ID.
     */
    setDetailsViewSection(state: import("immer").WritableDraft<DetailsViewSectionState>, action: PayloadAction<DetailsViewSectionType | DetailsViewSection>): void;
    /**
     * Adds a details view sections processor.
     *
     * If the processor is passed as a function, it will be wrapped in an object with a generated ID.
     */
    addDetailsViewSectionsProcessor(state: import("immer").WritableDraft<DetailsViewSectionState>, action: PayloadAction<DetailsViewsSectionProcessor | DetailsViewsSectionProcessor["processor"]>): void;
}, "detailsViewSection", "detailsViewSection", import("@reduxjs/toolkit").SliceSelectors<DetailsViewSectionState>>;
export declare const addDetailsViewSectionsProcessor: import("@reduxjs/toolkit").ActionCreatorWithPayload<DetailsViewsSectionProcessor | HeaderActionFuncType, "detailsViewSection/addDetailsViewSectionsProcessor">, setDetailsView: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<DetailsViewSectionType, "detailsViewSection/setDetailsView">, setDetailsViewSection: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<DetailsViewSectionType | DetailsViewSection, "detailsViewSection/setDetailsViewSection">;
export { detailsViewSectionSlice };
declare const _default: import("redux").Reducer<DetailsViewSectionState>;
export default _default;
