import { ReactElement, ReactNode } from 'react';
import { KubeObject } from '../../lib/k8s/KubeObject';
export interface DetailsViewSectionProps {
    resource: KubeObject;
}
export type DetailsViewSectionType = ((...args: any[]) => ReactNode) | null | ReactElement | ReactNode;
/**
 * View components registered by plugins in the different Details views.
 *
 * @see registerDetailsViewSection
 */
export default function DetailsViewSection(props: DetailsViewSectionProps): import("react/jsx-runtime").JSX.Element;
