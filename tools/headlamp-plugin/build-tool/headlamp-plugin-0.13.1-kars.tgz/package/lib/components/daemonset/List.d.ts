export default function DaemonSetList(): import("react/jsx-runtime").JSX.Element;
