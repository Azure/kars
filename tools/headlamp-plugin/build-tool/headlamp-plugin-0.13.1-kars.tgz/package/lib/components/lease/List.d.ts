export declare function LeaseList(): import("react/jsx-runtime").JSX.Element;
