import { KubeMetrics } from '../../lib/k8s/cluster';
import Node from '../../lib/k8s/node';
interface UsageBarChartProps {
    node: Node;
    nodeMetrics: KubeMetrics[] | null;
    resourceType: keyof KubeMetrics['usage'];
    noMetrics?: boolean;
}
export declare function UsageBarChart(props: UsageBarChartProps): import("react/jsx-runtime").JSX.Element;
export {};
