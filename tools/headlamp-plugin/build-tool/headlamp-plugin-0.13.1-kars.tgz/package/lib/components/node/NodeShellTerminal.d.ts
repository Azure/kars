import Node from '../../lib/k8s/node';
interface NodeShellTerminalProps {
    item: Node;
    onClose?: () => void;
}
export declare function NodeShellTerminal(props: NodeShellTerminalProps): import("react/jsx-runtime").JSX.Element;
export {};
