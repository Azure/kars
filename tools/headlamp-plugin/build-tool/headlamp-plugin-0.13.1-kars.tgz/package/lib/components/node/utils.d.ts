import Node from '../../lib/k8s/node';
export declare function formatTaint(taint: {
    key: string;
    value?: string;
    effect: string;
}): string;
export declare function NodeTaintsLabel(props: {
    node: Node;
}): import("react/jsx-runtime").JSX.Element;
