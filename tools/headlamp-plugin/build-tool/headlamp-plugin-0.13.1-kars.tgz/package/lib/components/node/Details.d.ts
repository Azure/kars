import Node from '../../lib/k8s/node';
export default function NodeDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
interface NodeReadyLabelProps {
    node: Node;
}
export declare function NodeReadyLabel(props: NodeReadyLabelProps): import("react/jsx-runtime").JSX.Element;
export {};
