export default function NodeList(): import("react/jsx-runtime").JSX.Element;
