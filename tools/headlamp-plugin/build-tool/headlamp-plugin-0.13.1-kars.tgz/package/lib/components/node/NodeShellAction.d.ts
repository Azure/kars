import Node from '../../lib/k8s/node';
interface NodeShellTerminalProps {
    item: Node | null;
}
export declare function NodeShellAction(props: NodeShellTerminalProps): import("react/jsx-runtime").JSX.Element;
export {};
