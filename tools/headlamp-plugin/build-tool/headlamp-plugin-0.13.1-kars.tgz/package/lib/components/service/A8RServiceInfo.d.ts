/**
 * Represents a parsed a8r.io annotation item with display metadata.
 */
export type A8RMetadataItem = {
    /** The annotation key without the 'a8r.io/' prefix (e.g., 'owner', 'description') */
    key: string;
    /** Translation key for the display label */
    labelKey: string;
    /** The annotation value */
    value: string;
    /** MDI icon identifier for visual display */
    icon: string;
    /** Whether the value is a valid HTTP/HTTPS URL */
    isLink: boolean;
};
/**
 * Parses Kubernetes service annotations and extracts a8r.io metadata items.
 *
 * Filters annotations starting with 'a8r.io/', maps them to display-friendly
 * metadata items with icons and labels, and sorts by preferred display order.
 *
 * @param annotations - Key-value pairs of Kubernetes annotations (defaults to empty object)
 * @returns Array of parsed metadata items sorted by preferred display order
 */
export declare function getA8RMetadata(annotations?: Record<string, string>): A8RMetadataItem[];
export default function A8RServiceInfo({ annotations }: {
    annotations?: Record<string, string>;
}): import("react/jsx-runtime").JSX.Element | null;
