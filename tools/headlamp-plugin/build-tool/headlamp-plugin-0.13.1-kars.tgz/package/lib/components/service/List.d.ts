export default function ServiceList(): import("react/jsx-runtime").JSX.Element;
