export default function ConfigDetails(props: {
    name?: string;
    namespace?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
