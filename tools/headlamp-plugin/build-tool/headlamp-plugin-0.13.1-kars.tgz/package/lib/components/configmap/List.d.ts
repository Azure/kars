export default function ConfigMapList(): import("react/jsx-runtime").JSX.Element;
