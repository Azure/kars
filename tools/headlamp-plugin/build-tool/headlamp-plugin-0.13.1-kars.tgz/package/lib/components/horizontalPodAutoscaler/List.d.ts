export default function HpaList(): import("react/jsx-runtime").JSX.Element;
