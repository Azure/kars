export declare function CrInstanceList(): import("react/jsx-runtime").JSX.Element;
