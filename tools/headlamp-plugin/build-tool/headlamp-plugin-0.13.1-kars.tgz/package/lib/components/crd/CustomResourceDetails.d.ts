import CustomResourceDefinition from '../../lib/k8s/crd';
export default function CustomResourceDetailsFromURL(): import("react/jsx-runtime").JSX.Element;
export interface CustomResourceDetailsProps {
    crd: string;
    crName: string;
    namespace: string;
    cluster?: string;
}
export declare function CustomResourceDetails({ crd: crdName, crName, namespace: ns, cluster, }: CustomResourceDetailsProps): import("react/jsx-runtime").JSX.Element;
export interface CustomResourceDetailsRendererProps {
    crd: CustomResourceDefinition;
    crName: string;
    namespace?: string;
    cluster?: string;
}
