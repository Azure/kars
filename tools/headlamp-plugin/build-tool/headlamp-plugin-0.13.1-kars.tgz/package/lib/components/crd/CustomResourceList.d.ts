import CRD from '../../lib/k8s/crd';
export default function CustomResourceList(): import("react/jsx-runtime").JSX.Element;
export interface CustomResourceTableProps {
    crd: CRD;
    title?: string;
    includeCRDLink?: boolean;
}
export declare function CustomResourceListTable(props: CustomResourceTableProps): import("react/jsx-runtime").JSX.Element;
