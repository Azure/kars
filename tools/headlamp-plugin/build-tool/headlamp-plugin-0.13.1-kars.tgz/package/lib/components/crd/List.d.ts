export default function CustomResourceDefinitionList(): import("react/jsx-runtime").JSX.Element;
