export default function CustomResourceDefinitionDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
