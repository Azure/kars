import { PayloadAction } from '@reduxjs/toolkit';
/**
 * The maximum number of notifications to store in localStorage.
 */
declare const defaultMaxNotificationsStored = 200;
interface NotificationOptions {
    /**
     * The message of the notification.
     */
    message?: string;
    /**
     * The date of the notification from the server (or where the notification was created).
     */
    date?: number | string | Date;
    /**
     * The cluster the notification is for.
     */
    cluster?: string | null;
}
/** @deprecated use ${NotificationOptions} instead */
type NotificationMessageString = string;
/** @deprecated use ${NotifictionOptions} instead */
type OldNotificationDateArg = number | string;
export interface NotificationIface {
    /**
     * The cluster the notification is for.
     */
    cluster: string | null;
    /**
     * The date the notification was created.
     */
    date: number | string;
    /**
     * True if the notification has been deleted.
     */
    deleted: boolean;
    /**
     * The id of the notification.
     */
    id: string;
    /**
     * The message of the notification.
     */
    message: string;
    /**
     * True if the notification has been seen by the user.
     */
    seen: boolean;
    /**
     * The url to redirect to when the notification is clicked.
     */
    url?: string;
}
export declare class Notification implements NotificationIface {
    cluster: string | null;
    date: number | string;
    deleted: boolean;
    id: string;
    message: string;
    seen: boolean;
    url?: string;
    constructor(messageOrOptions?: NotificationOptions | NotificationMessageString, date?: OldNotificationDateArg);
    prepareMessage(message: string): string;
    static fromJSON(json: any): Notification;
    toJSON(): {
        id: string;
        seen: boolean;
        url: string | undefined;
        date: string | number;
        deleted: boolean;
        cluster: string | null;
        message: string;
    };
}
interface NotificationStoreOptions {
    max?: number;
}
export interface NotificationsState {
    notifications: NotificationIface[];
}
export declare const initialState: NotificationsState;
/**
 * Store the given notifications to localStorage.
 * @param notifications - The notifications to store.
 * @param options - Options for storing notifications.
 */
declare function storeNotifications(notifications: Notification[] | NotificationIface[], options?: NotificationStoreOptions): NotificationIface[];
/**
 * @returns An array of NotificationIface objects from localStorage.
 */
export declare function loadNotifications(): NotificationIface[];
declare const notificationsSlice: import("@reduxjs/toolkit").Slice<NotificationsState, {
    /**
     * Set notifications. Overwrites current notifications with new notifications.
     */
    setNotifications(state: import("immer").WritableDraft<NotificationsState>, action: PayloadAction<Notification[] | NotificationIface[] | NotificationIface>): import("immer").WritableDraft<NotificationsState>;
    /**
     * Update existing notifications with new notifications data.
     */
    updateNotifications(state: import("immer").WritableDraft<NotificationsState>, action: PayloadAction<NotificationIface[] | NotificationIface>): {
        notifications: NotificationIface[];
    };
}, "notifications", "notifications", import("@reduxjs/toolkit").SliceSelectors<NotificationsState>>;
export { notificationsSlice, defaultMaxNotificationsStored, storeNotifications };
export declare const setNotifications: import("@reduxjs/toolkit").ActionCreatorWithPayload<Notification[] | NotificationIface | NotificationIface[], "notifications/setNotifications">, updateNotifications: import("@reduxjs/toolkit").ActionCreatorWithPayload<NotificationIface | NotificationIface[], "notifications/updateNotifications">;
declare const _default: import("redux").Reducer<NotificationsState>;
export default _default;
