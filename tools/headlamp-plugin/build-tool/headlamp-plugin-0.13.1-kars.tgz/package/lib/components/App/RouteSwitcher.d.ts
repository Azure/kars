import React from 'react';
export default function RouteSwitcher(props: {
    requiresToken: () => boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function PreviousRouteProvider({ children }: React.PropsWithChildren<{}>): import("react/jsx-runtime").JSX.Element;
export declare function useHasPreviousRoute(): boolean;
