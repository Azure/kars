import { PluginInfo } from '../../../plugin/pluginsSlice';
export default function PluginSettingsDetails(): import("react/jsx-runtime").JSX.Element;
/**
 * Represents the properties expected by the PluginSettingsDetails component.
 *
 * @property {Object} [config] - Optional configuration settings for the plugin. This is an object that contains current configuration of the plugin.
 * @property {PluginInfo} plugin - Information about the plugin.
 * @property {(data: { [key: string]: any }) => void} [onSave] - Optional callback function that is called when the settings are saved. The function receives an object representing the updated configuration settings for the plugin.
 * @property {() => void} onDelete - Callback function that is called when the plugin is requested to be deleted. This function does not take any parameters and does not return anything.
 *
 * @see PluginInfo - Refer to the PluginInfo documentation for details on what this object should contain.
 */
export interface PluginSettingsDetailsPureProps {
    config?: {
        [key: string]: any;
    };
    plugin: PluginInfo;
    onSave?: (data: {
        [key: string]: any;
    }) => void;
    onDelete: () => void;
}
export declare function PluginSettingsDetailsPure(props: PluginSettingsDetailsPureProps): import("react/jsx-runtime").JSX.Element;
