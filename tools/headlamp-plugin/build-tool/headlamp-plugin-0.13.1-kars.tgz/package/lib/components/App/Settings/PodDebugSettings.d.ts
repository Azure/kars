/**
 * Props for PodDebugSettings.
 *
 * @property {string} cluster - Cluster name for debug settings
 */
interface SettingsProps {
    cluster: string;
}
/**
 * Settings component for pod debugging with ephemeral containers.
 *
 * Allows enabling/disabling debugging and configuring the default debug image per cluster.
 * Settings persist to localStorage and take effect immediately.
 *
 * @param props - Cluster name
 * @returns Settings section with debug controls
 */
export default function PodDebugSettings(props: SettingsProps): import("react/jsx-runtime").JSX.Element;
export {};
