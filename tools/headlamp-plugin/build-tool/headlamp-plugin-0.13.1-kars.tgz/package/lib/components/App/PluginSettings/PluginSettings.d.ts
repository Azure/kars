import { PluginInfo } from '../../../plugin/pluginsSlice';
/**
 * Interface of the component's props structure.
 *
 * plugins: will consist of an array of plugin data objects
 *
 * @see PluginInfo
 *
 * onSave: function that will handle the named plugins data array
 */
export interface PluginSettingsPureProps {
    plugins: PluginInfo[];
    onSave: (plugins: PluginInfo[]) => void;
    saveAlwaysEnable?: boolean;
}
/** PluginSettingsProp intentially left empty to remain malleable */
export interface PluginSettingsProps {
}
/** PluginSettingsPure is the main component to where we render the plugin data. */
export declare function PluginSettingsPure(props: PluginSettingsPureProps): import("react/jsx-runtime").JSX.Element;
/** Container function for the PluginSettingsPure, onSave prop returns plugins */
export default function PluginSettings(): import("react/jsx-runtime").JSX.Element;
