export declare function isValidNamespaceFormat(namespace: string): boolean;
export declare function isValidClusterNameFormat(name: string): boolean;
