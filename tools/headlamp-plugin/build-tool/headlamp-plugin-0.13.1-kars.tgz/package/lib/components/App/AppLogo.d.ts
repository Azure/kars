import { Theme } from '@mui/material/styles';
import { SxProps } from '@mui/system';
import React, { ReactElement } from 'react';
export interface AppLogoProps {
    /** The size of the logo. 'small' for in mobile view, and 'large' for tablet and desktop sizes. By default the 'large' is used. */
    logoType?: 'small' | 'large';
    /** User selected theme. By default it checks which is is active. */
    themeName?: string;
    /** A class to use on your SVG. */
    className?: string;
    /** SxProps to use on your SVG. */
    sx?: SxProps<Theme>;
    [key: string]: any;
}
export type AppLogoType = React.ComponentType<AppLogoProps> | ReactElement | typeof React.Component | null;
export default function OriginalAppLogo(props: AppLogoProps): import("react/jsx-runtime").JSX.Element;
export declare function AppLogo(props: AppLogoProps): import("react/jsx-runtime").JSX.Element;
