export default function SettingsButton(props: {
    onClickExtra?: () => void;
}): import("react/jsx-runtime").JSX.Element | null;
