import { useClustersConf } from '../../../lib/k8s';
/**
 * Gets the names of the clusters from the clusters configuration.
 * If the cluster has a custom name, it will be used instead of the default name.
 * The clusters are sorted by their names.
 *
 * @returns An array of name sorted clusters.
 */
export declare function getCustomClusterNames(clusters: ReturnType<typeof useClustersConf>): {
    name: any;
    useToken?: boolean;
    auth_type: string;
}[];
