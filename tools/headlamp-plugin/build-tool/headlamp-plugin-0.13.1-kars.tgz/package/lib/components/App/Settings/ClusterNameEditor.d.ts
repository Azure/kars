import React from 'react';
import { ClusterSettings } from '../../../helpers/clusterSettings';
import { Cluster } from '../../../lib/k8s/cluster';
interface ClusterNameEditorProps {
    cluster: string;
    clusterConf: {
        [clusterName: string]: Cluster;
    } | null;
    clusterSettings: ClusterSettings | null;
    setClusterSettings: React.Dispatch<React.SetStateAction<ClusterSettings | null>>;
}
export declare function ClusterNameEditor({ cluster, clusterConf, clusterSettings, setClusterSettings, }: ClusterNameEditorProps): import("react/jsx-runtime").JSX.Element;
export {};
