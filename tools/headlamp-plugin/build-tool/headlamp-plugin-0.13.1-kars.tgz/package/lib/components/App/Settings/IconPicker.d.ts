export declare const PRESET_ICONS: {
    name: string;
    value: string;
}[];
interface IconPickerProps {
    open: boolean;
    currentIcon: string;
    onClose: () => void;
    onSelectIcon: (icon: string) => void;
}
export default function IconPicker({ open, currentIcon, onClose, onSelectIcon }: IconPickerProps): import("react/jsx-runtime").JSX.Element;
export {};
