export declare const useSettings: (settingName?: string) => any;
