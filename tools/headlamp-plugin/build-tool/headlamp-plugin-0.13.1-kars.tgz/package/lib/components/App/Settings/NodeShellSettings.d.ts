/**
 * Props for the Settings component.
 * @interface SettingsProps
 * @property {Object.<string, {isEnabled?: boolean, namespace?: string, image?: string}>} data - Configuration data for each cluster
 * @property {Function} onDataChange - Callback function when data changes
 */
interface SettingsProps {
    cluster: string;
}
export default function NodeShellSettings(props: SettingsProps): import("react/jsx-runtime").JSX.Element;
export {};
