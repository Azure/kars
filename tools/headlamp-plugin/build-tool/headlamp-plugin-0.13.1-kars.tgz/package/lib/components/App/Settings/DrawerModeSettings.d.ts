export default function DrawerModeSettings(): import("react/jsx-runtime").JSX.Element;
