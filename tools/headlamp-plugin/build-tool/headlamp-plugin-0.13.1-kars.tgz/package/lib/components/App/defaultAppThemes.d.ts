import { AppTheme } from '../../lib/AppTheme';
export declare const darkTheme: AppTheme;
export declare const lightTheme: AppTheme;
export declare const lightsOutTheme: AppTheme;
export declare const monochromeLightTheme: AppTheme;
declare const defaultAppThemes: AppTheme[];
export default defaultAppThemes;
