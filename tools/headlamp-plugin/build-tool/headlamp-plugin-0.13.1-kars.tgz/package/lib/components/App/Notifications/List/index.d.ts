import NotificationList from './List';
export default NotificationList;
