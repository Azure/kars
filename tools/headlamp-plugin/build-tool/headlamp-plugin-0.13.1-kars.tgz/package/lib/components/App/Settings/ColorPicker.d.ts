export declare const PRESET_COLORS: {
    name: string;
    value: string;
}[];
interface ColorPickerProps {
    open: boolean;
    currentColor: string;
    onClose: () => void;
    onSelectColor: (color: string) => void;
    onError: (error: string) => void;
}
export default function ColorPicker({ open, currentColor, onClose, onSelectColor, onError, }: ColorPickerProps): import("react/jsx-runtime").JSX.Element;
export {};
