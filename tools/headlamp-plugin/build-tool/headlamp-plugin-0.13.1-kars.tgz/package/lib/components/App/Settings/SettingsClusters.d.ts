export default function SettingsClusters(): import("react/jsx-runtime").JSX.Element;
