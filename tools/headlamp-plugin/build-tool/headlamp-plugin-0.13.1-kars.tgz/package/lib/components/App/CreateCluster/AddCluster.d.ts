import { DialogProps } from '../../common/Dialog';
export default function AddCluster(props: DialogProps & {
    onChoice: () => void;
}): import("react/jsx-runtime").JSX.Element | null;
