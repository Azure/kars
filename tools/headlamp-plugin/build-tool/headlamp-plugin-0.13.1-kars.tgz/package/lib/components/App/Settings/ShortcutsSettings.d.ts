export declare function ShortcutsList(): import("react/jsx-runtime").JSX.Element;
export default function ShortcutsSettings(): import("react/jsx-runtime").JSX.Element;
