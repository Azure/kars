export default function NumRowsInput(props: {
    defaultValue: number[];
    nameLabelID?: string;
}): import("react/jsx-runtime").JSX.Element;
