import { ButtonBaseProps } from '@mui/material/ButtonBase';
export interface SquareButtonProps extends ButtonBaseProps {
    /** The icon to display for this button. */
    icon: string;
    /** The size of the icon. */
    iconSize?: number;
    /** The color of the icon. */
    iconColor?: string;
    /** The label to display for this button. */
    label: string;
    /** Whether this button has the primary color or not. */
    primary?: boolean;
}
export default function SquareButton(props: SquareButtonProps): import("react/jsx-runtime").JSX.Element;
