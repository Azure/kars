export default function SettingsCluster(): import("react/jsx-runtime").JSX.Element;
