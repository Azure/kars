/**
 * Runs a shell command and returns an object that mimics the interface of a ChildProcess object returned by Node's spawn function.
 *
 * This function is intended to be used only when Headlamp is in app mode.
 *
 * @see handleRunCommand in app/electron/main.ts
 *
 * This function uses the desktopApi.send and desktopApi.receive methods to communicate with the main process.
 * @param command - The command to run.
 * @param args - An array of arguments to pass to the command.
 * @param options - Additional options for the command.
 * @param permissionSecrets - Internal use. A record of permission secrets that may be required for the command.
 * @param desktopApiSend - Internal use. The function to send data to the main process.
 * @param desktopApiReceive - Internal use. The function to receive data from the main process.
 * @returns An object with `stdout`, `stderr`, and `on` properties. You can listen for 'data' events on `stdout` and `stderr`, and 'exit' events with `on`.
 * @example
 *
 * How it can be used in a plugin:
 * ```ts
 *   declare const pluginRunCommand: typeof runCommand;
 *   const minikube = pluginRunCommand('minikube', ['status'], {});
 *
 *   minikube.stdout.on('data', (data) => {
 *     console.log('stdout:', data);
 *   });
 *   minikube.stderr.on('data', (data) => {
 *     console.log('stderr:', data);
 *   });
 *   minikube.on('exit', (code) => {
 *     console.log('exit code:', code);
 *   });
 * ```
 */
export declare function runCommand(command: 'minikube' | 'az' | 'scriptjs', args: string[], options: {}, permissionSecrets?: Record<string, number>, desktopApiSend?: (channel: string, data: {
    id: string;
    command: string;
    args: string[];
    options: {};
    permissionSecrets: Record<string, number>;
}) => void, desktopApiReceive?: (channel: string, listener: (cmdId: string, data: string | number) => void) => void): {
    stdout: {
        on: (event: string, listener: (chunk: any) => void) => void;
    };
    stderr: {
        on: (event: string, listener: (chunk: any) => void) => void;
    };
    on: (event: string, listener: (code: number | null) => void) => void;
};
