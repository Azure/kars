import { useClustersConf, useClustersVersion } from '../../../lib/k8s';
import { getCustomClusterNames } from './customClusterNames';
export interface ClusterTableProps {
    /** Some clusters have custom names. */
    customNameClusters: ReturnType<typeof getCustomClusterNames>;
    /** Versions for each cluster. */
    versions: ReturnType<typeof useClustersVersion>[0];
    /** Errors for each cluster. */
    errors: ReturnType<typeof useClustersVersion>[1];
    /** Clusters configuration. */
    clusters: ReturnType<typeof useClustersConf>;
    /** Warnings for each cluster. */
    warningLabels: {
        [cluster: string]: string;
    };
}
/**
 * ClusterTable component displays a table of clusters with their status, origin, and version.
 */
export default function ClusterTable({ customNameClusters, versions, errors, clusters, warningLabels, }: ClusterTableProps): import("react/jsx-runtime").JSX.Element;
