import React from 'react';
export interface ClusterSelectorProps {
    currentCluster?: string;
    clusters: string[];
}
declare const ClusterSelector: React.FC<ClusterSelectorProps>;
export default ClusterSelector;
