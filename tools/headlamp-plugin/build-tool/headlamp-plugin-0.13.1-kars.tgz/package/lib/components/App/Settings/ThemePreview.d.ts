import { AppTheme } from '../../../lib/AppTheme';
export declare function ThemePreview({ theme, size }: {
    theme: AppTheme;
    size?: number;
}): import("react/jsx-runtime").JSX.Element;
