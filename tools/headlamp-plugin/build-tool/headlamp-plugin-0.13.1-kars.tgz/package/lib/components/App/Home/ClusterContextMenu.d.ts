import { Cluster } from '../../../lib/k8s/cluster';
interface ClusterContextMenuProps {
    /** The cluster for the context menu to act on. */
    cluster: Cluster;
}
/**
 * ClusterContextMenu component displays a context menu for a given cluster.
 */
export default function ClusterContextMenu({ cluster }: ClusterContextMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
