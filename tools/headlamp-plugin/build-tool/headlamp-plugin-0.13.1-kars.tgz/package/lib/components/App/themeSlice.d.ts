import { PayloadAction } from '@reduxjs/toolkit';
import { AppTheme } from '../../lib/AppTheme';
import { AppLogoType } from './AppLogo';
export interface ThemeState {
    /**
     * The logo component to use for the app.
     */
    logo: AppLogoType;
    /**
     * The name of the active theme.
     */
    name: string;
    /** List of all custom App Themes */
    appThemes: AppTheme[];
}
export declare const initialState: ThemeState;
declare const themeSlice: import("@reduxjs/toolkit").Slice<ThemeState, {
    /**
     * Sets the logo component to use for the app.
     */
    setBrandingAppLogoComponent(state: import("immer").WritableDraft<ThemeState>, action: PayloadAction<AppLogoType>): void;
    /**
     * Sets the theme name of the application.
     */
    setTheme(state: import("immer").WritableDraft<ThemeState>, action: PayloadAction<string>): void;
    addCustomAppTheme(state: import("immer").WritableDraft<ThemeState>, action: PayloadAction<AppTheme>): void;
    /** Checks if the selected theme name doesn't exist anymore and sets a fallback */
    ensureValidThemeName(state: import("immer").WritableDraft<ThemeState>): void;
}, "theme", "theme", import("@reduxjs/toolkit").SliceSelectors<ThemeState>>;
export declare const useAppThemes: () => AppTheme[];
export declare const useCurrentAppTheme: () => AppTheme;
export declare const setBrandingAppLogoComponent: import("@reduxjs/toolkit").ActionCreatorWithPayload<AppLogoType, "theme/setBrandingAppLogoComponent">, setTheme: import("@reduxjs/toolkit").ActionCreatorWithPayload<string, "theme/setTheme">;
export { themeSlice };
declare const _default: import("redux").Reducer<ThemeState>;
export default _default;
