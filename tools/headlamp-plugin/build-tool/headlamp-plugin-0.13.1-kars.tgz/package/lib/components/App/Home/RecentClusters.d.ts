import { Cluster } from '../../../lib/k8s/cluster';
export interface RecentClustersProps {
    /** The clusters available. So if there's a record of recent clusters, it'll try to use
     * them only if they exist, otherwise it'll just use the first 3 of the ones passed here.
     */
    clusters: Cluster[];
    /** Callback for when a cluster button is clicked. The button's respective cluster is passed as a parameter. */
    onButtonClick: (cluster: Cluster) => void;
}
export default function RecentClusters(props: RecentClustersProps): import("react/jsx-runtime").JSX.Element;
