/** Allow selecting multiple clusters on home page. */
export declare const MULTI_HOME_ENABLED: true;
/** Show recent clusters on the home page */
export declare const ENABLE_RECENT_CLUSTERS: boolean;
