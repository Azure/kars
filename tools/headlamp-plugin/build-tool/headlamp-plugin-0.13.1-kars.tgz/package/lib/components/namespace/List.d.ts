export default function NamespacesList(): import("react/jsx-runtime").JSX.Element;
