export default function CreateNamespaceButton(): import("react/jsx-runtime").JSX.Element;
