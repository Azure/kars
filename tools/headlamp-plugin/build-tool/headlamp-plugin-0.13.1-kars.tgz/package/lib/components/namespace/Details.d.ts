import Namespace from '../../lib/k8s/namespace';
export default function NamespaceDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
export interface NamespacedLimitRangesSectionProps {
    resource: Namespace;
}
export declare function NamespacedLimitRangesSection(props: NamespacedLimitRangesSectionProps): import("react/jsx-runtime").JSX.Element;
export interface NamespacedResourceQuotasSectionProps {
    resource: Namespace;
}
export declare function NamespacedResourceQuotasSection(props: NamespacedResourceQuotasSectionProps): import("react/jsx-runtime").JSX.Element;
