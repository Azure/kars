export default function PDBList(): import("react/jsx-runtime").JSX.Element;
