export default function PriorityClassDetails(props: {
    name?: string;
    cluster?: string;
}): import("react/jsx-runtime").JSX.Element;
