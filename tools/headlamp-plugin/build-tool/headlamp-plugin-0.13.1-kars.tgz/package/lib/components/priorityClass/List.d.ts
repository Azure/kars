export default function PriorityClassList(): import("react/jsx-runtime").JSX.Element;
