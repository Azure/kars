export default function ReplicaSetList(): import("react/jsx-runtime").JSX.Element;
