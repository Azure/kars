import { SimpleTableProps } from './SimpleTable';
export default function InnerTable(props: SimpleTableProps): import("react/jsx-runtime").JSX.Element;
