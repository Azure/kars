import { KubeObject } from '../../lib/k8s/KubeObject';
export interface ObjectEventListProps {
    object: KubeObject;
}
export default function ObjectEventList(props: ObjectEventListProps): import("react/jsx-runtime").JSX.Element;
