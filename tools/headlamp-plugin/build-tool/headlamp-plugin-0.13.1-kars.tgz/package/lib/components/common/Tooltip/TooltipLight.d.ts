import { TooltipProps } from '@mui/material/Tooltip';
import { ReactNode } from 'react';
export interface TooltipLightProps extends Omit<TooltipProps, 'children'> {
    /**
     * If true, the tooltip will be interactive. Defaults to true.
     *
     * If a tooltip is interactive, it will close when the user hovers over the tooltip before the leaveDelay is expired.
     */
    interactive?: boolean;
    children: ReactNode;
}
export default function TooltipLight(props: TooltipLightProps): import("react/jsx-runtime").JSX.Element;
