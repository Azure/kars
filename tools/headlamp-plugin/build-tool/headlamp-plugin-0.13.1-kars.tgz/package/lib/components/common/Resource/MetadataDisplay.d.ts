import { Theme } from '@mui/material/styles';
import { KubeObject } from '../../../lib/k8s/KubeObject';
import { NameValueTableRow } from '../../common/SimpleTable';
type ExtraRowsFunc<T extends KubeObject> = (resource: T) => NameValueTableRow[] | null;
export declare const metadataStyles: (theme: Theme) => {
    color: string;
    backgroundColor: any;
    fontSize: string;
    wordBreak: string;
    paddingLeft: string;
    paddingRight: string;
    marginRight: string;
    overflow: string;
    whiteSpace: string;
    overflowWrap: string;
    textOverflow: string;
};
export interface MetadataDisplayProps<T extends KubeObject = KubeObject> {
    resource: T;
    extraRows?: ExtraRowsFunc<T> | NameValueTableRow[] | null;
}
export declare function MetadataDisplay<T extends KubeObject>(props: MetadataDisplayProps<T>): import("react/jsx-runtime").JSX.Element;
interface MetadataDictGridProps {
    dict: {
        [index: string]: string;
        [index: number]: string;
    };
    showKeys?: boolean;
    gridProps?: {
        [index: string]: any;
    };
}
export declare function MetadataDictGrid(props: MetadataDictGridProps): import("react/jsx-runtime").JSX.Element;
export {};
