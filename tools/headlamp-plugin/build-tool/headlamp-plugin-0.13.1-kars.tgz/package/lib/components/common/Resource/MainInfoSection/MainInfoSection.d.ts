import React from 'react';
import { useLocation } from 'react-router-dom';
import { KubeObject } from '../../../../lib/k8s/KubeObject';
import { HeaderAction } from '../../../../redux/actionButtonsSlice';
import { HeaderStyle } from '../../../common/SectionHeader';
import { NameValueTableRow } from '../../../common/SimpleTable';
export interface MainInfoSectionProps<T extends KubeObject = KubeObject> {
    resource: T | null;
    headerSection?: ((resource: T | null) => React.ReactNode) | React.ReactNode;
    title?: string;
    extraInfo?: ((resource: T | null) => NameValueTableRow[] | null) | NameValueTableRow[] | null;
    actions?: ((resource: T | null) => React.ReactNode[] | HeaderAction[] | null) | React.ReactNode[] | null | HeaderAction[];
    headerStyle?: HeaderStyle;
    noDefaultActions?: boolean;
    /** The route or location to go to. If it's an empty string, then the "browser back" function is used. If null, no back button will be shown. */
    backLink?: string | ReturnType<typeof useLocation> | null;
    error?: string | Error | null;
}
export declare function MainInfoSection<T extends KubeObject>(props: MainInfoSectionProps<T>): import("react/jsx-runtime").JSX.Element;
