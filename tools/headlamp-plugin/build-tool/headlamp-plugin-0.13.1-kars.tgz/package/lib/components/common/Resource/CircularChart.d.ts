import '../../../i18n/config';
import { KubeMetrics } from '../../../lib/k8s/cluster';
import Node from '../../../lib/k8s/node';
import Pod from '../../../lib/k8s/pod';
import { PercentageCircleProps } from '../Chart';
export interface CircularChartProps extends Omit<PercentageCircleProps, 'data'> {
    /** Items to display in the chart (should have a corresponding value in @param itemsMetrics) */
    items: Node[] | Pod[] | null;
    /** Metrics to display in the chart (for items in @param items) */
    itemsMetrics: KubeMetrics[] | null;
    /** Whether no metrics are available. If true, then instead of a chart, a message will be displayed */
    noMetrics?: boolean;
    /** Function to get the "used" value for the metrics in question */
    resourceUsedGetter?: (node: KubeMetrics) => number;
    /** Function to get the "available" value for the metrics in question */
    resourceAvailableGetter?: (node: Node | Pod) => number;
    /** Function to create a legend for the data */
    getLegend?: (used: number, available: number) => string;
    /** Tooltip to display when hovering over the chart */
    tooltip?: string | null;
}
export declare function CircularChart(props: CircularChartProps): import("react/jsx-runtime").JSX.Element;
export default CircularChart;
