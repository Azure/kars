import '@xterm/xterm/css/xterm.css';
import { DialogProps } from '@mui/material/Dialog';
import Pod from '../../lib/k8s/pod';
interface TerminalProps extends DialogProps {
    item: Pod;
    isAttach?: boolean;
    /** Don't render the terminal in the dialog */
    noDialog?: boolean;
    onClose?: () => void;
}
export default function Terminal(props: TerminalProps): import("react/jsx-runtime").JSX.Element;
export {};
