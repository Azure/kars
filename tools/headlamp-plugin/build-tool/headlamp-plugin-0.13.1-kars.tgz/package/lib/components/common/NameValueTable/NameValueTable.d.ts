import { GridProps } from '@mui/material/Grid';
import { ReactNode } from 'react';
export interface NameValueTableRow {
    /** The name (key) for this row */
    name: ReactNode;
    /** The value for this row */
    value?: ReactNode;
    /** Whether this row should be hidden (can be a boolean or a function that will take the
     * @param value and return a boolean) */
    hide?: boolean | ((value: NameValueTableRow['value']) => boolean);
    /** Extra properties to pass to the value cell */
    valueCellProps?: GridProps;
    valueFullRow?: boolean;
    /** Whether to highlight the row (used for titles, separators, etc.). */
    withHighlightStyle?: boolean;
    /** The ID to use for the name element, useful for accessibility */
    nameID?: string;
}
export interface NameValueTableProps {
    rows: NameValueTableRow[];
    valueCellProps?: GridProps;
}
export default function NameValueTable(props: NameValueTableProps): import("react/jsx-runtime").JSX.Element;
