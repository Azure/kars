import { KubeObjectClass } from '../../lib/k8s/cluster';
export interface CreateResourceButtonProps {
    resourceClass: KubeObjectClass;
    resourceName?: string;
}
export declare function CreateResourceButton(props: CreateResourceButtonProps): import("react/jsx-runtime").JSX.Element | null;
