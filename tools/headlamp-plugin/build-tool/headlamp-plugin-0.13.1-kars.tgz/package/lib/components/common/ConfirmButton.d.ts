import Button, { ButtonProps } from '@mui/material/Button';
export interface ConfirmButtonProps extends ButtonProps {
    buttonComponent?: typeof Button;
    ariaLabel?: string;
    confirmTitle: string;
    confirmDescription: string;
    onConfirm: (...args: any[]) => void;
    [otherProps: string]: any;
}
export default function ConfirmButton(props: ConfirmButtonProps): import("react/jsx-runtime").JSX.Element;
