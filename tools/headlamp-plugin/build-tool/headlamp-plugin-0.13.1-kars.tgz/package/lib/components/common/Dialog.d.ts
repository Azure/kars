import { DialogProps as MuiDialogProps } from '@mui/material/Dialog';
import { DialogTitleProps } from '@mui/material/DialogTitle';
import React from 'react';
export { ConfirmDialog } from './ConfirmDialog';
export type { ConfirmDialogProps } from './ConfirmDialog';
export interface OurDialogTitleProps extends DialogTitleProps {
    /** true if you want the title focused in the dialog */
    focusTitle?: boolean;
    buttons?: React.ReactNode[];
    disableTypography?: boolean;
}
/**
 * This is like Material-ui DialogTitle but fixes some a11y issues.
 *
 * First, it needs a h1 because other page content is aria-diable=true'd
 *
 * Additionally, it also focuses the title text as that is where
 * reading can begin.
 */
export declare function DialogTitle(props: OurDialogTitleProps): import("react/jsx-runtime").JSX.Element | null;
export interface OurDialogProps {
    withFullScreen?: boolean;
    onFullScreenToggled?: (isFullScreen: boolean) => void;
    titleProps?: OurDialogTitleProps;
}
export type DialogProps = OurDialogProps & MuiDialogProps;
export declare function Dialog(props: DialogProps): import("react/jsx-runtime").JSX.Element;
