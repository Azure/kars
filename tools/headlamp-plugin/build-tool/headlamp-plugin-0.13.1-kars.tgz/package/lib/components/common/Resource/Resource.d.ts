import { GridProps } from '@mui/material/Grid';
import { InputProps } from '@mui/material/Input';
import { BaseTextFieldProps } from '@mui/material/TextField';
import React, { PropsWithChildren, ReactNode } from 'react';
import { ApiError } from '../../../lib/k8s/api/v2/ApiError';
import { KubeContainer } from '../../../lib/k8s/cluster';
import { KubeEvent } from '../../../lib/k8s/event';
import { KubeObject } from '../../../lib/k8s/KubeObject';
import { KubeObjectInterface } from '../../../lib/k8s/KubeObject';
import { KubeObjectClass } from '../../../lib/k8s/KubeObject';
import { KubePod, KubeVolume } from '../../../lib/k8s/pod';
import { RouteURLProps } from '../../../lib/router';
import { DetailsViewSection } from '../../DetailsViewSection/detailsViewSectionSlice';
import { PodListProps } from '../../pod/List';
import { LinkProps } from '../Link';
import { MainInfoSection, MainInfoSectionProps } from './MainInfoSection/MainInfoSection';
export { MainInfoSection };
export type { MainInfoSectionProps };
export interface ResourceLinkProps extends Omit<LinkProps, 'routeName' | 'params'> {
    name?: string;
    routeName?: string;
    routeParams?: RouteURLProps;
    resource: KubeObject<any>;
}
export declare function ResourceLink(props: ResourceLinkProps): import("react/jsx-runtime").JSX.Element;
export interface DetailsGridProps<T extends KubeObjectClass> extends PropsWithChildren<Omit<MainInfoSectionProps<InstanceType<T>>, 'resource'>> {
    /** Resource type to fetch (from the ResourceClasses). */
    resourceType: T;
    /** Name of the resource. */
    name: string;
    /** Namespace of the resource. If not provided, it's assumed the resource is not namespaced. */
    namespace?: string;
    /** Name of the cluster of the resource */
    cluster?: string;
    /** Sections to show in the details grid (besides the default ones). */
    extraSections?: ((item: InstanceType<T>) => boolean | DetailsViewSection[] | ReactNode[]) | boolean | DetailsViewSection[];
    /** @deprecated Use extraSections instead. */
    sectionsFunc?: (item: InstanceType<T>) => React.ReactNode | DetailsViewSection[];
    /** If true, will show the events section. */
    withEvents?: boolean;
    /** Called when the resource instance is created/updated, or there is an error. */
    onResourceUpdate?: (resource: InstanceType<T>, error: ApiError) => void;
}
/** Renders the different parts that constibute an actual resource's details view.
 * Those are: the back link, the header, the main info section, the extra sections, and the events section.
 */
export declare function DetailsGrid<T extends KubeObjectClass>(props: DetailsGridProps<T>): import("react/jsx-runtime").JSX.Element;
export interface PageGridProps extends GridProps {
    sections?: React.ReactNode;
    children?: React.ReactNode;
}
export declare function PageGrid(props: PageGridProps): import("react/jsx-runtime").JSX.Element;
export interface SectionGridProps {
    items: React.ReactNode[];
    useDivider?: boolean;
}
export declare function SectionGrid(props: SectionGridProps): import("react/jsx-runtime").JSX.Element;
export interface DataFieldProps extends BaseTextFieldProps {
    disableLabel?: boolean;
    onSave?: (newValue: string) => void;
    onChange?: (newValue: string) => void;
}
export declare function DataField(props: DataFieldProps): import("react/jsx-runtime").JSX.Element;
export interface SecretFieldProps extends InputProps {
    nameID?: string;
}
export declare function SecretField(props: SecretFieldProps): import("react/jsx-runtime").JSX.Element;
export interface ConditionsTableProps {
    resource: KubeObjectInterface | KubeEvent | null;
    showLastUpdate?: boolean;
}
export declare function ConditionsTable(props: ConditionsTableProps): import("react/jsx-runtime").JSX.Element;
export interface VolumeMountsProps {
    mounts?: {
        mountPath: string;
        name: string;
        readOnly: boolean;
    }[];
}
export declare function VolumeMounts(props: VolumeMountsProps): import("react/jsx-runtime").JSX.Element | null;
export declare function LivenessProbes(props: {
    liveness: KubeContainer['livenessProbe'];
}): import("react/jsx-runtime").JSX.Element;
/** @deprecated Please use `ContainerInfoKubeObjectProps` for better type safety */
export interface ContainerInfoLegacyProps {
    container: KubeContainer;
    resource: KubeObjectInterface | null;
    status?: Omit<KubePod['status']['KubeContainerStatus'], 'name'>;
}
export interface ContainerInfoKubeObjectProps {
    container: KubeContainer;
    resource: KubeObject | null;
    status?: Omit<KubePod['status']['KubeContainerStatus'], 'name'>;
}
export type ContainerInfoProps = ContainerInfoKubeObjectProps | ContainerInfoLegacyProps;
export declare function ContainerInfo(props: ContainerInfoProps): import("react/jsx-runtime").JSX.Element;
export interface OwnedPodsSectionProps {
    resource: KubeObject;
    hideColumns?: PodListProps['hideColumns'];
    /**
     * Hides the namespace selector
     */
    noSearch?: boolean;
}
export declare function OwnedPodsSection(props: OwnedPodsSectionProps): import("react/jsx-runtime").JSX.Element;
export declare function ContainersSection(props: {
    resource: KubeObjectInterface | null;
}): import("react/jsx-runtime").JSX.Element;
export declare function ConditionsSection(props: {
    resource: KubeObjectInterface | null;
}): import("react/jsx-runtime").JSX.Element | null;
export interface VolumeSectionProps {
    resource: KubeObjectInterface | null;
}
export interface VolumeRowsProps {
    volume: KubeVolume;
}
export interface PrintVolumeLinkProps {
    volumeName: string;
    volumeKind: string;
    volume: KubeVolume;
}
export interface VolumePrints {
    directPrint?: any[];
    yamlPrint?: any[];
}
export declare function VolumeSection(props: VolumeSectionProps): import("react/jsx-runtime").JSX.Element | null;
