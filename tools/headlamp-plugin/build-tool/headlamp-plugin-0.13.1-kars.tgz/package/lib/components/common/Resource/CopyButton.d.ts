import { ButtonStyle } from '../ActionButton';
interface CopyButtonProps {
    text?: string;
    buttonStyle?: ButtonStyle;
}
export default function CopyButton(props: CopyButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
