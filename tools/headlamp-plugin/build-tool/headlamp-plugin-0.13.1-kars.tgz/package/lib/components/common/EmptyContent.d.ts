import { TypographyProps } from '@mui/material/Typography';
import React from 'react';
type EmptyProps = React.PropsWithChildren<{
    color?: TypographyProps['color'];
}>;
export default function Empty({ color, children }: EmptyProps): import("react/jsx-runtime").JSX.Element;
export {};
