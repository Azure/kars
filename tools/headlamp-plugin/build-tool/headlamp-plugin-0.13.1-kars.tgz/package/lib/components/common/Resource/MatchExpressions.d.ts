import { LabelSelector } from '../../../lib/k8s/cluster';
export interface MatchExpressionsProps {
    matchLabels?: LabelSelector['matchLabels'];
    matchExpressions?: LabelSelector['matchExpressions'];
}
export declare function MatchExpressions(props: MatchExpressionsProps): import("react/jsx-runtime").JSX.Element;
