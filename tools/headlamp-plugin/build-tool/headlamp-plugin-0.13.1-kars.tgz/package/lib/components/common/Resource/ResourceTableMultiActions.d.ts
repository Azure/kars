import { MRT_TableInstance } from 'material-react-table';
export interface ResourceTableMultiActionsProps<RowItem extends Record<string, any>> {
    table: MRT_TableInstance<RowItem>;
}
export default function ResourceTableMultiActions<RowItem extends Record<string, any>>(props: ResourceTableMultiActionsProps<RowItem>): import("react/jsx-runtime").JSX.Element;
