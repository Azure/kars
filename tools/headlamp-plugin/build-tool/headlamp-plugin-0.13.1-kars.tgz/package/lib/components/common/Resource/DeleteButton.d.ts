import { KubeObject } from '../../../lib/k8s/KubeObject';
import { CallbackActionOptions } from '../../../redux/clusterActionSlice';
import { ButtonStyle } from '../ActionButton';
interface DeleteButtonProps {
    item?: KubeObject;
    options?: CallbackActionOptions;
    buttonStyle?: ButtonStyle;
    afterConfirm?: () => void;
}
export default function DeleteButton(props: DeleteButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
