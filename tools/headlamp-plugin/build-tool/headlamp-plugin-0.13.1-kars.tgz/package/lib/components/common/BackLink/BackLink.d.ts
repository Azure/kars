import { useLocation } from 'react-router-dom';
export interface BackLinkProps {
    /** The location to go back to. If not provided, the browser's history will be used. */
    to?: string | ReturnType<typeof useLocation>;
}
export default function BackLink(props: BackLinkProps): import("react/jsx-runtime").JSX.Element;
