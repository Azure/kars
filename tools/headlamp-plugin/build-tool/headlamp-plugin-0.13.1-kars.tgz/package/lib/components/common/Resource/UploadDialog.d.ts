import React from 'react';
interface UploadDialogProps {
    setUploadFiles: (value: boolean) => void;
    setCode: React.Dispatch<React.SetStateAction<{
        code: string;
        format: string;
    }>>;
}
export declare function UploadDialog(props: UploadDialogProps): import("react/jsx-runtime").JSX.Element;
export {};
