import DaemonSet from '../../../lib/k8s/daemonSet';
import Deployment from '../../../lib/k8s/deployment';
import { KubeObject } from '../../../lib/k8s/KubeObject';
import StatefulSet from '../../../lib/k8s/statefulSet';
import { ButtonStyle } from '../ActionButton';
export type RestartableResource = Deployment | StatefulSet | DaemonSet;
export declare function isRestartableResource(item: KubeObject): item is RestartableResource;
interface RestartButtonProps {
    item: KubeObject;
    buttonStyle?: ButtonStyle;
    afterConfirm?: () => void;
}
export declare function RestartButton(props: RestartButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
