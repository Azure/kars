import { Theme } from '@mui/material/styles';
import { SxProps } from '@mui/system';
import React from 'react';
type sortFunction = (arg1: any, arg2: any) => number;
type getterFunction = (arg: any) => any;
interface SimpleTableColumn {
    label: string;
    header?: React.ReactNode;
    gridTemplate?: number | string;
    cellProps?: {
        [propName: string]: any;
    };
    sort?: sortFunction | getterFunction | boolean;
}
export interface SimpleTableDatumColumn extends SimpleTableColumn {
    datum: string;
}
export interface SimpleTableGetterColumn extends SimpleTableColumn {
    getter: (...args: any[]) => void;
}
export interface SimpleTableProps {
    columns: (SimpleTableGetterColumn | SimpleTableDatumColumn)[];
    data: {
        [dataProp: string]: any;
        [dataProp: number]: any;
    }[] | null | undefined;
    filterFunction?: ((...args: any[]) => boolean) | null;
    rowsPerPage?: number[];
    emptyMessage?: string;
    errorMessage?: string | null;
    defaultSortingColumn?: number;
    noTableHeader?: boolean;
    /** Whether to reflect the page/perPage properties in the URL.
     * If assigned to a string, it will be the prefix for the page/perPage parameters.
     * If true or '', it'll reflect the parameters without a prefix.
     * By default, no parameters are reflected in the URL. */
    reflectInURL?: string | boolean;
    /** The page number to show by default (by default it's the first page). */
    page?: number;
    /** Whether to show the pagination component */
    showPagination?: boolean;
    /** The style for the table */
    className?: string;
    sx?: SxProps<Theme>;
}
export default function SimpleTable(props: SimpleTableProps): import("react/jsx-runtime").JSX.Element;
export * from './NameValueTable';
