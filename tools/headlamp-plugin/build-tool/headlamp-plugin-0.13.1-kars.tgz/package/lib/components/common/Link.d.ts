import React from 'react';
import type { KubeObject } from '../../lib/k8s/KubeObject';
import type { RouteURLProps } from '../../lib/router/createRouteURL';
export interface LinkBaseProps {
    /** The tooltip to display on hover. If true, the tooltip will be the link's text. */
    tooltip?: string | boolean;
}
export interface LinkProps extends LinkBaseProps {
    /** A key in the default routes object (given by router.tsx's getDefaultRoutes). */
    routeName: string;
    /** An object with corresponding params for the pattern to use. */
    params?: RouteURLProps;
    /** A string representation of query parameters. */
    search?: string;
    /** Cluster name of the resource. Set this parameter to not override selected clusters param */
    activeCluster?: string;
    /** State to persist to the location. */
    state?: {
        [prop: string]: any;
    };
}
export interface LinkObjectProps extends LinkBaseProps {
    kubeObject?: KubeObject | null;
    [prop: string]: any;
}
export default function Link(props: React.PropsWithChildren<LinkProps | LinkObjectProps>): import("react/jsx-runtime").JSX.Element;
