import { DialogProps as MuiDialogProps } from '@mui/material/Dialog';
import { ReactNode } from 'react';
export interface ConfirmDialogProps extends MuiDialogProps {
    title: string;
    description: ReactNode;
    onConfirm: () => void;
    handleClose: () => void;
    cancelLabel?: string;
    confirmLabel?: string;
    /**
     * Disables the Cancel button, defaults to false
     */
    hideCancelButton?: boolean;
}
export declare function ConfirmDialog(props: ConfirmDialogProps): import("react/jsx-runtime").JSX.Element;
export default ConfirmDialog;
