import Deployment from '../../../lib/k8s/deployment';
import ReplicaSet from '../../../lib/k8s/replicaSet';
import StatefulSet from '../../../lib/k8s/statefulSet';
import { CallbackActionOptions } from '../../../redux/clusterActionSlice';
import { ButtonStyle } from '../ActionButton';
interface ScaleButtonProps {
    item: (Deployment | StatefulSet | ReplicaSet) & {
        _class?: () => {
            isScalable?: boolean;
        };
    };
    buttonStyle?: ButtonStyle;
    options?: CallbackActionOptions;
}
export default function ScaleButton(props: ScaleButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
