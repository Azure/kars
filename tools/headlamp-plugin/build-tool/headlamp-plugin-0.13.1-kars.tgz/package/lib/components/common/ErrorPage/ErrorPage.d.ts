import React from 'react';
export interface ErrorComponentProps {
    /** The main title to display. By default it is: "Uh-oh! Something went wrong." */
    title?: React.ReactNode;
    /** The message to display. By default it is: "Head back <a href="..."> home</a>." */
    message?: React.ReactNode;
    /** The graphic or element to display as a main graphic. If used as a string, it will be
     * used as the source for displaying an image. By default it is "headlamp-broken.svg". */
    graphic?: React.ReactNode;
    /** Whether to use Typography or not. By default it is true. */
    withTypography?: boolean;
    /** The error object to display. */
    error?: Error;
}
export default function ErrorComponent(props: ErrorComponentProps): import("react/jsx-runtime").JSX.Element;
