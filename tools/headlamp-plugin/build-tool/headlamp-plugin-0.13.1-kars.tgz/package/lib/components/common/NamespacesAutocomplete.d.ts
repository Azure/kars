import React from 'react';
export interface PureNamespacesAutocompleteProps {
    namespaceNames: string[];
    onChange: (event: React.ChangeEvent<{}>, newValue: string[]) => void;
    filter: {
        namespaces: Set<string>;
    };
}
export declare function PureNamespacesAutocomplete({ namespaceNames, onChange: onChangeFromProps, filter, }: PureNamespacesAutocompleteProps): import("react/jsx-runtime").JSX.Element;
export declare function NamespacesAutocomplete(): import("react/jsx-runtime").JSX.Element;
