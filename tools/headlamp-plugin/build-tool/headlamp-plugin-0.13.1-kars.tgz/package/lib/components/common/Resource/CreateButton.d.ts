interface CreateButtonProps {
    isNarrow?: boolean;
}
export default function CreateButton(props: CreateButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
