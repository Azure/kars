export interface TimezoneSelectorProps {
    initialTimezone?: string;
    onChange: (timezone: string) => void;
    /** The custom ID to be used when this component is inside NameValueTable for ARIA labelledby */
    nameLabelID?: string;
}
export default function TimezoneSelect(props: TimezoneSelectorProps): import("react/jsx-runtime").JSX.Element;
