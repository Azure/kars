import { SearchAddon } from '@xterm/addon-search';
import { Terminal as XTerminal } from '@xterm/xterm';
import React, { ReactNode } from 'react';
import { DialogProps } from './Dialog';
export interface LogViewerProps extends DialogProps {
    logs: string[];
    title?: string;
    downloadName?: string;
    onClose: () => void;
    topActions?: ReactNode[];
    open: boolean;
    xtermRef?: React.MutableRefObject<XTerminal | null>;
    /**
     * @description This is a callback function that is called when the user clicks on the reconnect button.
     * @returns void
     */
    handleReconnect?: () => void;
    /**
     * @description This is a boolean that determines whether the reconnect button should be shown or not.
     */
    showReconnectButton?: boolean;
    /** Don't render in the dialog */
    noDialog?: boolean;
}
export declare function LogViewer(props: LogViewerProps): import("react/jsx-runtime").JSX.Element;
interface SearchPopoverProps {
    searchAddonRef: {
        current: SearchAddon | null;
    };
    open: boolean;
    onClose: () => void;
}
export declare function SearchPopover(props: SearchPopoverProps): import("react/jsx-runtime").JSX.Element;
export {};
