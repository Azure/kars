import { KubeObject } from '../../../lib/k8s/KubeObject';
interface LogsButtonProps {
    item: KubeObject | null;
}
export declare function LogsButton({ item }: LogsButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
