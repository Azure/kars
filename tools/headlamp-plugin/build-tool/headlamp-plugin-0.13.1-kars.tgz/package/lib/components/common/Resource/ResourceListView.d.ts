import { PropsWithChildren, ReactElement, ReactNode } from 'react';
import { KubeObject, KubeObjectClass } from '../../../lib/k8s/KubeObject';
import { BackLinkProps } from '../BackLink';
import { SectionFilterHeaderProps } from '../SectionFilterHeader';
import { ResourceTableProps } from './ResourceTable';
export interface ResourceListViewProps<Item extends KubeObject> extends PropsWithChildren<Omit<ResourceTableProps<Item>, 'data'>> {
    title: ReactNode;
    backLink?: BackLinkProps['to'] | boolean;
    headerProps?: Omit<SectionFilterHeaderProps, 'title'>;
    data: Item[] | null;
}
export interface ResourceListViewWithResourceClassProps<ItemClass extends KubeObjectClass> extends PropsWithChildren<Omit<ResourceTableProps<InstanceType<ItemClass>>, 'data'>> {
    title: ReactNode;
    backLink?: BackLinkProps['to'] | boolean;
    headerProps?: Omit<SectionFilterHeaderProps, 'title'>;
    resourceClass: ItemClass;
}
export default function ResourceListView<ItemClass extends KubeObjectClass>(props: ResourceListViewWithResourceClassProps<ItemClass>): ReactElement;
export default function ResourceListView<Item extends KubeObject<any>>(props: ResourceListViewProps<Item>): ReactElement;
