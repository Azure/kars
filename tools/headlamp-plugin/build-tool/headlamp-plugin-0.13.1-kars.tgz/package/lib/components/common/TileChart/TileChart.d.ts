import '../../../i18n/config';
import { PercentageCircleProps } from '../Chart';
export interface TileChartProps extends Omit<PercentageCircleProps, 'data'> {
    /** Tooltip to display when hovering over the info icon. This info icon is only shown if this property is passed. */
    infoTooltip?: string | null;
    /** Data to display for the chart. */
    data?: PercentageCircleProps['data'] | null;
}
export declare function TileChart(props: TileChartProps): import("react/jsx-runtime").JSX.Element;
export default TileChart;
