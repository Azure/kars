export interface ShowHideLabelProps {
    children: string;
    show?: boolean;
    labelId?: string;
    maxChars?: number;
}
export default function ShowHideLabel(props: ShowHideLabelProps): import("react/jsx-runtime").JSX.Element | null;
