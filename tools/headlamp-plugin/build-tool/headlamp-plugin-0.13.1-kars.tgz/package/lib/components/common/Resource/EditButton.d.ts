import { KubeObject } from '../../../lib/k8s/KubeObject';
import { CallbackActionOptions } from '../../../redux/clusterActionSlice';
import { ButtonStyle } from '../ActionButton';
interface EditButtonProps {
    item: KubeObject;
    options?: CallbackActionOptions;
    buttonStyle?: ButtonStyle;
    afterConfirm?: () => void;
}
export default function EditButton(props: EditButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
