import React from 'react';
import { SectionHeaderProps } from './SectionHeader';
export interface SectionFilterHeaderProps extends SectionHeaderProps {
    noNamespaceFilter?: boolean;
    /**
     * @deprecated
     * This prop has no effect, search has moved inside the Table component.
     * To disable namespace filter use `noNamespaceFilter`
     */
    noSearch?: boolean;
    preRenderFromFilterActions?: React.ReactNode[];
}
export default function SectionFilterHeader(props: SectionFilterHeaderProps): import("react/jsx-runtime").JSX.Element;
