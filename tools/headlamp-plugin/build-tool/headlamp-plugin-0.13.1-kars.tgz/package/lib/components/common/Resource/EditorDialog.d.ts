import '../../../i18n/config';
import React from 'react';
import { KubeObjectInterface } from '../../../lib/k8s/KubeObject';
import { DialogProps } from '../Dialog';
type KubeObjectIsh = Partial<KubeObjectInterface>;
export interface EditorDialogProps extends DialogProps {
    /** The object(s) to edit, or null to make the dialog be in "loading mode". Pass it an empty object if no contents are to be shown when the dialog is first open. */
    item: KubeObjectIsh | object | object[] | string | null;
    /** Called when the dialog is closed. */
    onClose: () => void;
    /** Called by a component for when the user clicks the save button. When set to "default", internal save logic is applied. */
    onSave?: ((...args: any[]) => void) | 'default' | null;
    /** Called when the editor's contents change. */
    onEditorChanged?: ((newValue: string) => void) | null;
    /** The function to open the dialog. */
    setOpen?: (open: boolean) => void;
    allowToHideManagedFields?: boolean;
    /** The label to use for the save button. */
    saveLabel?: string;
    /** The error message to display. */
    errorMessage?: string;
    /** The dialog title. */
    title?: string;
    /** Extra optional actions. */
    actions?: React.ReactNode[];
    /** Don't render the editor in the dialog */
    noDialog?: boolean;
}
export default function EditorDialog(props: EditorDialogProps): import("react/jsx-runtime").JSX.Element | null;
export declare function ViewDialog(props: Omit<EditorDialogProps, 'onSave'>): import("react/jsx-runtime").JSX.Element;
export {};
