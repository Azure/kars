import { IconProps } from '@iconify/react';
import { SxProps, Theme } from '@mui/material/styles';
import { TypographyProps } from '@mui/material/Typography';
import React from 'react';
import { DateFormatOptions } from '../../lib/util';
export interface InfoLabelProps {
    name: string;
    value?: string | null;
}
export declare function InfoLabel(props: React.PropsWithChildren<InfoLabelProps>): import("react/jsx-runtime").JSX.Element;
export declare function NameLabel(props: React.PropsWithChildren<{}>): import("react/jsx-runtime").JSX.Element;
export declare function ValueLabel(props: React.PropsWithChildren<{}>): import("react/jsx-runtime").JSX.Element;
export interface StatusLabelProps {
    status: 'success' | 'warning' | 'error' | '';
    sx?: SxProps<Theme>;
    [otherProps: string]: any;
}
export declare const StatusLabel: React.ForwardRefExoticComponent<Omit<StatusLabelProps, "ref"> & React.RefAttributes<HTMLSpanElement>>;
export declare function makeStatusLabel(label: string, successStatusName: string): import("react/jsx-runtime").JSX.Element;
export interface HeaderLabelProps {
    label: string;
    value: string;
    tooltip?: string | null;
}
export declare function HeaderLabel(props: HeaderLabelProps): import("react/jsx-runtime").JSX.Element;
export interface HoverInfoLabelProps {
    label: React.ReactNode;
    hoverInfo?: React.ReactNode;
    labelProps?: TypographyProps;
    icon?: IconProps['icon'];
    iconProps?: Omit<IconProps, 'icon'>;
    iconPosition?: 'start' | 'end';
}
export declare function HoverInfoLabel(props: HoverInfoLabelProps): import("react/jsx-runtime").JSX.Element;
export interface DateLabelProps {
    date: number | string | Date;
    format?: DateFormatOptions;
    iconProps?: Omit<IconProps, 'icon'>;
}
export declare function DateLabel(props: DateLabelProps): import("react/jsx-runtime").JSX.Element;
