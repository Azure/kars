import { CircularProgressProps } from '@mui/material/CircularProgress';
export interface LoaderProps extends CircularProgressProps {
    noContainer?: boolean;
    title: string;
}
export default function Loader(props: LoaderProps): import("react/jsx-runtime").JSX.Element;
