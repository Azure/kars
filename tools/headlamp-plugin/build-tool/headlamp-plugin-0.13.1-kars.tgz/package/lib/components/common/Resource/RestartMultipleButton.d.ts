import { ButtonStyle } from '../ActionButton';
import { RestartableResource } from './RestartButton';
interface RestartMultipleButtonProps {
    items: RestartableResource[];
    buttonStyle?: ButtonStyle;
    afterConfirm?: () => void;
}
export default function RestartMultipleButton(props: RestartMultipleButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
