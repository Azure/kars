import { KubeObject } from '../../../lib/k8s/KubeObject';
import { CallbackActionOptions } from '../../../redux/clusterActionSlice';
import { ButtonStyle } from '../ActionButton';
interface DeleteMultipleButtonProps {
    items?: KubeObject[];
    options?: CallbackActionOptions;
    buttonStyle?: ButtonStyle;
    afterConfirm?: () => void;
}
export default function DeleteMultipleButton(props: DeleteMultipleButtonProps): import("react/jsx-runtime").JSX.Element | null;
export {};
