import { ResourceTableColumn } from './ResourceTable';
interface ColumnsPopupProps<T> {
    columns: ResourceTableColumn<T>[];
    onToggleColumn: (cols: ResourceTableColumn<T>[]) => void;
    onClose: () => void;
    anchorEl: HTMLElement | null;
}
export default function ColumnsPopup<T>(props: ColumnsPopupProps<T>): import("react/jsx-runtime").JSX.Element;
export {};
