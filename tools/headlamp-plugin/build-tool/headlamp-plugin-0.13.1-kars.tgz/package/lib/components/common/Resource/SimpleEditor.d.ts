export interface SimpleEditorProps {
    /** Programming language. */
    language: string;
    /** The thing we are editing. */
    value: string | undefined;
    /** When things in the editor change. */
    onChange(value: string | undefined, ev: any): void;
}
/** A very basic code editor. */
declare function SimpleEditor({ language, value, onChange }: SimpleEditorProps): import("react/jsx-runtime").JSX.Element;
export default SimpleEditor;
