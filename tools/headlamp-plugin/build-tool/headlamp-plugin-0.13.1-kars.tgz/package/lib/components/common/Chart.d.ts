import { ReactNode } from 'react';
export interface ChartDataPoint {
    name: string;
    value: number;
    fill?: string;
}
export interface PercentageCircleProps {
    data: ChartDataPoint[];
    size?: number;
    dataKey?: string;
    label?: string | null;
    title?: ReactNode;
    legend?: ReactNode;
    total?: number;
    totalProps?: {
        [propName: string]: any;
    };
    thickness?: number;
}
export declare function PercentageCircle(props: PercentageCircleProps): import("react/jsx-runtime").JSX.Element;
export interface PercentageBarProps {
    data: ChartDataPoint[];
    total?: number;
    tooltipFunc?: ((data: any) => ReactNode) | null;
}
export declare function PercentageBar(props: PercentageBarProps): import("react/jsx-runtime").JSX.Element;
