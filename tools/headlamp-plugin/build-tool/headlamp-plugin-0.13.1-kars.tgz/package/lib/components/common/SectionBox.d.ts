import { BoxProps } from '@mui/material/Box';
import React from 'react';
import { BackLinkProps } from './BackLink';
import { SectionHeaderProps } from './SectionHeader';
export interface SectionBoxProps extends Omit<BoxProps, 'title'> {
    title?: React.ReactNode;
    subtitle?: React.ReactNode;
    headerProps?: Omit<SectionHeaderProps, 'title'>;
    outterBoxProps?: Omit<BoxProps, 'title'>;
    backLink?: BackLinkProps['to'] | boolean;
}
export declare function SectionBox(props: SectionBoxProps): import("react/jsx-runtime").JSX.Element;
export default SectionBox;
