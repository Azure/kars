import React from 'react';
export interface LabelListItemProps {
    labels?: React.ReactNode[];
}
export default function LabelListItem(props: LabelListItemProps): import("react/jsx-runtime").JSX.Element | null;
