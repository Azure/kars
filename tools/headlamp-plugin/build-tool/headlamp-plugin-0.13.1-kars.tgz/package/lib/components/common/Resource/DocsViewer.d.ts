export interface DocsViewerProps {
    docSpecs: any;
}
declare function DocsViewer(props: DocsViewerProps): import("react/jsx-runtime").JSX.Element;
export default DocsViewer;
