import React from 'react';
export type HeaderStyle = 'main' | 'subsection' | 'normal' | 'label';
export interface SectionHeaderProps {
    title: string | React.ReactNode;
    subtitle?: string | React.ReactNode;
    actions?: React.ReactNode[] | null;
    noPadding?: boolean;
    headerStyle?: HeaderStyle;
    titleSideActions?: React.ReactNode[];
}
export default function SectionHeader(props: SectionHeaderProps): import("react/jsx-runtime").JSX.Element;
