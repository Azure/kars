import { PayloadAction } from '@reduxjs/toolkit';
import { ResourceTableProps } from './ResourceTable';
export interface ResourceTableState {
    /**
     * List of table columns processors. Allowing the modification of what tables show.
     */
    tableColumnsProcessors: TableColumnsProcessor[];
}
export type TableColumnsProcessor = {
    /** Unique ID for this processor. */
    id: string;
    /** Function that will be called to process the columns.
     * @param args.id The table ID.
     * @param args.columns The current table columns.
     *
     * @returns The new table columns.
     */
    processor: <T>(args: {
        id: string;
        columns: ResourceTableProps<T>['columns'];
    }) => ResourceTableProps<T>['columns'];
};
declare const resourceTableSlice: import("@reduxjs/toolkit").Slice<ResourceTableState, {
    /**
     * Adds a table columns processor.
     */
    addResourceTableColumnsProcessor(state: import("immer").WritableDraft<ResourceTableState>, action: PayloadAction<TableColumnsProcessor | TableColumnsProcessor["processor"]>): void;
}, "resourceTable", "resourceTable", import("@reduxjs/toolkit").SliceSelectors<ResourceTableState>>;
export declare const addResourceTableColumnsProcessor: import("@reduxjs/toolkit").ActionCreatorWithPayload<TableColumnsProcessor | (<T>(args: {
    id: string;
    columns: ResourceTableProps<T>["columns"];
}) => ResourceTableProps<T>["columns"]), "resourceTable/addResourceTableColumnsProcessor">;
export { resourceTableSlice };
declare const _default: import("redux").Reducer<ResourceTableState>;
export default _default;
