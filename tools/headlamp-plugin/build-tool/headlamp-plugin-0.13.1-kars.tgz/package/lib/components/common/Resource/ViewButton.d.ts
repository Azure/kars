import { KubeObject } from '../../../lib/k8s/cluster';
import { ButtonStyle } from '../ActionButton';
export interface ViewButtonProps {
    /** The item we want to view */
    item: KubeObject;
    /** If we want to have the view open by default */
    initialToggle?: boolean;
    buttonStyle?: ButtonStyle;
}
declare function ViewButton({ item, buttonStyle, initialToggle }: ViewButtonProps): import("react/jsx-runtime").JSX.Element;
export default ViewButton;
