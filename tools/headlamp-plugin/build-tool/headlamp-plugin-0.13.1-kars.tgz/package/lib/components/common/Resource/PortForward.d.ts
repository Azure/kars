import { KubeObject, KubeObjectInterface } from '../../../lib/k8s/KubeObject';
export { type PortForward as PortForwardState } from '../../../lib/k8s/api/v1/portForward';
interface PortForwardKubeObjectProps {
    containerPort: number | string;
    resource?: KubeObject;
}
/** @deprecated Please use PortForwardKubeObjectProps for better type safety */
interface PortForwardLegacyProps {
    containerPort: number | string;
    resource?: KubeObjectInterface;
}
type PortForwardProps = PortForwardKubeObjectProps | PortForwardLegacyProps;
export declare const PORT_FORWARDS_STORAGE_KEY = "portforwards";
export declare const PORT_FORWARD_STOP_STATUS = "Stopped";
export declare const PORT_FORWARD_RUNNING_STATUS = "Running";
export declare const DOCKER_DESKTOP_MIN_PORT = 30000;
export declare const DOCKER_DESKTOP_MAX_PORT = 32000;
export default function PortForward(props: PortForwardProps): import("react/jsx-runtime").JSX.Element | null;
