import { IconProps } from '@iconify/react';
import React from 'react';
export interface TooltipIconProps {
    children: string | React.ReactNode;
    /** A materialui/core icon. */
    icon?: IconProps['icon'];
}
export default function TooltipIcon(props: TooltipIconProps): import("react/jsx-runtime").JSX.Element;
