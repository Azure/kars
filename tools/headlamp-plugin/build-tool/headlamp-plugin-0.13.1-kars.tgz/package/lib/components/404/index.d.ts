export default function NotFoundComponent(): import("react/jsx-runtime").JSX.Element;
