export default function EndpointSliceList(): import("react/jsx-runtime").JSX.Element;
