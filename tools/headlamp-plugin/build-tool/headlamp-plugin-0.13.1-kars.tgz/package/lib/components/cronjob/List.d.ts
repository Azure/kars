import CronJob from '../../lib/k8s/cronJob';
export declare function getSchedule(cronJob: CronJob, locale: string): import("react/jsx-runtime").JSX.Element;
export declare function getLastScheduleTime(cronJob: CronJob): "" | import("react/jsx-runtime").JSX.Element;
export default function CronJobList(): import("react/jsx-runtime").JSX.Element;
