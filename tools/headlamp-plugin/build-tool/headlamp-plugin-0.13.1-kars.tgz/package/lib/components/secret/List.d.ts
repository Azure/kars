export default function SecretList(): import("react/jsx-runtime").JSX.Element;
