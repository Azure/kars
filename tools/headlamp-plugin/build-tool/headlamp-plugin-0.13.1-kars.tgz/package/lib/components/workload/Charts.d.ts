import type { Workload } from '../../lib/k8s/Workload';
import type { PercentageCircleProps } from '../common/Chart';
export interface WorkloadCircleChartProps extends Omit<PercentageCircleProps, 'data'> {
    workloadData: Workload[] | null;
    partialLabel: string;
    totalLabel: string;
}
export declare function WorkloadCircleChart(props: WorkloadCircleChartProps): import("react/jsx-runtime").JSX.Element;
