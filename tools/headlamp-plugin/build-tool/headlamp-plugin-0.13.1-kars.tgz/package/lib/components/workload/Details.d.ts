import { WorkloadClass } from '../../lib/k8s/Workload';
interface WorkloadDetailsProps<T extends WorkloadClass> {
    workloadKind: T;
    name?: string;
    namespace?: string;
    cluster?: string;
}
export default function WorkloadDetails<T extends WorkloadClass>(props: WorkloadDetailsProps<T>): import("react/jsx-runtime").JSX.Element;
export {};
